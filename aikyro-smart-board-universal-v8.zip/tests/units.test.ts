import { DEFAULT_SETTINGS, sanitizeSettings, resolveQuality } from "../src/lib/settings";
import { EN } from "../src/lib/i18n/en";
import { HI } from "../src/lib/i18n/hi";
import { MR } from "../src/lib/i18n/mr";
let f = 0; const ok = (c: boolean, m: string) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) f++; };
ok(JSON.stringify(sanitizeSettings(undefined)) === JSON.stringify(DEFAULT_SETTINGS) && JSON.stringify(sanitizeSettings("junk")) === JSON.stringify(DEFAULT_SETTINGS), "settings: missing/garbage storage -> defaults");
const s = sanitizeSettings({ theme: "dark", room: "studio", speed: 2, reviewGoal: 20, popupQuestions: false, graphics: "low" });
ok(s.theme === "dark" && s.room === "studio" && s.speed === 2 && s.reviewGoal === 20 && s.popupQuestions === false && s.graphics === "low" && s.voiceOn === false, "settings: valid values are kept, the rest default");
const bad = sanitizeSettings({ theme: "neon", room: "<script>", speed: 9, reviewGoal: 7, popupQuestions: "yes", graphics: 3, effects: null });
ok(bad.theme === "system" && bad.room === "auto" && bad.speed === 1 && bad.reviewGoal === 10 && bad.popupQuestions === true && bad.graphics === "auto" && bad.effects === true, "settings: tampered/invalid values fall back safely");
const dev = (o: object) => Object.defineProperty(globalThis, "navigator", { value: o, configurable: true });
ok(resolveQuality("high") === "high" && resolveQuality("low") === "low", "graphics: an explicit choice always wins");
dev({ userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 17)", hardwareConcurrency: 6 }); ok(resolveQuality("auto") === "low", "graphics auto: phones get Low");
dev({ userAgent: "Mozilla/5.0 (X11; Linux)", hardwareConcurrency: 2, deviceMemory: 8 }); ok(resolveQuality("auto") === "low", "graphics auto: 2-core machines get Low");
dev({ userAgent: "Mozilla/5.0 (X11; Linux)", hardwareConcurrency: 4, deviceMemory: 8 }); ok(resolveQuality("auto") === "medium", "graphics auto: ordinary laptops get Medium");
dev({ userAgent: "Mozilla/5.0 (Macintosh)", hardwareConcurrency: 12, deviceMemory: 8 }); ok(resolveQuality("auto") === "high", "graphics auto: powerful machines get High");
const ph = (s: string) => (s.match(/\{(\w+)\}/g) ?? []).sort().join(",");
for (const [name, D] of [["Hindi", HI], ["Marathi", MR]] as const) {
  const keys = Object.keys(EN); const missing = keys.filter((k) => !(k in D)); const mism = keys.filter((k) => k in D && ph((D as Record<string, string>)[k]!) !== ph((EN as Record<string, string>)[k]!));
  ok(missing.length === 0, `${name}: all ${keys.length} strings translated${missing.length ? " — missing " + missing.slice(0, 5) : ""}`);
  ok(mism.length === 0, `${name}: every {placeholder} preserved${mism.length ? " — " + mism.slice(0, 5) : ""}`);
}
console.log(f ? `${f} FAILED` : "ALL PASSED"); process.exit(f ? 1 : 0);
