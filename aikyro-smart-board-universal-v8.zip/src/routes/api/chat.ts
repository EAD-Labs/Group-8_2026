import { createFileRoute } from "@tanstack/react-router";
import { createOpenAI } from "@ai-sdk/openai";
import { streamText } from "ai";
import { z } from "zod";
import { LANG_CODES, aiErrorResponse, completeText, languageRule } from "@/lib/ai-server";
import { pickProvider } from "@/lib/vision-server";

const Input = z.object({
  question: z.string().min(1).max(2000),
  context: z.string().max(12000),
  source: z.string().max(12000).optional(),
  teacher: z.string().max(60).optional(),
  language: z.enum(LANG_CODES).optional(),
});

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const data = Input.parse(await request.json());
          const env = process.env as Record<string, string | undefined>;
          const provider = pickProvider(env);
          if (!provider)
            return Response.json(
              { message: "AI is not configured for this classroom." },
              { status: 401 },
            );
          const teacher = data.teacher?.replace(/[^\p{L}\p{N} .'-]/gu, "") || "Dr Rao";
          const system =
            `You are ${teacher}, a rigorous and warm university teacher in AI KYRO. Answer the learner's exact question using the classroom context. Surface one hidden assumption, use a concrete example, and end with one short check-for-understanding question. Never claim a source says something unless it appears in supplied source text. Keep the answer under 180 words.` +
            languageRule(data.language);
          const prompt = `CLASSROOM CONTEXT:\n${data.context}\n\nLEARNER MATERIAL:\n${data.source || "No learner material attached."}\n\nQUESTION:\n${data.question}`;
          if (provider === "gateway") {
            // the gateway streams, so the answer appears as it is written
            const key = env["LOVABLE_API_KEY"] ?? "";
            const lovable = createOpenAI({
              baseURL: "https://ai.gateway.lovable.dev/v1",
              apiKey: key,
              headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
            });
            const result = streamText({
              model: lovable.responses(env["TEXT_MODEL"] || "openai/gpt-6-astra"),
              system,
              prompt,
              providerOptions: {
                openai: {
                  forceReasoning: true,
                  reasoningEffort: "low",
                  reasoningSummary: "auto",
                  store: false,
                  include: ["reasoning.encrypted_content"],
                },
              },
            });
            return result.toTextStreamResponse();
          }
          return new Response(await completeText(env, { system, prompt, maxTokens: 1024 }), {
            headers: { "content-type": "text/plain; charset=utf-8" },
          });
        } catch (error) {
          if (error instanceof z.ZodError)
            return Response.json({ message: "Invalid question." }, { status: 400 });
          return aiErrorResponse(error);
        }
      },
    },
  },
});
