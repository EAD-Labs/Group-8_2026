import { Component, type ReactNode } from "react";
import { tr } from "@/lib/i18n";

/** True when the browser can create a WebGL context (needed by the 3D classroom). */
export function webglAvailable(): boolean {
  if (typeof document === "undefined") return true;
  try {
    const c = document.createElement("canvas");
    return Boolean(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

function Fallback({ onRetry }: { onRetry?: () => void }) {
  return (
    <div className="scene-fallback" role="status">
      <strong>{tr("scene.failedTitle")}</strong>
      <p>{tr("scene.failedBody")}</p>
      {onRetry && (
        <button type="button" onClick={onRetry}>
          {tr("scene.retry")}
        </button>
      )}
    </div>
  );
}

/** Keeps a 3D failure from taking the whole classroom page down with it. */
export class SceneBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  override componentDidCatch(error: unknown) {
    console.warn("3D classroom failed:", error);
  }
  override render() {
    if (this.state.failed) return <Fallback onRetry={() => this.setState({ failed: false })} />;
    if (!webglAvailable()) return <Fallback />;
    return this.props.children;
  }
}
