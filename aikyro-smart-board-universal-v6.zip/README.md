# Immersive Learning Hub

this was my project and i have attached what i made through claude.. https://classroom-reality-engine.lovable.app.. i also used lovable and made this.. however both of them are not sufficient, i have attached the hld.. optimize and work on this.. the classroom should feel realistic.. 3d ,moving, etc., the modules should not just be abt definitions but should cover all the content..there shoukld be an ioption where i can attach my own class slides/material to learn along with the ai... work on this

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/37c92582-a38c-4530-b13c-4112076fa03d).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Run locally

Requires Node 20+.

```sh
npm install        # or: bun install
npm run dev        # http://localhost:5173
```

Use Chrome or Edge for voice input. AI features (graded feedback, teacher answers, AI-built classes)
need `LOVABLE_API_KEY` in the environment, e.g. `LOVABLE_API_KEY=... npm run dev`. Without it the app
still works using the built-in rubric grader and the offline class builder.

Checks: `npx tsc --noEmit`, `npm run lint`, `npm run build`.

## What is in here

- Three classrooms (Dr Rao / Prof. Meera / Prof. Kabir) with different avatars and an animated smart board
- Narrated lessons with a distinct voice per person, and spoken answers
- Typed or spoken answers are assessed; mastery and points are saved
- Upload PDF / PPTX / DOCX / TXT / MD / PNG / JPG: read on-device, used to ground answers, or turned into a class
- Scans, handwriting and diagrams: pages are rendered to images and sent to an AI vision model
  (`/api/read-page`). Without AI, printed scans fall back to offline OCR (tesseract.js, downloads its
  language data on first use); handwriting and figures are skipped and the app says why

## Handwriting & diagrams (AI key)

Set ONE of these where the server runs (e.g. in the same terminal before `npm run dev`):

```sh
ANTHROPIC_API_KEY=sk-ant-...   # direct Claude (recommended); model claude-sonnet-5-5,
                               # override with ANTHROPIC_VISION_MODEL=...
LOVABLE_API_KEY=...            # Lovable AI gateway; override the model with VISION_MODEL=...
```

Then check it works **before** uploading real notes (with the app running):

```sh
npm run check:vision                      # reads a built-in sample page
npm run check:vision -- ./my-page.jpg     # or one of your own pages
```

Tips for handwriting: scan or photograph flat, in good light, at 150 dpi or more; dark pen on
plain paper works best. Anything the model cannot read is marked `[illegible]`, never guessed.
- Honours "reduce motion"; shows a fallback if WebGL is unavailable
