// Reading a learner's own material (PDF, PowerPoint, Word, text/markdown) in the browser, and
// turning it into (a) searchable sections used to ground answers and (b) a class module.
//
// Previously uploads were only stored: nothing was read, so "grounded in your material" was not
// true. All parsing here is local — the file never has to leave the device just to be read.

import { STOP, stem, words } from "./assess";

export type Section = {
  title: string;
  text: string;
  ref: string;
  /** how the text was obtained: its text layer, the AI page reader, or offline OCR */
  via?: "text" | "ai" | "ocr";
};
export type Extracted = {
  sections: Section[];
  text: string;
  pages: number | null;
  format: "pdf" | "pptx" | "docx" | "text";
  /** non-fatal remark, e.g. "only the first 150 pages were read" */
  note?: string;
};
export type SourceDoc = { name: string; sections: Section[] };

/** An error whose message is safe and useful to show the learner. */
export class MaterialError extends Error {}

export const MAX_FILE_BYTES = 25 * 1024 * 1024;
export const MAX_TEXT_CHARS = 150_000;
const MAX_PDF_PAGES = 150;

// ------------------------------------------------------------------ XML text (docx / pptx)
const decodeEntities = (s: string) =>
  s
    .replace(/&#x([0-9a-f]+);/gi, (_, h: string) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d: string) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");

const normalise = (s: string) =>
  s
    .replace(/[ \t\u00a0]+/g, " ")
    .replace(/\s+$/g, "")
    .replace(/^\s+/g, "");

function runText(paragraphXml: string, tag: "a:t" | "w:t"): string {
  const withBreaks = paragraphXml.replace(/<(?:a:br|w:br|w:tab)\b[^>]*\/>/g, `<${tag}> </${tag}>`);
  const re = new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, "g");
  let out = "";
  for (let m = re.exec(withBreaks); m; m = re.exec(withBreaks)) out += decodeEntities(m[1] ?? "");
  return normalise(out);
}

export type Para = { text: string; heading: boolean };

export function parseDocxXml(xml: string): Para[] {
  const out: Para[] = [];
  for (const m of xml.matchAll(/<w:p[\s>][\s\S]*?<\/w:p>/g)) {
    const p = m[0];
    const text = runText(p, "w:t");
    if (!text) continue;
    out.push({ text, heading: /<w:pStyle\s+w:val="(?:Heading\d|Title|Subtitle)"/i.test(p) });
  }
  return out;
}

export function parsePptxSlideXml(xml: string): string[] {
  const out: string[] = [];
  for (const m of xml.matchAll(/<a:p[\s>][\s\S]*?<\/a:p>/g)) {
    const text = runText(m[0], "a:t");
    if (text) out.push(text);
  }
  return out;
}

// ------------------------------------------------------------------ sectioning
const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s);
const cleanTitle = (s: string) => clip(s.replace(/^[\s\d.)•\-–—·*#]+/, "").trim() || s.trim(), 80);

/** Group paragraphs into chunks of about `target` characters without splitting a paragraph. */
export function chunkParagraphs(paras: string[], target = 1200): string[] {
  const chunks: string[] = [];
  let cur = "";
  for (const p of paras) {
    if (cur && cur.length + p.length > target) {
      chunks.push(cur);
      cur = "";
    }
    cur += (cur ? "\n" : "") + p;
  }
  if (cur) chunks.push(cur);
  return chunks;
}

function sectionsFromParas(paras: Para[], label = "Part"): Section[] {
  const out: Section[] = [];
  if (paras.some((p) => p.heading)) {
    let title = "";
    let body: string[] = [];
    const flush = () => {
      const text = body.join("\n").trim();
      if (text || title)
        out.push({
          title: cleanTitle(title || `${label} ${out.length + 1}`),
          text: text || title,
          ref: `${label} ${out.length + 1}`,
        });
      body = [];
    };
    for (const p of paras) {
      if (p.heading) {
        if (title || body.length) flush();
        title = p.text;
      } else body.push(p.text);
    }
    if (title || body.length) flush();
    return out;
  }
  chunkParagraphs(paras.map((p) => p.text)).forEach((text, i) =>
    out.push({
      title: cleanTitle(text.split("\n")[0] ?? `${label} ${i + 1}`),
      text,
      ref: `${label} ${i + 1}`,
    }),
  );
  return out;
}

export function sectionsFromText(text: string): Section[] {
  const lines = text.replace(/\r\n?/g, "\n").split("\n");
  const paras: Para[] = [];
  for (const raw of lines) {
    const l = raw.trim();
    if (!l) continue;
    const h = /^#{1,3}\s+(.*)$/.exec(l);
    paras.push(h ? { text: h[1] ?? l, heading: true } : { text: l, heading: false });
  }
  return sectionsFromParas(paras);
}

const finish = (
  sections: Section[],
  format: Extracted["format"],
  pages: number | null,
  note?: string,
): Extracted => {
  let total = 0;
  const kept: Section[] = [];
  let truncated = false;
  for (const s of sections) {
    if (!s.text.trim()) continue;
    if (total + s.text.length > MAX_TEXT_CHARS) {
      truncated = true;
      break;
    }
    total += s.text.length;
    kept.push(s);
  }
  if (!kept.length)
    throw new MaterialError(
      "No readable text was found. If this is a scan or a photo, export it as a PDF with selectable text first.",
    );
  const notes = [
    note,
    truncated ? "The file was very long, so only the first part was kept." : undefined,
  ].filter(Boolean);
  return {
    sections: kept,
    text: kept.map((s) => `${s.ref} — ${s.title}\n${s.text}`).join("\n\n"),
    pages,
    format,
    ...(notes.length ? { note: notes.join(" ") } : {}),
  };
};

// ------------------------------------------------------------------ scans, handwriting & figures
// Real handwriting and diagrams need a vision model, so pages are rendered to images and sent to
// the AI page reader (server route /api/read-page). When it is not available, printed scans fall
// back to offline OCR (tesseract); handwriting and figures are then skipped and the learner is told.

export type VisionInput = { dataUrl: string; ref: string; pageText: string };
export type VisionResult = { text: string; figures: string[]; handwritten?: boolean };
/** Resolve null when the AI reader is not available at all; throw for a one-off page failure. */
export type VisionReader = (input: VisionInput) => Promise<VisionResult | null>;

/** The few canvas 2D calls we use, so tests can plug in a Node canvas. */
type Ctx2D = {
  fillStyle: string | CanvasGradient | CanvasPattern;
  fillRect: (x: number, y: number, w: number, h: number) => void;
};
type CanvasLike = {
  width: number;
  height: number;
  getContext: (k: "2d") => Ctx2D;
  toDataURL: (mime: string, quality?: number) => string;
};
export type CanvasEnv = {
  createCanvas: (w: number, h: number) => CanvasLike;
  decodeImage: (
    bytes: Uint8Array,
    mime: string,
  ) => Promise<{ width: number; height: number; draw: (ctx: Ctx2D, w: number, h: number) => void }>;
};
export type OcrEngine = {
  recognize: (image: string) => Promise<{ text: string; confidence: number }>;
  terminate: () => Promise<void>;
};
export type ReadOptions = {
  vision?: VisionReader;
  /** defaults to the browser's canvas */
  env?: CanvasEnv;
  /** defaults to tesseract.js; pass `null` to turn offline OCR off */
  ocr?: (() => Promise<OcrEngine>) | null;
  onProgress?: (message: string) => void;
  maxVisionPages?: number;
};

const MAX_VISION_PAGES = 40;
const MAX_OCR_PAGES = 20;
const OCR_MIN_CONFIDENCE = 55;
const MAX_IMAGE_SIDE = 1568; // Claude downsizes anything larger anyway
const MAX_DATA_URL = 4_000_000;

const browserEnv: CanvasEnv = {
  createCanvas: (w, h) => {
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    return c as unknown as CanvasLike;
  },
  decodeImage: async (bytes, mime) => {
    const bmp = await createImageBitmap(new Blob([bytes as BlobPart], { type: mime }));
    return {
      width: bmp.width,
      height: bmp.height,
      draw: (ctx, w, h) => (ctx as unknown as CanvasRenderingContext2D).drawImage(bmp, 0, 0, w, h),
    };
  },
};

const defaultOcr = async (): Promise<OcrEngine> => {
  const { createWorker } = await import("tesseract.js");
  const worker = await createWorker("eng");
  return {
    recognize: async (img) => {
      const r = await worker.recognize(img);
      return { text: r.data.text, confidence: r.data.confidence };
    },
    terminate: async () => {
      await worker.terminate();
    },
  };
};

const linesOf = (t: string) => t.split("\n").map(normalise).filter(Boolean);

class PageReader {
  stats = { ai: 0, ocr: 0, unreadable: 0, capped: 0, figuresMissed: 0, failed: 0, ocrCapped: 0 };
  private visionOk: boolean | null = null;
  private visionUsed = 0;
  private ocrEngine: OcrEngine | null | undefined;
  constructor(readonly o: ReadOptions) {}

  get env(): CanvasEnv | null {
    return this.o.env ?? (typeof document !== "undefined" ? browserEnv : null);
  }
  progress(m: string) {
    this.o.onProgress?.(m);
  }
  /** `null` = unavailable (no key, offline, out of budget). */
  async askVision(input: VisionInput): Promise<VisionResult | null> {
    if (!this.o.vision || this.visionOk === false) return null;
    if (this.visionUsed >= (this.o.maxVisionPages ?? MAX_VISION_PAGES)) {
      this.stats.capped++;
      return null;
    }
    try {
      const r = await this.o.vision(input);
      if (!r) {
        this.visionOk = false;
        return null;
      }
      this.visionOk = true;
      this.visionUsed++;
      this.stats.ai++;
      return r;
    } catch {
      this.stats.failed++;
      return null;
    }
  }
  get visionAvailable() {
    return Boolean(this.o.vision) && this.visionOk !== false;
  }
  async ocr(dataUrl: string): Promise<{ text: string; confidence: number } | null> {
    if (this.o.ocr === null) return null;
    if (this.stats.ocr >= MAX_OCR_PAGES) {
      this.stats.ocrCapped++;
      return null;
    }
    try {
      this.ocrEngine ??= await (this.o.ocr ?? defaultOcr)();
      return await this.ocrEngine.recognize(dataUrl);
    } catch {
      this.ocrEngine = null;
      return null;
    }
  }
  async close() {
    try {
      await this.ocrEngine?.terminate();
    } catch {
      /* ignore */
    }
  }
  notes(): string[] {
    const s = this.stats;
    const out: string[] = [];
    if (s.ai)
      out.push(
        `${s.ai} page${s.ai === 1 ? "" : "s"} read with the AI page reader (handwriting and figures).`,
      );
    if (s.ocr)
      out.push(
        `${s.ocr} scanned page${s.ocr === 1 ? "" : "s"} read with offline OCR (printed text only).`,
      );
    if (s.unreadable)
      out.push(
        `${s.unreadable} page${s.unreadable === 1 ? "" : "s"} looked handwritten or too faint to read without AI and ${s.unreadable === 1 ? "was" : "were"} skipped.`,
      );
    if (s.figuresMissed)
      out.push(
        `${s.figuresMissed} page${s.figuresMissed === 1 ? " has" : "s have"} diagrams or images that could not be described (the AI page reader is unavailable).`,
      );
    if (s.capped)
      out.push(
        `Only the first ${this.o.maxVisionPages ?? MAX_VISION_PAGES} pages were sent to the AI reader.`,
      );
    if (s.failed)
      out.push(`${s.failed} page${s.failed === 1 ? "" : "s"} could not be read by the AI reader.`);
    if (s.ocrCapped) out.push(`Offline OCR stopped after ${MAX_OCR_PAGES} pages.`);
    return out;
  }
}

/** Draw into a canvas no larger than MAX_IMAGE_SIDE and encode as JPEG small enough to send. */
function encodeCanvas(canvas: CanvasLike): string {
  let q = 0.72;
  let url = canvas.toDataURL("image/jpeg", q);
  while (url.length > MAX_DATA_URL && q > 0.35) {
    q -= 0.15;
    url = canvas.toDataURL("image/jpeg", q);
  }
  return url;
}
function fit(w: number, h: number, max = MAX_IMAGE_SIDE) {
  const k = Math.min(1, max / Math.max(w, h));
  return { w: Math.max(1, Math.round(w * k)), h: Math.max(1, Math.round(h * k)) };
}
async function rasteriseBytes(
  env: CanvasEnv,
  bytes: Uint8Array,
  mime: string,
): Promise<{ dataUrl: string; w: number; h: number } | null> {
  const img = await env.decodeImage(bytes, mime);
  const { w, h } = fit(img.width, img.height);
  const canvas = env.createCanvas(w, h);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  img.draw(ctx, w, h);
  return { dataUrl: encodeCanvas(canvas), w: img.width, h: img.height };
}

/** Result of reading one rasterised page: extra lines to add and how they were obtained. */
async function readRaster(
  r: PageReader,
  a: { ref: string; pageText: string; scanned: boolean; dataUrl: string },
): Promise<{ lines: string[]; via: "ai" | "ocr" } | null> {
  const v = await r.askVision({ dataUrl: a.dataUrl, ref: a.ref, pageText: a.pageText });
  if (v) {
    const lines: string[] = [];
    if (a.scanned || a.pageText.length < 60) lines.push(...linesOf(v.text));
    v.figures.forEach((f, i) =>
      lines.push(`[Figure${v.figures.length > 1 ? " " + (i + 1) : ""}] ${normalise(f)}`),
    );
    if (lines.length) return { lines, via: "ai" };
  }
  if (a.scanned) {
    const o = await r.ocr(a.dataUrl);
    if (o && o.confidence >= OCR_MIN_CONFIDENCE && o.text.trim().length >= 20) {
      r.stats.ocr++;
      return { lines: linesOf(o.text), via: "ocr" };
    }
    r.stats.unreadable++;
  }
  return null;
}

// ------------------------------------------------------------------ format readers
type ZipLike = {
  files: Record<string, { dir: boolean }>;
  file: (name: string) => {
    async: { (t: "string"): Promise<string>; (t: "uint8array"): Promise<Uint8Array> };
  } | null;
};

const IMG_MIME: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
};

export async function extractPptx(zip: ZipLike, reader?: PageReader): Promise<Extracted> {
  const slideNames = Object.keys(zip.files)
    .map((n) => ({ n, i: /^ppt\/slides\/slide(\d+)\.xml$/.exec(n)?.[1] }))
    .filter((x): x is { n: string; i: string } => Boolean(x.i))
    .sort((a, b) => Number(a.i) - Number(b.i));
  if (!slideNames.length)
    throw new MaterialError("That doesn't look like a valid PowerPoint (.pptx) file.");
  // pictures that repeat on most slides are logos/backgrounds, not content
  const picsBySlide = new Map<string, string[]>();
  const seen = new Map<string, number>();
  for (const { i } of slideNames) {
    const rels = (await zip.file(`ppt/slides/_rels/slide${i}.xml.rels`)?.async("string")) ?? "";
    const pics = [...rels.matchAll(/Target="\.\.\/media\/([^"]+\.(?:png|jpe?g|webp))"/gi)].map(
      (m) => m[1] as string,
    );
    picsBySlide.set(i, [...new Set(pics)]);
    for (const n of new Set(pics)) seen.set(n, (seen.get(n) ?? 0) + 1);
  }
  const decorative = (n: string) =>
    slideNames.length >= 3 && (seen.get(n) ?? 0) > slideNames.length / 2;
  const sections: Section[] = [];
  for (const { n, i } of slideNames) {
    reader?.progress(`Reading slide ${Number(i)} of ${slideNames.length}…`);
    const lines = parsePptxSlideXml((await zip.file(n)?.async("string")) ?? "");
    const slideText = lines.join(" ");
    // speaker notes live in a separate part referenced from the slide's relationships
    const rels = (await zip.file(`ppt/slides/_rels/slide${i}.xml.rels`)?.async("string")) ?? "";
    const notesTarget = /Target="\.\.\/notesSlides\/(notesSlide\d+\.xml)"/.exec(rels)?.[1];
    if (notesTarget) {
      const notes = parsePptxSlideXml(
        (await zip.file(`ppt/notesSlides/${notesTarget}`)?.async("string")) ?? "",
      )
        // drop the slide-number placeholder that notes pages always contain
        .filter((l) => !/^\d+$/.test(l));
      if (notes.length) lines.push("Speaker notes: " + notes.join(" "));
    }
    let via: Section["via"];
    const pics = (picsBySlide.get(i) ?? []).filter((p) => !decorative(p)).slice(0, 4);
    for (const pic of pics) {
      if (!reader) break;
      const bytes = await zip.file(`ppt/media/${pic}`)?.async("uint8array");
      if (!bytes || bytes.length < 1500) continue; // tiny bullets (pixel size is checked below)
      const env = reader.env;
      let got: Awaited<ReturnType<typeof readRaster>> = null;
      if (env && reader.visionAvailable) {
        try {
          const ras = await rasteriseBytes(
            env,
            bytes,
            IMG_MIME[pic.split(".").pop()?.toLowerCase() ?? ""] ?? "image/png",
          );
          if (ras && ras.w >= 120 && ras.h >= 120)
            got = await readRaster(reader, {
              ref: `Slide ${Number(i)}`,
              pageText: slideText,
              scanned: false,
              dataUrl: ras.dataUrl,
            });
        } catch {
          reader.stats.failed++;
        }
      } else reader.stats.figuresMissed++;
      if (got) {
        lines.push(...got.lines);
        via = "ai";
      }
    }
    if (!lines.length) continue;
    sections.push({
      title: cleanTitle(lines[0] ?? `Slide ${i}`),
      text: lines.join("\n"),
      ref: `Slide ${Number(i)}`,
      ...(via ? { via } : {}),
    });
  }
  return finish(sections, "pptx", slideNames.length, reader?.notes().join(" ") || undefined);
}

export async function extractDocx(zip: ZipLike): Promise<Extracted> {
  const xml = await zip.file("word/document.xml")?.async("string");
  if (!xml) throw new MaterialError("That doesn't look like a valid Word (.docx) file.");
  return finish(sectionsFromParas(parseDocxXml(xml)), "docx", null);
}

async function pageHasFigures(
  page: { getOperatorList: () => Promise<{ fnArray: number[] }> },
  OPS: Record<string, number>,
): Promise<boolean> {
  try {
    const { fnArray } = await page.getOperatorList();
    const imageOps = new Set(
      [
        OPS["paintImageXObject"],
        OPS["paintInlineImageXObject"],
        OPS["paintImageMaskXObject"],
        OPS["paintJpegXObject"],
      ].filter((x): x is number => typeof x === "number"),
    );
    let images = 0;
    let paths = 0;
    for (const fn of fnArray) {
      if (imageOps.has(fn)) images++;
      else if (fn === OPS["constructPath"]) paths++;
    }
    return images >= 1 || paths >= 12; // pictures, or enough drawn strokes to be a diagram
  } catch {
    return false;
  }
}

async function extractPdf(buf: ArrayBuffer, reader: PageReader): Promise<Extracted> {
  // The "legacy" build polyfills newer JS features (e.g. Promise.try) so PDFs also open on older
  // browsers; the modern build throws there.
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  if (typeof window !== "undefined" && !pdfjs.GlobalWorkerOptions.workerSrc) {
    const worker = await import("pdfjs-dist/legacy/build/pdf.worker.min.mjs?url");
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  }
  let doc;
  try {
    doc = await pdfjs.getDocument({ data: new Uint8Array(buf) }).promise;
  } catch (e) {
    const name = (e as { name?: string }).name;
    throw new MaterialError(
      name === "PasswordException"
        ? "This PDF is password-protected. Remove the password and upload it again."
        : "This PDF couldn't be opened. It may be damaged.",
    );
  }
  const sections: Section[] = [];
  const last = Math.min(doc.numPages, MAX_PDF_PAGES);
  let scannedSkipped = 0;
  for (let p = 1; p <= last; p++) {
    reader.progress(`Reading page ${p} of ${last}…`);
    const page = await doc.getPage(p);
    const content = await page.getTextContent();
    let text = "";
    for (const it of content.items) {
      if (!("str" in it)) continue;
      text += it.str + (it.hasEOL ? "\n" : " ");
    }
    const lines = text.split("\n").map(normalise).filter(Boolean);
    const pageText = lines.join(" ");
    const scanned = pageText.length < 20; // no text layer: a scan, photo or handwriting
    const figures = scanned
      ? false
      : await pageHasFigures(page, pdfjs.OPS as unknown as Record<string, number>);
    let via: Section["via"] = "text";
    if ((scanned || figures) && reader.env && (reader.visionAvailable || scanned)) {
      try {
        const base = page.getViewport({ scale: 1 });
        const { w, h } = fit(base.width * 3, base.height * 3);
        const vp = page.getViewport({ scale: w / base.width });
        const canvas = reader.env.createCanvas(Math.ceil(vp.width), Math.ceil(vp.height));
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        await page.render({ canvasContext: ctx, viewport: vp, canvas } as never).promise;
        void h;
        const got = await readRaster(reader, {
          ref: `Page ${p}`,
          pageText,
          scanned,
          dataUrl: encodeCanvas(canvas),
        });
        if (got) {
          lines.push(...got.lines);
          via = got.via;
        } else if (!scanned && figures) reader.stats.figuresMissed++;
      } catch {
        reader.stats.failed++;
        if (!scanned && figures) reader.stats.figuresMissed++;
      }
    } else if (figures) reader.stats.figuresMissed++;
    if (lines.join(" ").length < 20) {
      if (scanned) scannedSkipped++;
      continue;
    }
    sections.push({
      title: cleanTitle(lines[0] ?? `Page ${p}`),
      text: lines.join("\n"),
      ref: `Page ${p}`,
      via,
    });
  }
  const notes = reader.notes();
  if (doc.numPages > last)
    notes.unshift(`Only the first ${last} of ${doc.numPages} pages were read.`);
  if (!sections.length && scannedSkipped)
    throw new MaterialError(
      "This PDF is a scan or handwritten, and nothing could be read from it. Reading scans and handwriting needs the AI page reader (an AI key must be set on the server: ANTHROPIC_API_KEY or LOVABLE_API_KEY). Or upload a PDF that has selectable text.",
    );
  return finish(sections, "pdf", doc.numPages, notes.join(" ") || undefined);
}

/** Read a File chosen in the browser. Throws MaterialError with a learner-friendly message. */
export async function extractMaterial(file: File, options: ReadOptions = {}): Promise<Extracted> {
  if (file.size > MAX_FILE_BYTES)
    throw new MaterialError("That file is over 25 MB. Try a smaller file or split it.");
  const name = file.name.toLowerCase();
  if (/\.(ppt|doc)$/.test(name))
    throw new MaterialError(
      "Old .ppt/.doc files can't be read. Save as .pptx / .docx (or PDF) and upload again.",
    );
  const reader = new PageReader(options);
  try {
    if (/\.(png|jpe?g|webp)$/.test(name) || /^image\/(png|jpe?g|webp)$/.test(file.type)) {
      const env = reader.env;
      if (!env) throw new MaterialError("Reading images needs a browser.");
      reader.progress("Reading the image…");
      let ras;
      try {
        ras = await rasteriseBytes(
          env,
          new Uint8Array(await file.arrayBuffer()),
          file.type || IMG_MIME[name.split(".").pop() ?? ""] || "image/png",
        );
      } catch {
        throw new MaterialError("This image couldn't be opened.");
      }
      const got = ras
        ? await readRaster(reader, {
            ref: "Image",
            pageText: "",
            scanned: true,
            dataUrl: ras.dataUrl,
          })
        : null;
      if (!got)
        throw new MaterialError(
          "Nothing could be read from this image. Handwriting and diagrams need the AI page reader (an AI key must be set on the server: ANTHROPIC_API_KEY or LOVABLE_API_KEY); offline reading only handles clear printed text.",
        );
      const text = got.lines.join("\n");
      return finish(
        [{ title: cleanTitle(got.lines[0] ?? "Image"), text, ref: "Image", via: got.via }],
        "text",
        1,
        reader.notes().join(" ") || undefined,
      );
    }
    if (/\.gif$|^image\//.test(name + file.type))
      throw new MaterialError(
        "That image type isn't supported. Use PNG, JPG or WebP, or export as PDF.",
      );
    if (/\.pdf$/.test(name) || file.type === "application/pdf")
      return await extractPdf(await file.arrayBuffer(), reader);
    if (/\.(pptx|docx)$/.test(name)) {
      const { default: JSZip } = await import("jszip");
      let zip;
      try {
        zip = await JSZip.loadAsync(await file.arrayBuffer());
      } catch {
        throw new MaterialError(
          "This file couldn't be opened. It may be damaged or not a real Office file.",
        );
      }
      return /\.pptx$/.test(name)
        ? await extractPptx(zip as unknown as ZipLike, reader)
        : await extractDocx(zip as unknown as ZipLike);
    }
    if (/\.(txt|md|markdown|csv|tsv)$/.test(name) || file.type.startsWith("text/"))
      return finish(sectionsFromText(await file.text()), "text", null);
    throw new MaterialError(
      "That file type isn't supported. Use PDF, PPTX, DOCX, TXT, Markdown, or a PNG/JPG image.",
    );
  } finally {
    await reader.close();
  }
}

// ------------------------------------------------------------------ grounding
// STOP only covers words of 4+ letters (the assessor ignores shorter ones); add the short ones.
const SHORT_STOP = new Set(
  "the and for are was but not you all can has had her his its our out who why how may did get got any one use via per yet nor too off own say see".split(
    " ",
  ),
);
const tokens = (s: string) => {
  const m = new Map<string, number>();
  for (const w of words(s)) {
    if (w.length < 3 || STOP.has(w) || SHORT_STOP.has(w)) continue;
    const st = stem(w);
    m.set(st, (m.get(st) ?? 0) + 1);
  }
  return m;
};

/**
 * Pick the passages of the learner's material most relevant to `query`. Returns nothing when
 * nothing overlaps — callers must then say the answer is not grounded rather than pretend.
 */
export function pickExcerpts(
  docs: SourceDoc[],
  query: string,
  maxChars = 5000,
  maxSections = 4,
): { text: string; used: Array<{ name: string; ref: string; title: string }> } {
  const q = tokens(query);
  if (!q.size) return { text: "", used: [] };
  const scored: Array<{ score: number; name: string; s: Section }> = [];
  for (const d of docs)
    for (const s of d.sections) {
      const body = tokens(`${s.title} ${s.text}`);
      const title = tokens(s.title);
      let score = 0;
      for (const [k, wq] of q) {
        const hit = body.get(k);
        if (hit) score += Math.min(hit, 3) * (title.has(k) ? 2 : 1) * Math.min(wq, 2);
      }
      if (score > 0)
        scored.push({ score: score / Math.log2(2 + s.text.length / 400), name: d.name, s });
    }
  scored.sort((a, b) => b.score - a.score);
  const per = Math.floor(maxChars / Math.max(1, Math.min(maxSections, scored.length)));
  const top = scored.slice(0, maxSections);
  return {
    text: top.map((t) => `[${t.name} · ${t.s.ref}]\n${clip(t.s.text, per)}`).join("\n\n"),
    used: top.map((t) => ({ name: t.name, ref: t.s.ref, title: t.s.title })),
  };
}

// ------------------------------------------------------------------ build a class without AI
export type DraftConcept = {
  title: string;
  bloom: string;
  definition: string;
  misconception: string;
  example: string;
  equation: string;
  transfer: string;
};
export type DraftModule = { title: string; description: string; concepts: DraftConcept[] };

const sentences = (t: string) =>
  t
    .split(/(?<=[.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 3);

function partition<T>(items: T[], n: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < n; i++)
    out.push(
      items.slice(Math.floor((i * items.length) / n), Math.floor(((i + 1) * items.length) / n)),
    );
  return out.filter((g) => g.length);
}

/**
 * Offline fallback used when the AI service is unavailable: each group of sections becomes one
 * concept whose definition and example are the learner's own sentences. Misconception and
 * transfer prompts are generic, so the UI labels these classes as "built without AI".
 */
export function buildModuleLocally(title: string, sections: Section[]): DraftModule {
  const usable = sections.filter((s) => s.text.trim().length > 0);
  const totalChars = usable.reduce((t, s) => t + s.text.length, 0);
  if (totalChars < 200)
    throw new MaterialError("There isn't enough text in this material to build a class from.");
  let groups: Section[][];
  if (usable.length >= 2) groups = partition(usable, Math.min(6, usable.length));
  else {
    const sents = sentences(usable[0]?.text ?? "");
    const parts = partition(sents, Math.min(4, Math.max(2, Math.floor(sents.length / 2))));
    groups = parts.map((p, i) => [
      { title: p[0] ?? `Part ${i + 1}`, text: p.join(" "), ref: `Part ${i + 1}` },
    ]);
  }
  const seen = new Set<string>();
  const concepts = groups.map((g, i): DraftConcept => {
    const text = g.map((s) => s.text).join("\n");
    const sents = sentences(text);
    let t = cleanTitle(g[0]?.title ?? `Part ${i + 1}`);
    if (seen.has(t.toLowerCase())) t = `${t} (${i + 1})`;
    seen.add(t.toLowerCase());
    const definition = clip(sents.slice(0, 2).join(" ") || text, 420);
    const example =
      clip(sents.slice(2, 4).join(" "), 320) ||
      `Find where “${t}” appears in your material and trace one case step by step.`;
    const eq = sents.find((x) => /[=≈≤≥∝→±]|\b[A-Za-z]\s*=\s*\S/.test(x) && x.length <= 80);
    return {
      title: t,
      bloom: i === 0 ? "Understand" : i === groups.length - 1 ? "Analyse" : "Apply",
      definition,
      misconception: "this is just a list of facts to memorise rather than an idea to reason with",
      example,
      equation: eq ?? t,
      transfer: `Take the idea from “${t}” and apply it to a situation that does not appear in your material. What carries over, and what changes?`,
    };
  });
  return {
    title: clip(title, 70),
    description: `Built from your material “${clip(title, 50)}” — ${concepts.length} concepts that follow your own sections.`,
    concepts,
  };
}

export const summarise = (text: string, n = 220) => clip(text.replace(/\s+/g, " ").trim(), n);
