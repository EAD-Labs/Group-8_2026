import { createFileRoute } from "@tanstack/react-router";
import { Suspense, lazy, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  BarChart3,
  Beaker,
  BookOpen,
  Brain,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  ClipboardCheck,
  Clock3,
  FileText,
  Flame,
  GraduationCap,
  Hand,
  HelpCircle,
  Library,
  Lightbulb,
  Leaf,
  Mic,
  MicOff,
  Pause,
  Pencil,
  Play,
  Plus,
  Send,
  Settings,
  Sigma,
  Sparkles,
  Sun,
  Target,
  TrendingUp,
  Upload,
  Trash2,
  Volume2,
  VolumeX,
  X,
  Zap,
} from "lucide-react";
import type { CSSProperties, MouseEvent as ReactMouseEvent } from "react";
import { modules as baseModules, arc, type Concept, type Module } from "@/lib/curriculum";
import {
  ROOMS,
  ARJUN,
  MAYA,
  defaultRoomForModule,
  personaFor,
  roomById,
  type RoomId,
  type Speaker,
} from "@/components/classroom/personas";
import {
  assessKindOf,
  assessLocal,
  buildReference,
  dbAssessmentType,
  nextMastery,
  nextReviewAt,
  parseAiAssessment,
  pointsFor,
  type AssessKind,
  type Assessment,
} from "@/lib/assess";
import {
  cancelSpeech,
  pickVoices,
  speak as speakText,
  startRecognizer,
  sttSupported,
  ttsSupported,
  useVoices,
  type Recognizer,
} from "@/lib/voice";
import {
  MaterialError,
  buildModuleLocally,
  extractMaterial,
  pickExcerpts,
  summarise,
  type DraftModule,
  type Extracted,
  type ReadOptions,
  type Section,
  type VisionReader,
} from "@/lib/materials";
import { SceneBoundary } from "@/components/classroom/SceneBoundary";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import type { User } from "@supabase/supabase-js";
import type { Json } from "@/integrations/supabase/types";

// The 3D scene (three.js, ~1 MB) loads only when the classroom is opened.
const ClassroomScene = lazy(() =>
  import("@/components/classroom/ClassroomScene").then((m) => ({ default: m.ClassroomScene })),
);

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "AI KYRO — Metacognitive Classroom" },
      {
        name: "description",
        content:
          "Learn complete university topics through an interactive AI classroom grounded in your own materials.",
      },
      { property: "og:title", content: "AI KYRO — Metacognitive Classroom" },
      {
        property: "og:description",
        content: "An immersive AI classroom for active, measurable learning.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: App,
});

type GenConcept = {
  title: string;
  bloom: string;
  definition: string;
  misconception: string;
  example: string;
  equation: string;
  transfer: string;
};
type VoiceTarget = "topic" | "question" | "response";
type AttemptLog = { key: string; kind: AssessKind; score: number; at: number };
type ResultMeta = { gain: number; from: number; to: number };
type VoiceNote = { target: VoiceTarget | "tts"; text: string; error: boolean };
const PROGRESS_KEY = "kyro_progress_v1";
const KIND_LABEL: Record<AssessKind, string> = {
  question: "YOUR FIRST THOUGHT",
  predict: "YOUR PREDICTION",
  checkpoint: "CHECKPOINT",
  teachback: "TEACH-BACK · TYPE OR SPEAK",
  transfer: "TRANSFER TASK",
};
type Panel = "dashboard" | "classroom" | "library" | "progress";
type Material = {
  id: string;
  title: string;
  file_name: string;
  status: string;
  page_count: number | null;
  extracted_summary: string | null;
  storage_path: string;
  /** the readable text, split into slides / pages / sections (used to ground answers) */
  sections?: Section[];
  /** kept only in this browser (not signed in, or the account save failed) */
  local?: boolean;
};
type UsedSource = { name: string; ref: string; title: string };
const LOCAL_MATERIALS_KEY = "kyro_local_materials_v1";
const MATERIAL_COLUMNS =
  "id,title,file_name,status,page_count,extracted_summary,storage_path,source_outline";
const toSections = (j: unknown): Section[] =>
  Array.isArray(j)
    ? (j as Array<Record<string, unknown>>)
        .filter(
          (x) =>
            x &&
            typeof x["title"] === "string" &&
            typeof x["text"] === "string" &&
            typeof x["ref"] === "string",
        )
        .map((x) => ({
          title: x["title"] as string,
          text: x["text"] as string,
          ref: x["ref"] as string,
          ...(x["via"] === "ai" || x["via"] === "ocr" || x["via"] === "text"
            ? { via: x["via"] }
            : {}),
        }))
    : [];
type MasteryRow = { module_slug: string; concept_slug: string; mastery_score: number };
function required<T>(value: T | undefined, label: string): T {
  if (value === undefined) throw new Error(`Missing ${label}`);
  return value;
}

/**
 * Sends one page image to the AI page reader (handwriting transcription + figure descriptions).
 * Resolves null when the AI is not set up or out of credits, so the caller can fall back to offline
 * OCR and tell the learner what was skipped; throws for a one-off failure on a single page.
 */
let visionProblem = ""; // why the AI reader was unavailable during the current upload, if it was
const visionReader: VisionReader = async ({ dataUrl, ref, pageText }) => {
  const r = await fetch("/api/read-page", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ image: dataUrl, ref, pageText: pageText.slice(0, 6000) }),
  });
  if (r.status === 401 || r.status === 402) {
    const d = (await r.json().catch(() => ({}))) as { message?: string; code?: string };
    visionProblem =
      d.code === "not_configured"
        ? "Handwriting and figures need an AI key on the server (ANTHROPIC_API_KEY or LOVABLE_API_KEY)."
        : (d.message ?? "The AI page reader is unavailable.");
    return null;
  }
  if (!r.ok) throw new Error(`read-page ${r.status}`);
  const d = (await r.json()) as { text?: unknown; figures?: unknown; handwritten?: unknown };
  return {
    text: typeof d.text === "string" ? d.text : "",
    figures: Array.isArray(d.figures)
      ? d.figures.filter((x): x is string => typeof x === "string")
      : [],
    handwritten: d.handwritten === true,
  };
};

function App() {
  const [panel, setPanel] = useState<Panel>("dashboard");
  const [moduleIndex, setModuleIndex] = useState(0);
  const [conceptIndex, setConceptIndex] = useState(1);
  const [stageIndex, setStageIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [response, setResponse] = useState("");
  const [showHint, setShowHint] = useState(false);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [asking, setAsking] = useState(false);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [uploading, setUploading] = useState(false);
  const [matError, setMatError] = useState("");
  const [readMsg, setReadMsg] = useState("");
  const [matNote, setMatNote] = useState("");
  const [buildingId, setBuildingId] = useState<string | null>(null);
  const [materialsLoaded, setMaterialsLoaded] = useState(false);
  const [usedSources, setUsedSources] = useState<UsedSource[] | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [sourceOpen, setSourceOpen] = useState(false);
  const [points, setPoints] = useState(0);
  const [masteryMap, setMasteryMap] = useState<Record<string, number>>({});
  const [attemptLog, setAttemptLog] = useState<AttemptLog[]>([]);
  const [progressLoaded, setProgressLoaded] = useState(false);
  const [roomId, setRoomId] = useState<RoomId>("green-hall");
  const [voiceOn, setVoiceOn] = useState(false);
  const [speakingNow, setSpeakingNow] = useState(false);
  const [voiceNote, setVoiceNote] = useState<VoiceNote | null>(null);
  const [assessing, setAssessing] = useState(false);
  const [result, setResult] = useState<Assessment | null>(null);
  const [resultMeta, setResultMeta] = useState<ResultMeta | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const heroRef = useRef<HTMLButtonElement>(null);
  const [customModules, setCustomModules] = useState<Module[]>([]);
  useEffect(() => {
    try {
      setCustomModules(JSON.parse(localStorage.getItem("kyro_custom_modules") || "[]"));
    } catch {
      /* ignore corrupt saved modules */
    }
  }, []);
  const modules = [...baseModules, ...customModules];
  const [topic, setTopic] = useState("");
  const [attachments, setAttachments] = useState<File[]>([]);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState("");
  const [listening, setListening] = useState<null | VoiceTarget>(null);
  const attachRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<Recognizer | null>(null);
  const recToken = useRef(0);
  const stopDictation = () => {
    recToken.current++; // ignore the late onDone of the session we are stopping
    recRef.current?.stop();
    recRef.current = null;
    setListening(null);
  };
  const dictate = (target: VoiceTarget) => {
    const wasSame = listening === target;
    if (listening) {
      stopDictation();
      if (wasSame) {
        setVoiceNote(null);
        return;
      }
    }
    if (!sttSupported()) {
      setVoiceNote({
        target,
        text: "Voice input isn't supported in this browser. Try Chrome, Edge or Safari — or type instead.",
        error: true,
      });
      return;
    }
    cancelSpeech();
    setSpeakingNow(false);
    if (target === "question") setPlaying(false); // raising your hand pauses the class
    const setter =
      target === "topic" ? setTopic : target === "question" ? setQuestion : setResponse;
    const base = target === "topic" ? topic : target === "question" ? question : response;
    const token = ++recToken.current;
    setVoiceNote({
      target,
      text: "Listening… speak now. Tap the mic again to stop.",
      error: false,
    });
    setListening(target);
    const rec = startRecognizer({
      base,
      onText: (full) => {
        if (token === recToken.current) setter(full);
      },
      onDone: (error) => {
        if (token !== recToken.current) return;
        recRef.current = null;
        setListening(null);
        setVoiceNote(error ? { target, text: error, error: true } : null);
      },
    });
    if (rec) recRef.current = rec;
  };
  /** Turn an AI or offline draft into a saved custom module and open it in the Seminar Studio. */
  const addCustomModule = (d: DraftModule, openNow: boolean): Module => {
    const slug = `custom-${Date.now()}`;
    const mod: Module = {
      slug,
      code: "MY " + (customModules.length + 1),
      title: d.title,
      description: d.description,
      concepts: (d.concepts as GenConcept[]).map((c, i) => ({
        slug: `${slug}-${i}`,
        title: c.title,
        bloom: c.bloom,
        duration: 12,
        mastery: 0,
        stages: arc(c.title, c.definition, c.misconception, c.example, c.equation, c.transfer),
      })),
    };
    const next = [...customModules, mod];
    setCustomModules(next);
    try {
      localStorage.setItem("kyro_custom_modules", JSON.stringify(next));
    } catch {
      /* storage full or blocked — the module still works for this session */
    }
    if (openNow) {
      setModuleIndex(baseModules.length + customModules.length);
      setConceptIndex(0);
      setStageIndex(0);
      setRoomId(defaultRoomForModule(slug));
      setPanel("classroom");
    }
    return mod;
  };
  const readOptions: ReadOptions = { vision: visionReader, onProgress: setReadMsg };
  const removeCustomModule = (slug: string) => {
    const next = customModules.filter((m) => m.slug !== slug);
    const removedIndex = baseModules.length + customModules.findIndex((m) => m.slug === slug);
    setCustomModules(next);
    try {
      localStorage.setItem("kyro_custom_modules", JSON.stringify(next));
    } catch {
      /* ignore */
    }
    if (moduleIndex >= removedIndex) {
      setModuleIndex(
        Math.max(
          0,
          Math.min(
            moduleIndex - (moduleIndex === removedIndex ? 0 : 1),
            baseModules.length + next.length - 1,
          ),
        ),
      );
      setConceptIndex(0);
      setStageIndex(0);
    }
  };
  const generateModule = async () => {
    if (!topic.trim() && !attachments.length) return;
    setGenerating(true);
    setGenError("");
    setMatNote("");
    try {
      const texts: string[] = [];
      const read: Section[] = [];
      visionProblem = "";
      for (const f of attachments) {
        const ex = await extractMaterial(f, readOptions); // text, scans, handwriting, figures
        texts.push(`[${f.name}]\n${ex.text.slice(0, 6000)}`);
        read.push(...ex.sections);
        await upload(f, ex); // also keep it in the library
      }
      let draft: DraftModule | null = null;
      let failure = "Could not build the module.";
      try {
        const r = await fetch("/api/generate-module", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            topic: topic.trim(),
            material: texts.join("\n\n").slice(0, 12000),
          }),
        });
        const d = await r.json();
        if (r.ok) draft = d as DraftModule;
        else failure = d.message || failure;
      } catch {
        failure = "Could not reach the AI service.";
      }
      if (!draft) {
        if (!read.length) throw new Error(failure);
        // AI unavailable: still build a class straight from the learner's own sections.
        draft = buildModuleLocally(
          topic.trim() || attachments[0]?.name.replace(/\.[^.]+$/, "") || "My material",
          read,
        );
        draft.description += " (built without AI)";
        setMatNote(`${failure} The class was built directly from your sections instead.`);
      }
      addCustomModule(draft, false);
      setTopic("");
      setAttachments([]);
    } catch (e) {
      setGenError(e instanceof Error ? e.message : "Something went wrong.");
    }
    setGenerating(false);
  };
  const module = required(modules[moduleIndex] ?? modules[0], "module");
  const concept = required(module.concepts[conceptIndex] ?? module.concepts[0], "concept");
  const stage = required(concept.stages[stageIndex] ?? concept.stages[0], "lesson stage");
  const room = roomById(roomId);
  const lastStage = concept.stages.length - 1;
  const stageKind = assessKindOf(stage);
  const reference = useMemo(() => buildReference(concept.title, concept.stages), [concept]);
  const masteryOf = (m: Module, c: Concept) => masteryMap[`${m.slug}:${c.slug}`] ?? c.mastery;
  const selectModule = (i: number, ci = 0) => {
    const m = modules[i];
    setModuleIndex(i);
    setConceptIndex(ci);
    setStageIndex(0);
    if (m) setRoomId(defaultRoomForModule(m.slug));
  };

  // ----- voice: one distinct voice per persona -----
  const voices = useVoices();
  const assigned = useMemo(
    () => pickVoices(voices, [room.teacher.voice, MAYA.voice, ARJUN.voice]),
    [voices, room],
  );
  const cancelSpeakRef = useRef<(() => void) | null>(null);
  const stopSpeaking = () => {
    cancelSpeakRef.current?.();
    cancelSpeakRef.current = null;
    setSpeakingNow(false);
  };
  const say = (text: string, who: Speaker, onEnd?: () => void) => {
    stopSpeaking();
    if (!ttsSupported()) {
      setVoiceNote({
        target: "tts",
        text: "Spoken audio isn't supported in this browser.",
        error: true,
      });
      setPlaying(false);
      return;
    }
    setVoiceNote((n) => (n?.target === "tts" ? null : n));
    cancelSpeakRef.current = speakText(text, {
      profile: personaFor(room, who).voice,
      voice: assigned[who === "teacher" ? 0 : who === "maya" ? 1 : 2] ?? null,
      speed,
      onStart: () => setSpeakingNow(true),
      onEnd: () => {
        setSpeakingNow(false);
        cancelSpeakRef.current = null;
        onEnd?.();
      },
      onError: (message) => {
        setSpeakingNow(false);
        cancelSpeakRef.current = null;
        setVoiceNote({ target: "tts", text: message, error: true });
        setPlaying(false);
      },
    });
  };
  const live = useRef({ say, stopSpeaking });
  live.current = { say, stopSpeaking };

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  useEffect(() => {
    // Saved progress for this browser (also used when signed out).
    try {
      const raw = localStorage.getItem(PROGRESS_KEY);
      if (raw) {
        const p = JSON.parse(raw) as { mastery?: unknown; attempts?: unknown; points?: unknown };
        if (p.mastery && typeof p.mastery === "object") {
          const clean: Record<string, number> = {};
          for (const [k, v] of Object.entries(p.mastery as Record<string, unknown>))
            if (typeof v === "number" && v >= 0 && v <= 100) clean[k] = v;
          setMasteryMap(clean);
        }
        if (Array.isArray(p.attempts))
          setAttemptLog(
            (p.attempts as AttemptLog[]).filter(
              (a) => a && typeof a.key === "string" && typeof a.score === "number",
            ),
          );
        if (typeof p.points === "number" && p.points >= 0) setPoints(p.points);
      }
    } catch {
      /* ignore unreadable saved progress */
    }
    setProgressLoaded(true);
  }, []);
  useEffect(() => {
    if (!progressLoaded) return;
    try {
      localStorage.setItem(
        PROGRESS_KEY,
        JSON.stringify({ mastery: masteryMap, attempts: attemptLog.slice(-200), points }),
      );
    } catch {
      /* storage full or blocked — progress still works for this session */
    }
  }, [progressLoaded, masteryMap, attemptLog, points]);
  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("points")
      .eq("id", user.id)
      .single()
      .then(({ data }) => setPoints((p) => Math.max(p, data?.points ?? 0)));
    supabase
      .from("concept_mastery")
      .select("module_slug,concept_slug,mastery_score")
      .eq("user_id", user.id)
      .then(({ data }) => {
        const rows: MasteryRow[] = data ?? [];
        if (rows.length)
          setMasteryMap((m) => ({
            ...m,
            ...Object.fromEntries(
              rows.map((r) => [`${r.module_slug}:${r.concept_slug}`, r.mastery_score]),
            ),
          }));
      });
  }, [user]);
  useEffect(() => {
    // Materials read on this device (kept in the browser, also used when signed out).
    try {
      const raw = localStorage.getItem(LOCAL_MATERIALS_KEY);
      const saved = raw ? (JSON.parse(raw) as Material[]) : [];
      const clean = saved
        .filter((m) => m && typeof m.id === "string" && typeof m.file_name === "string")
        .map((m) => ({ ...m, local: true, status: "ready", sections: toSections(m.sections) }));
      if (clean.length) setMaterials((prev) => [...clean, ...prev.filter((m) => !m.local)]);
    } catch {
      /* ignore unreadable saved materials */
    }
    setMaterialsLoaded(true);
  }, []);
  useEffect(() => {
    if (!materialsLoaded) return;
    try {
      localStorage.setItem(LOCAL_MATERIALS_KEY, JSON.stringify(materials.filter((m) => m.local)));
    } catch {
      setMatNote(
        "This browser's storage is full, so your latest material won't be remembered after you close the page.",
      );
    }
  }, [materialsLoaded, materials]);
  useEffect(() => {
    if (!user) {
      setMaterials((m) => m.filter((x) => x.local));
      return;
    }
    supabase
      .from("learning_materials")
      .select(MATERIAL_COLUMNS)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        const rows: Material[] = (data ?? []).map((r) => ({
          id: r.id,
          title: r.title,
          file_name: r.file_name,
          status: r.status,
          page_count: r.page_count,
          extracted_summary: r.extracted_summary,
          storage_path: r.storage_path,
          sections: toSections(r.source_outline),
        }));
        setMaterials((prev) => [...prev.filter((m) => m.local), ...rows]);
      });
  }, [user]);
  // Playback. With "Voice" on, the class is narrated and advances when each line has been spoken;
  // otherwise it advances on a timer. Either way it waits at turns that need YOUR answer, so the
  // lesson never moves on (and wipes your answer) while you are still typing or speaking.
  useEffect(() => {
    if (panel !== "classroom" || !playing) return;
    let timer = 0;
    const advance = () => {
      if (stageIndex < lastStage) setStageIndex(stageIndex + 1);
      else setPlaying(false);
    };
    if (voiceOn) {
      const waits = Boolean(stage.prompt);
      live.current.say(stage.text, stage.speaker, () => {
        if (!waits) timer = window.setTimeout(advance, 600);
      });
      return () => {
        window.clearTimeout(timer);
        live.current.stopSpeaking();
      };
    }
    if (stage.prompt) return;
    timer = window.setTimeout(advance, Math.max(3500, 9000 / speed));
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- stage and lastStage derive from the indices listed here
  }, [playing, voiceOn, stageIndex, conceptIndex, moduleIndex, roomId, panel, speed]);
  useEffect(() => {
    setShowHint(false);
    setResponse("");
    setAnswer("");
    setUsedSources(null);
    setResult(null);
    setResultMeta(null);
    setVoiceNote((n) => (n && n.target !== "topic" ? null : n));
    if (listening === "response" || listening === "question") stopDictation();
    if (!playing) live.current.stopSpeaking();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- reset only when the lesson position or room changes
  }, [stageIndex, conceptIndex, moduleIndex, roomId]);
  useEffect(
    () => () => {
      recToken.current++;
      recRef.current?.stop();
      cancelSpeech();
    },
    [],
  );
  useEffect(() => {
    if (panel !== "classroom") {
      live.current.stopSpeaking();
      if (listening === "response" || listening === "question") stopDictation();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- only react to leaving the classroom panel
  }, [panel]);

  const stageProgress = Math.round(((stageIndex + 1) / concept.stages.length) * 100);
  /** The passages of the learner's own material that are relevant to `query` (may be none). */
  const groundFor = (query: string) =>
    pickExcerpts(
      materials
        .filter((m) => m.sections?.length)
        .map((m) => ({ name: m.file_name, sections: m.sections ?? [] })),
      query,
      5000,
      4,
    );
  const speakerName =
    stage.speaker === "teacher"
      ? room.teacher.name
      : stage.speaker === "maya"
        ? `${MAYA.name} · ${MAYA.role}`
        : `${ARJUN.name} · ${ARJUN.role}`;
  const speak = () => {
    if (speakingNow) stopSpeaking();
    else say(stage.text, stage.speaker);
  };
  const stageKeyRef = useRef("");
  stageKeyRef.current = `${module.slug}:${concept.slug}:${stageIndex}`;
  const bestRef = useRef<Record<string, number>>({});
  const submitAttempt = async () => {
    if (!stageKind || !response.trim() || assessing) return;
    stopDictation();
    const key = stageKeyRef.current;
    const text = response.trim();
    const kind = stageKind;
    setAssessing(true);
    let a: Assessment | null = null;
    try {
      const r = await fetch("/api/assess", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          kind,
          response: text.slice(0, 4000),
          concept: concept.title,
          prompt: stage.prompt,
          reference: {
            definition: reference.definition,
            example: reference.example,
            misconception: reference.misconception,
            equation: reference.equation,
            transfer: reference.transfer,
          },
          source: groundFor(`${text} ${concept.title}`).text,
        }),
      });
      if (r.ok) a = parseAiAssessment(await r.json());
    } catch {
      /* offline or AI not configured — fall back to the built-in rubric below */
    }
    const graded = a ?? assessLocal({ kind, response: text, reference });
    const mkey = `${module.slug}:${concept.slug}`;
    const from = masteryOf(module, concept);
    const to = nextMastery(from, graded.score, kind);
    const prevBest = bestRef.current[key] ?? 0;
    const gain = Math.max(0, pointsFor(graded.score) - pointsFor(prevBest));
    bestRef.current[key] = Math.max(prevBest, graded.score);
    setMasteryMap((m) => ({ ...m, [mkey]: to }));
    setPoints((pt) => pt + gain);
    setAttemptLog((l) => [
      ...l.slice(-199),
      { key: mkey, kind, score: graded.score, at: Date.now() },
    ]);
    if (user) {
      const warn = (what: string) => (r: { error: { message: string } | null }) => {
        if (r.error) console.warn(`Could not save ${what}:`, r.error.message);
      };
      supabase
        .from("concept_mastery")
        .upsert(
          {
            user_id: user.id,
            module_slug: module.slug,
            concept_slug: concept.slug,
            bloom_level: concept.bloom.toLowerCase(),
            mastery_score: to,
            next_review_at: nextReviewAt(to),
          },
          { onConflict: "user_id,module_slug,concept_slug" },
        )
        .then(warn("mastery"));
      supabase
        .from("assessment_attempts")
        .insert({
          user_id: user.id,
          concept_slug: concept.slug,
          assessment_type: dbAssessmentType(kind),
          response_text: text,
          score: graded.score,
          feedback: graded as unknown as Json,
        })
        .then(warn("attempt"));
      if (gain)
        supabase
          .from("profiles")
          .upsert({ id: user.id, points: points + gain })
          .then(warn("points"));
    }
    if (stageKeyRef.current === key) {
      setResult(graded);
      setResultMeta({ gain, from, to });
    }
    setAssessing(false);
  };
  const ask = async () => {
    if (!question.trim() || asking) return;
    stopDictation();
    setPlaying(false);
    stopSpeaking();
    setAsking(true);
    setAnswer("");
    // Search on what was actually asked; only borrow the concept title for very short follow-ups
    // ("why?"), otherwise every question would match the slide on screen and look "grounded".
    const grounding = groundFor(
      question.trim().split(/\s+/).length < 4 ? `${question} ${concept.title}` : question,
    );
    setUsedSources(materials.some((m) => m.sections?.length) ? grounding.used : null);
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          question,
          context: concept.stages
            .slice(0, stageIndex + 1)
            .map((s) => `${s.speaker}: ${s.text}`)
            .join("\n"),
          source: grounding.text,
          teacher: room.teacher.name,
        }),
      });
      if (!r.ok) {
        const e = await r.json();
        throw new Error(e.message);
      }
      const reader = r.body?.getReader();
      const decoder = new TextDecoder();
      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          setAnswer((a) => a + decoder.decode(value, { stream: true }));
        }
      }
    } catch (e) {
      setAnswer(e instanceof Error ? e.message : "The teacher could not answer right now.");
    } finally {
      setAsking(false);
    }
  };
  const upload = async (file: File, pre?: Extracted): Promise<Material | null> => {
    setMatError("");
    setUploading(true);
    if (!pre) visionProblem = "";
    try {
      const ex = pre ?? (await extractMaterial(file, readOptions));
      const base = {
        title: file.name.replace(/\.[^.]+$/, ""),
        file_name: file.name,
        page_count: ex.pages,
        extracted_summary: summarise(ex.sections.map((s) => s.text).join(" ")),
      };
      let saved: Material | null = null;
      if (user) {
        const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
        const path = `${user.id}/${crypto.randomUUID()}-${safe}`;
        const { error } = await supabase.storage.from("learning-materials").upload(path, file);
        if (!error) {
          const { data, error: insErr } = await supabase
            .from("learning_materials")
            .insert({
              user_id: user.id,
              ...base,
              file_type: file.type || "application/octet-stream",
              storage_path: path,
              status: "ready",
              source_outline: ex.sections as unknown as Json,
            })
            .select(MATERIAL_COLUMNS)
            .single();
          if (data && !insErr)
            saved = { ...data, source_outline: undefined, sections: ex.sections } as Material;
        }
        if (!saved)
          setMatNote("Couldn't save to your account, so this file is kept on this device only.");
      }
      saved ??= {
        id: `local-${crypto.randomUUID()}`,
        ...base,
        status: "ready",
        storage_path: "",
        sections: ex.sections,
        local: true,
      };
      const result = saved;
      setMaterials((m) => [result, ...m]);
      if (ex.note || visionProblem) setMatNote([ex.note, visionProblem].filter(Boolean).join(" "));
      return result;
    } catch (e) {
      setMatError(
        e instanceof MaterialError
          ? [e.message, visionProblem].filter(Boolean).join(" ")
          : "Something went wrong reading that file.",
      );
      return null;
    } finally {
      setUploading(false);
      setReadMsg("");
    }
  };
  const uploadMany = async (files: FileList | File[] | null | undefined) => {
    for (const f of Array.from(files ?? [])) await upload(f);
  };
  const removeMaterial = async (m: Material) => {
    setMaterials((all) => all.filter((x) => x.id !== m.id));
    if (!m.local && user) {
      await supabase.from("learning_materials").delete().eq("id", m.id);
      if (m.storage_path)
        await supabase.storage.from("learning-materials").remove([m.storage_path]);
    }
  };
  const buildClass = async (m: Material) => {
    const sections = m.sections ?? [];
    setMatError("");
    setMatNote("");
    if (!sections.length) {
      setMatError("No readable text was saved for this file. Upload it again so it can be read.");
      return;
    }
    setBuildingId(m.id);
    let draft: DraftModule | null = null;
    let aiNote = "";
    try {
      const r = await fetch("/api/generate-module", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          topic: m.title,
          material: sections
            .map((s) => `[${s.ref}] ${s.title}\n${s.text}`)
            .join("\n\n")
            .slice(0, 12000),
        }),
      });
      const d = await r.json();
      if (r.ok && Array.isArray(d.concepts) && d.concepts.length >= 2) draft = d as DraftModule;
      else aiNote = d?.message || "";
    } catch {
      aiNote = "Could not reach the AI service.";
    }
    if (!draft) {
      try {
        draft = buildModuleLocally(m.title, sections);
        draft.description += " (built without AI)";
        setMatNote(
          `${aiNote || "AI isn't available right now."} Built straight from your sections: definitions and examples are your own text; the challenge questions are generic.`,
        );
      } catch (e) {
        setMatError(
          e instanceof MaterialError ? e.message : "Could not build a class from this file.",
        );
        setBuildingId(null);
        return;
      }
    }
    addCustomModule(draft, true);
    setBuildingId(null);
  };
  const google = async () => {
    await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
  };
  const heroMove = (e: ReactMouseEvent<HTMLButtonElement>) => {
    const el = heroRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--x", `${e.clientX - r.left}px`);
    el.style.setProperty("--y", `${e.clientY - r.top}px`);
  };
  const openConcept = (mi: number, ci: number) => {
    selectModule(mi, ci);
    setPanel("classroom");
  };
  const masteryValues = Object.values(masteryMap);
  const conceptsStarted = masteryValues.length;
  const conceptsRetained = masteryValues.filter((v) => v >= 80).length;
  const openDoubts = masteryValues.filter((v) => v < 60).length;
  const allConcepts = modules.flatMap((m) => m.concepts.map((c) => ({ m, c, v: masteryOf(m, c) })));
  const activeConcepts = allConcepts.filter((x) => x.v > 0);
  const reviewConcepts = activeConcepts.filter((x) => x.v < 60);
  const transferScores = attemptLog.filter((a) => a.kind === "transfer");
  const transferAvg = transferScores.length
    ? Math.round(transferScores.reduce((t, a) => t + a.score, 0) / transferScores.length)
    : null;
  const retainedPct = conceptsStarted ? Math.round((conceptsRetained / conceptsStarted) * 100) : 0;
  const firstName = user?.email?.split("@")[0];
  const hour = new Date().getHours();
  const dayWord = hour < 12 ? "MORNING" : hour < 17 ? "AFTERNOON" : "EVENING";

  const visibleStages = concept.stages.slice(0, stageIndex + 1);

  return (
    <main className="app-shell">
      <aside className="main-sidebar">
        <div className="brand">
          <span className="brand-mark">
            <Sun />
          </span>
          <div>
            <strong>AI KYRO</strong>
            <small>Learn · Think · Grow</small>
          </div>
        </div>
        <div className="room-card">
          <span>
            <BookOpen />
          </span>
          <div>
            <strong>Room 617</strong>
            <small>Your learning space</small>
          </div>
          <b>›</b>
        </div>
        <nav aria-label="Primary">
          <Button
            variant="ghost"
            className={panel === "dashboard" ? "active" : ""}
            onClick={() => setPanel("dashboard")}
          >
            <BookOpen />
            <span>My Desk</span>
          </Button>
          <Button
            variant="ghost"
            className={panel === "classroom" ? "active" : ""}
            onClick={() => setPanel("classroom")}
          >
            <GraduationCap />
            <span>Classroom</span>
          </Button>
          <Button
            variant="ghost"
            className={panel === "library" ? "active" : ""}
            onClick={() => setPanel("library")}
          >
            <Library />
            <span>Class Library</span>
          </Button>
          <Button
            variant="ghost"
            className={panel === "progress" ? "active" : ""}
            onClick={() => setPanel("progress")}
          >
            <TrendingUp />
            <span>Report Card</span>
          </Button>
        </nav>
        <div className="sidebar-note">
          <i />
          <p>
            Small steps
            <br />
            build big ideas.
          </p>
          <Sparkles />
        </div>
        <div className="sidebar-profile">
          <span>{user?.email?.charAt(0).toUpperCase() ?? "S"}</span>
          <div>
            <strong>{user?.email?.split("@")[0] ?? "Student"}</strong>
            <small>Keep exploring</small>
          </div>
          <Settings />
        </div>
      </aside>

      <div className="app-content">
        <header className="topbar">
          <div>
            <span className="header-icon">
              <Sun />
            </span>
            <div>
              <strong>
                {panel === "dashboard"
                  ? "My Desk"
                  : panel === "classroom"
                    ? "Classroom"
                    : panel === "library"
                      ? "Class Library"
                      : "Report Card"}
              </strong>
              <small>
                {panel === "dashboard"
                  ? "Room 617 · Your learning space"
                  : panel === "classroom"
                    ? `${module.code} · ${concept.title}`
                    : "AI KYRO"}
              </small>
            </div>
          </div>
          <div className="top-actions">
            <span className="encouragement">
              <Sparkles /> Keep going!
            </span>
            <span className="points">{points} points</span>
            {user ? (
              <Button variant="outline" onClick={() => supabase.auth.signOut()}>
                Sign out
              </Button>
            ) : (
              <Button variant="outline" onClick={() => setAuthOpen(true)}>
                Sign in
              </Button>
            )}
          </div>
        </header>

        {panel === "dashboard" && (
          <div className="kyro-dashboard">
            <section className="dashboard-greeting">
              <div>
                <div className="eyebrow">
                  <Sun size={14} /> GOOD {dayWord}
                  {user ? ", STUDENT" : ""}
                </div>
                <h2 className="kyro-title">Welcome back{firstName ? `, ${firstName}` : ""}.</h2>
                <p className="kyro-subtitle">
                  {conceptsStarted > 0
                    ? `${conceptsRetained} of ${conceptsStarted} concept${conceptsStarted === 1 ? "" : "s"} retained so far.`
                    : "A good day to learn something new."}
                </p>
              </div>
              <div className="desk-note">
                <Pencil size={15} />
                <span>Small steps build big ideas.</span>
              </div>
            </section>
            <button
              ref={heroRef}
              onMouseMove={heroMove}
              onClick={() => setPanel("classroom")}
              className="classroom-hero group"
            >
              <div className="hero-window-glow" />
              <div className="hero-sunbeam beam-one" />
              <div className="hero-sunbeam beam-two" />
              <div className="hero-window">
                <div className="window-sky" />
                <div className="window-cross horizontal" />
                <div className="window-cross vertical" />
                <div className="window-trees" />
              </div>
              <div className="hero-clock">
                <span>10</span>
                <i />
                <span>2</span>
                <b />
                <span>4</span>
                <em />
                <span>8</span>
              </div>
              <div className="hero-board">
                <div className="board-pin pin-a" />
                <div className="board-pin pin-b" />
                <span className="board-kicker">
                  <BookOpen size={13} /> TODAY'S LESSON
                </span>
                <strong>Think → question → test</strong>
                <div className="board-rule" />
                <p>
                  No answer is accepted
                  <br />
                  without a second thought.
                </p>
                <span className="board-smile">☼</span>
                <div className="chalk-lines">
                  <i />
                  <i />
                  <i />
                </div>
              </div>
              <div className="hero-copy">
                <div className="hero-mini">
                  <span className="sun-doodle">☼</span> NEXT PERIOD
                </div>
                <h1>
                  Step into the
                  <br />
                  <span>classroom.</span>
                </h1>
                <p>
                  Pick a concept and learn through a live teacher–student discussion. Predict,
                  explain, challenge, and test your thinking.
                </p>
                <span className="hero-cta">
                  Enter class <ArrowRight size={16} />
                </span>
                <span className="hero-meta">
                  <Clock3 size={13} /> ~10 min · interactive
                </span>
              </div>
              <div className="hero-desk desk-books">
                <span />
                <span />
                <span />
                <i />
              </div>
              <div className="hero-desk desk-pencil">
                <i />
                <b />
                <em />
              </div>
              <div className="hero-plant">
                <Leaf size={35} />
                <span />
                <i />
                <b />
              </div>
              <div className="hero-cursor-light" />
            </button>
            <section className="stats-ribbon">
              <div className="stat-pill">
                <span className="stat-icon gold">
                  <Sparkles size={16} />
                </span>
                <strong>{points}</strong>
                <small>points</small>
              </div>
              <div className="stat-pill">
                <span className="stat-icon green">
                  <Flame size={16} />
                </span>
                <strong>
                  {conceptsRetained}
                  <small>/{conceptsStarted}</small>
                </strong>
                <small>retained</small>
              </div>
              <div className="stat-pill">
                <span className="stat-icon violet">
                  <ClipboardCheck size={16} />
                </span>
                <strong>{openDoubts}</strong>
                <small>open doubt{openDoubts === 1 ? "" : "s"}</small>
              </div>
              <button className="stats-progress" onClick={() => setPanel("progress")}>
                <BarChart3 size={16} /> View learning progress <ArrowRight size={14} />
              </button>
            </section>
            <div className="dashboard-grid">
              <main className="dashboard-main">
                <section>
                  <div className="section-heading">
                    <div>
                      <span className="section-icon book">
                        <BookOpen size={17} />
                      </span>
                      <div>
                        <h3>Continue Learning</h3>
                        <p>Pick up where your thinking left off.</p>
                      </div>
                    </div>
                    <button onClick={() => setPanel("classroom")}>
                      View all <ArrowRight size={14} />
                    </button>
                  </div>
                  <div className="module-grid">
                    {modules.map((mod, index) => {
                      const Icon = mod.slug.includes("thermo") ? Beaker : Sigma;
                      const explored = Object.keys(masteryMap).filter((k) =>
                        k.startsWith(`${mod.slug}:`),
                      ).length;
                      return (
                        <article key={mod.slug} className="module-card group">
                          <div
                            className={
                              index % 2
                                ? "module-visual module-visual-gold"
                                : "module-visual module-visual-green"
                            }
                          >
                            <span className="module-badge">
                              {explored > 0 ? "IN PROGRESS" : "NEXT UP"}
                            </span>
                            <Icon className="module-main-icon" size={42} strokeWidth={1.35} />
                            <span className="module-scribble">
                              {explored > 0 ? "keep going →" : "new idea"}
                            </span>
                            <span className="module-shape shape-one" />
                            <span className="module-shape shape-two" />
                          </div>
                          <div className="module-body">
                            <div className="module-title-row">
                              <h4>{mod.title}</h4>
                              <span className="module-arrow">
                                <ArrowRight size={15} />
                              </span>
                            </div>
                            <p>{mod.concepts.length} concepts · build it step by step</p>
                            <div className="module-progress">
                              <span style={{ width: `${Math.min(82, 22 + explored * 12)}%` }} />
                            </div>
                            <span className="module-progress-label">
                              {explored} / {mod.concepts.length} concepts explored
                            </span>
                            {mod.concepts.slice(0, 2).map((c, ci) => (
                              <button
                                key={c.slug}
                                className="concept-row"
                                onClick={() => openConcept(index, ci)}
                              >
                                <span className="concept-dot" />
                                <span className="concept-name">{c.title}</span>
                                <span className="bloom-tag">{c.bloom}</span>
                                <ArrowRight size={13} />
                              </button>
                            ))}
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </section>
                <section className="journey-card">
                  <div className="section-heading compact">
                    <div>
                      <span className="section-icon journey">
                        <Target size={17} />
                      </span>
                      <div>
                        <h3>Your Learning Journey</h3>
                        <p>Progress, not perfection.</p>
                      </div>
                    </div>
                  </div>
                  <div className="journey-content">
                    <div
                      className="progress-ring"
                      style={{ "--progress": `${retainedPct}%` } as CSSProperties}
                    >
                      <div>
                        <strong>{retainedPct}%</strong>
                        <span>retained</span>
                      </div>
                    </div>
                    <div className="journey-copy">
                      <strong>{conceptsRetained} concepts retained</strong>
                      <span>{conceptsStarted} concepts explored so far</span>
                      <em>“Curiosity first. Answers second.”</em>
                    </div>
                    <div className="journey-mini">
                      <span>
                        <Flame size={15} />
                        Streak
                      </span>
                      <strong>{conceptsRetained}</strong>
                      <small>concepts</small>
                    </div>
                    <div className="journey-mini">
                      <span>
                        <Brain size={15} />
                        Thinking
                      </span>
                      <strong>{openDoubts}</strong>
                      <small>open doubts</small>
                    </div>
                  </div>
                </section>
                <section>
                  <div className="section-heading compact">
                    <div>
                      <span className="section-icon practice">
                        <Zap size={17} />
                      </span>
                      <div>
                        <h3>Quick Practice</h3>
                        <p>Short activities to keep your mind sharp.</p>
                      </div>
                    </div>
                  </div>
                  <div className="practice-grid">
                    <button onClick={() => setPanel("classroom")} className="practice-card yellow">
                      <span>
                        <Lightbulb size={19} />
                      </span>
                      <div>
                        <strong>Concept Check</strong>
                        <small>Quick, focused questions</small>
                      </div>
                      <ArrowRight size={15} />
                    </button>
                    <button onClick={() => openConcept(0, 0)} className="practice-card coral">
                      <span>
                        <Target size={19} />
                      </span>
                      <div>
                        <strong>Mixed Practice</strong>
                        <small>Variety of concepts</small>
                      </div>
                      <ArrowRight size={15} />
                    </button>
                    <button onClick={() => setPanel("progress")} className="practice-card blue">
                      <span>
                        <ClipboardCheck size={19} />
                      </span>
                      <div>
                        <strong>Past Progress</strong>
                        <small>See what needs review</small>
                      </div>
                      <ArrowRight size={15} />
                    </button>
                  </div>
                </section>
              </main>
              <aside className="dashboard-rail">
                <div className="rail-card lesson-card">
                  <div className="rail-title">
                    <span>
                      <Clock3 size={16} /> Today at a glance
                    </span>
                    <span className="rail-live">LIVE</span>
                  </div>
                  <div className="rail-timeline">
                    <div className="timeline-item active">
                      <span className="timeline-dot" />
                      <div>
                        <small>NOW</small>
                        <strong>Interactive classroom</strong>
                        <p>Think → question → test</p>
                      </div>
                    </div>
                    <div className="timeline-item">
                      <span className="timeline-dot" />
                      <div>
                        <small>NEXT</small>
                        <strong>
                          {materials.length
                            ? `${materials.length} source${materials.length > 1 ? "s" : ""} ready`
                            : "Keep exploring"}
                        </strong>
                        <p>
                          {materials.length
                            ? "Your material can ground the next class."
                            : "Choose a concept from your desk."}
                        </p>
                      </div>
                    </div>
                  </div>
                  <button onClick={() => setPanel("library")} className="rail-link">
                    Open class library <ArrowRight size={14} />
                  </button>
                </div>
                <div className="rail-card activity-card">
                  <div className="rail-title">
                    <span>
                      <CheckCircle2 size={16} /> Your desk
                    </span>
                  </div>
                  <div className="desk-stat">
                    <span className="desk-stat-icon yellow">
                      <Sparkles size={15} />
                    </span>
                    <div>
                      <strong>{points}</strong>
                      <small>learning points</small>
                    </div>
                  </div>
                  <div className="desk-stat">
                    <span className="desk-stat-icon green">
                      <Leaf size={15} />
                    </span>
                    <div>
                      <strong>{conceptsRetained}</strong>
                      <small>concepts retained</small>
                    </div>
                  </div>
                  <div className="desk-stat">
                    <span className="desk-stat-icon violet">
                      <HelpCircle size={15} />
                    </span>
                    <div>
                      <strong>{openDoubts}</strong>
                      <small>open doubts to revisit</small>
                    </div>
                  </div>
                </div>
                <div className="quote-note">
                  <span className="pin" />
                  <span className="quote-icon">✦</span>
                  <p>
                    “The goal isn't to know everything. It's to notice what you don't know yet.”
                  </p>
                  <small>— AI KYRO</small>
                </div>
              </aside>
            </div>
            <div className="kyro-footer">
              <span /> ET 617 · Metacognitive AI Scaffold <span />
            </div>
          </div>
        )}

        {panel === "classroom" && (
          <div className="classroom-page">
            <div className="classroom-toolbar">
              <div>
                <span>NOW LEARNING</span>
                <strong>{module.title}</strong>
                <small>
                  {concept.title} · {concept.bloom}
                </small>
              </div>
              <div className="module-tabs" role="group" aria-label="Module">
                {modules.map((m, i) => (
                  <Button
                    size="sm"
                    variant="ghost"
                    key={m.slug}
                    className={i === moduleIndex ? "active" : ""}
                    onClick={() => selectModule(i)}
                  >
                    {m.code}
                  </Button>
                ))}
              </div>
              <div className="room-picker" role="group" aria-label="Classroom">
                {ROOMS.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    className={r.id === roomId ? "active" : ""}
                    aria-pressed={r.id === roomId}
                    title={`${r.name} — ${r.tagline}`}
                    onClick={() => setRoomId(r.id)}
                  >
                    <b>{r.teacher.name}</b>
                    <small>{r.name}</small>
                  </button>
                ))}
              </div>
              <div className="toolbar-right">
                <Button
                  variant={voiceOn ? "default" : "outline"}
                  aria-pressed={voiceOn}
                  title="Narrate the class aloud with a different voice for each person"
                  onClick={() => {
                    if (voiceOn) stopSpeaking();
                    setVoiceOn(!voiceOn);
                  }}
                >
                  {voiceOn ? <Volume2 /> : <VolumeX />} Voice {voiceOn ? "on" : "off"}
                </Button>
                <Button variant="outline" onClick={speak}>
                  <Volume2 /> {speakingNow ? "Stop" : "Read aloud"}
                </Button>
              </div>
            </div>
            {voiceNote?.target === "tts" && (
              <p className={`voice-note ${voiceNote.error ? "error" : ""}`} role="status">
                {voiceNote.text}
              </p>
            )}
            <div className="classroom-layout">
              <section className="classroom-stage">
                <div className="scene">
                  <SceneBoundary>
                    <Suspense
                      fallback={<div className="scene-fallback">Loading the classroom…</div>}
                    >
                      <ClassroomScene
                        speaker={stage.speaker}
                        roomId={roomId}
                        board={stage.board}
                        moduleTitle={module.title}
                        conceptTitle={concept.title}
                        lessonText={`${stage.text}. ${stage.prompt ?? ""}`}
                      />
                    </Suspense>
                  </SceneBoundary>
                  <div className="scene-top">
                    <span className="live-dot">
                      <i /> LIVE CLASS
                    </span>
                    <span>{concept.title}</span>
                    <Button variant="ghost" onClick={() => setSourceOpen(!sourceOpen)}>
                      <FileText />{" "}
                      {materials.length ? `${materials.length} sources` : "Course source"}
                    </Button>
                  </div>
                  <div className="speaker-card">
                    <div className={`speaker-avatar ${stage.speaker}`}>
                      {stage.speaker === "teacher" ? (
                        <GraduationCap />
                      ) : stage.speaker === "maya" ? (
                        <BookOpen />
                      ) : (
                        <Brain />
                      )}
                    </div>
                    <div>
                      <small>{stage.label}</small>
                      <strong>{speakerName}</strong>
                      <p>{stage.text}</p>
                    </div>
                  </div>
                  {sourceOpen && (
                    <div className="source-drawer">
                      <div>
                        <strong>Sources in this class</strong>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setSourceOpen(false)}
                          aria-label="Close sources"
                        >
                          <X />
                        </Button>
                      </div>
                      {materials.length ? (
                        materials.map((m) => (
                          <article key={m.id}>
                            <FileText />
                            <div>
                              <b>{m.title}</b>
                              <small>
                                {m.file_name} · {m.sections?.length ?? 0} sections
                              </small>
                            </div>
                            <span>Ready</span>
                          </article>
                        ))
                      ) : (
                        <p>
                          This lesson uses the verified AI KYRO pilot curriculum. Add your own
                          slides to ground the next class.
                        </p>
                      )}
                    </div>
                  )}
                </div>
                <div className="transport">
                  <div>
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() => setStageIndex((i) => Math.max(0, i - 1))}
                      aria-label="Previous turn"
                    >
                      <ChevronLeft />
                    </Button>
                    <Button
                      size="icon"
                      onClick={() => setPlaying((p) => !p)}
                      aria-label={playing ? "Pause" : "Play"}
                    >
                      {playing ? <Pause /> : <Play />}
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() =>
                        setStageIndex((i) => Math.min(concept.stages.length - 1, i + 1))
                      }
                      aria-label="Next turn"
                    >
                      <ChevronRight />
                    </Button>
                  </div>
                  <div className="timeline">
                    <Progress value={stageProgress} />
                    <small>
                      Class discussion · {stageIndex + 1} of {concept.stages.length}
                      {playing && stage.prompt && !result ? " · waiting for you" : ""}
                    </small>
                  </div>
                  <Button
                    variant="outline"
                    className="speed"
                    onClick={() => setSpeed((s) => (s === 1 ? 1.5 : s === 1.5 ? 2 : 1))}
                  >
                    {speed}×
                  </Button>
                </div>
              </section>
              <aside className="class-transcript">
                <div className="transcript-header">
                  <div>
                    <small>CLASS TRANSCRIPT</small>
                    <h2>Follow the discussion</h2>
                  </div>
                  <span>
                    <i /> LIVE
                  </span>
                </div>
                <div className="transcript-list">
                  {visibleStages.map((item, i) => (
                    <article
                      key={`${item.speaker}-${i}`}
                      className={i === stageIndex ? "current" : ""}
                    >
                      <span className={`transcript-avatar ${item.speaker}`}>
                        {item.speaker === "teacher" ? (
                          <GraduationCap />
                        ) : item.speaker === "maya" ? (
                          <BookOpen />
                        ) : (
                          <Brain />
                        )}
                      </span>
                      <div>
                        <header>
                          <strong>{personaFor(room, item.speaker).name}</strong>
                          {i === stageIndex && <em>speaking</em>}
                        </header>
                        <p>{item.text}</p>
                      </div>
                    </article>
                  ))}
                </div>
                {stage.prompt && (
                  <div className="transcript-response">
                    <small>{stageKind ? KIND_LABEL[stageKind] : "YOUR RESPONSE"}</small>
                    <p>{stage.prompt}</p>
                    <Textarea
                      value={response}
                      onChange={(e) => setResponse(e.target.value)}
                      disabled={assessing}
                      placeholder={
                        listening === "response"
                          ? "Listening… speak your explanation"
                          : "Type or speak your reasoning…"
                      }
                    />
                    {voiceNote?.target === "response" && (
                      <p className={`voice-note ${voiceNote.error ? "error" : ""}`} role="status">
                        {voiceNote.text}
                      </p>
                    )}
                    <div className="response-actions">
                      <Button variant="ghost" onClick={() => setShowHint((h) => !h)}>
                        <CircleHelp />
                        Hint
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        className={listening === "response" ? "listening" : ""}
                        aria-label={
                          listening === "response" ? "Stop dictation" : "Speak your answer"
                        }
                        aria-pressed={listening === "response"}
                        disabled={assessing}
                        onClick={() => dictate("response")}
                      >
                        {listening === "response" ? <MicOff /> : <Mic />}
                      </Button>
                      <Button onClick={submitAttempt} disabled={!response.trim() || assessing}>
                        {assessing ? "Assessing…" : result ? "Re-assess" : "Commit"}
                      </Button>
                    </div>
                    {showHint && (
                      <p className="feedback-text">
                        {stage.hint ??
                          "State the principle, connect it to this situation, then test your conclusion."}
                      </p>
                    )}
                    {result && (
                      <div
                        className={`assessment ${
                          result.label === "Strong"
                            ? "strong"
                            : result.label === "Developing"
                              ? "developing"
                              : "weak"
                        }`}
                        role="status"
                        aria-live="polite"
                      >
                        <div className="assessment-head">
                          <strong>{result.label}</strong>
                          <b>{result.score}%</b>
                        </div>
                        <Progress value={result.score} />
                        {result.strengths.length > 0 && (
                          <ul className="assessment-good">
                            {result.strengths.map((t, i) => (
                              <li key={i}>{t}</li>
                            ))}
                          </ul>
                        )}
                        {result.gaps.length > 0 && (
                          <ul className="assessment-gaps">
                            {result.gaps.map((t, i) => (
                              <li key={i}>{t}</li>
                            ))}
                          </ul>
                        )}
                        <p className="assessment-next">{result.next}</p>
                        <small className="assessment-meta">
                          {resultMeta ? `Mastery ${resultMeta.from}% → ${resultMeta.to}%` : ""}
                          {resultMeta && resultMeta.gain > 0 ? ` · +${resultMeta.gain} points` : ""}
                          {" · "}
                          {result.method === "ai"
                            ? "Assessed by AI against this lesson"
                            : "Quick rubric check: key ideas, reasoning, depth"}
                        </small>
                        <div className="assessment-actions">
                          <Button variant="ghost" onClick={() => setResult(null)}>
                            Revise
                          </Button>
                          {stageIndex < lastStage && (
                            <Button onClick={() => setStageIndex(stageIndex + 1)}>
                              Continue <ArrowRight />
                            </Button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </aside>
            </div>
            <div className="question-bar">
              <Hand />
              <Textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder={
                  listening === "question"
                    ? "Listening… speak your question"
                    : `Raise your hand to ask ${room.teacher.name} a question…`
                }
              />
              <Button
                size="icon"
                variant="ghost"
                className={listening === "question" ? "listening" : ""}
                aria-label={listening === "question" ? "Stop dictation" : "Speak question"}
                aria-pressed={listening === "question"}
                onClick={() => dictate("question")}
              >
                {listening === "question" ? <MicOff /> : <Mic />}
              </Button>
              <Button
                size="icon"
                onClick={ask}
                disabled={asking || !question.trim()}
                aria-label="Send question"
              >
                <Send />
              </Button>
            </div>
            {voiceNote?.target === "question" && (
              <p className={`voice-note ${voiceNote.error ? "error" : ""}`} role="status">
                {voiceNote.text}
              </p>
            )}
            {answer && (
              <div className="teacher-answer">
                <strong>{room.teacher.name}</strong>
                <p>{answer}</p>
                {!asking && usedSources !== null && (
                  <p className="grounding-note">
                    {usedSources.length
                      ? `Grounded in your material: ${usedSources.map((u) => `${u.name} · ${u.ref}`).join(", ")}`
                      : "Nothing in your uploaded material matched this question, so this answer uses general knowledge."}
                  </p>
                )}
                {!asking && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => (speakingNow ? stopSpeaking() : say(answer, "teacher"))}
                  >
                    {speakingNow ? <VolumeX /> : <Volume2 />}{" "}
                    {speakingNow ? "Stop" : "Read answer aloud"}
                  </Button>
                )}
              </div>
            )}
            <div className="concept-strip">
              {module.concepts.map((c, i) => (
                <Button
                  variant="ghost"
                  key={c.slug}
                  className={i === conceptIndex ? "active" : ""}
                  onClick={() => {
                    setConceptIndex(i);
                    setStageIndex(0);
                  }}
                >
                  <span>{i + 1}</span>
                  <div>
                    <strong>{c.title}</strong>
                    <small>
                      {c.bloom} · {masteryOf(module, c)}% mastery
                    </small>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        )}

        {panel === "library" && (
          <section
            className="page-view"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              void uploadMany(e.dataTransfer.files);
            }}
          >
            <div className="page-title">
              <div>
                <small>PERSONAL KNOWLEDGE BASE</small>
                <h1>Learn from your own material</h1>
                <p>
                  Bring slides, notes, readings or diagrams. AI KYRO turns them into a complete
                  classroom—not a summary.
                </p>
              </div>
              <input
                ref={inputRef}
                hidden
                multiple
                type="file"
                accept=".pdf,.pptx,.docx,.txt,.md,.png,.jpg,.jpeg,.webp"
                onChange={(e) => {
                  void uploadMany(e.target.files);
                  e.target.value = "";
                }}
              />
              <Button onClick={() => inputRef.current?.click()} disabled={uploading}>
                <Upload /> {uploading ? "Reading…" : "Upload material"}
              </Button>
            </div>
            <div className="module-composer">
              <h2>
                <Sparkles size={18} /> Add a module with AI
              </h2>
              <p>
                Describe a topic, and optionally attach your slides or notes. Speak instead of
                typing if you like.
              </p>
              {attachments.length > 0 && (
                <div className="attach-chips">
                  {attachments.map((f, i) => (
                    <span key={i}>
                      <FileText size={14} />
                      {f.name}
                      <button
                        aria-label={`Remove ${f.name}`}
                        onClick={() => setAttachments((a) => a.filter((_, j) => j !== i))}
                      >
                        <X size={12} />
                      </button>
                    </span>
                  ))}
                </div>
              )}
              <div className="composer-bar">
                <button
                  className="composer-icon"
                  aria-label="Attach files (optional)"
                  onClick={() => attachRef.current?.click()}
                >
                  <Plus />
                </button>
                <input
                  ref={attachRef}
                  hidden
                  multiple
                  type="file"
                  accept=".pdf,.pptx,.docx,.txt,.md,.png,.jpg,.jpeg,.webp"
                  onChange={(e) => {
                    const fs = Array.from(e.target.files ?? []);
                    setAttachments((a) => [...a, ...fs]);
                    e.target.value = "";
                  }}
                />
                <input
                  className="composer-input"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") generateModule();
                  }}
                  placeholder={
                    listening === "topic" ? "Listening…" : "e.g. Heat engines and the Carnot cycle"
                  }
                />
                <button
                  className={`composer-icon ${listening === "topic" ? "listening" : ""}`}
                  aria-label="Speak topic"
                  onClick={() => dictate("topic")}
                >
                  <Mic />
                </button>
                <button
                  className="composer-send"
                  aria-label="Generate module"
                  disabled={generating || (!topic.trim() && !attachments.length)}
                  onClick={generateModule}
                >
                  {generating ? <Clock3 /> : <ArrowRight />}
                </button>
              </div>
              {generating && (
                <small className="composer-note">Building your concept sequence…</small>
              )}
              {genError && <small className="composer-note error">{genError}</small>}
              {voiceNote?.target === "topic" && (
                <small className={`composer-note ${voiceNote.error ? "error" : ""}`} role="status">
                  {voiceNote.text}
                </small>
              )}
              {customModules.length > 0 && (
                <div className="custom-modules">
                  {customModules.map((m) => (
                    <article key={m.slug} className="material-card">
                      <Brain />
                      <div>
                        <small>
                          {m.code} · {m.concepts.length} CONCEPTS
                        </small>
                        <h3>{m.title}</h3>
                        <p>{m.description}</p>
                      </div>
                      <Button
                        onClick={() => {
                          selectModule(
                            Math.max(
                              0,
                              modules.findIndex((x) => x.slug === m.slug),
                            ),
                          );
                          setPanel("classroom");
                        }}
                      >
                        Start class
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        aria-label={`Delete ${m.title}`}
                        onClick={() => removeCustomModule(m.slug)}
                      >
                        <Trash2 />
                      </Button>
                    </article>
                  ))}
                </div>
              )}
            </div>
            {uploading && readMsg && (
              <p className="voice-note library-msg" role="status">
                {readMsg}
              </p>
            )}
            {matError && (
              <p className="voice-note error library-msg" role="alert">
                {matError}
              </p>
            )}
            {matNote && (
              <p className="voice-note library-msg" role="status">
                {matNote}
              </p>
            )}
            <div className="material-grid">
              {materials.map((m) => (
                <article key={m.id} className="material-card">
                  <FileText />
                  <div>
                    <small>
                      {m.local ? "ON THIS DEVICE" : m.status.toUpperCase()} ·{" "}
                      {m.sections?.length ?? 0} SECTIONS
                      {m.page_count ? ` · ${m.page_count} PAGES/SLIDES` : ""}
                      {m.sections?.some((x) => x.via === "ai") ? " · AI-READ" : ""}
                      {m.sections?.some((x) => x.via === "ocr") ? " · OCR" : ""}
                    </small>
                    <h3>{m.title}</h3>
                    <p>{m.extracted_summary}</p>
                    <span>{m.file_name}</span>
                  </div>
                  <div className="material-actions">
                    <Button onClick={() => buildClass(m)} disabled={buildingId !== null}>
                      {buildingId === m.id ? "Building…" : "Build class"}
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label={`Remove ${m.file_name}`}
                      onClick={() => removeMaterial(m)}
                    >
                      <Trash2 />
                    </Button>
                  </div>
                </article>
              ))}
              {!materials.length && (
                <div className="empty-material">
                  <Library />
                  <h3>Your materials will appear here</h3>
                  <p>
                    Upload a PDF, PowerPoint, Word, text file or image — including scans,
                    handwritten notes and diagrams. Text is read on your device; pages that need it
                    are sent to AI to read handwriting and describe figures. Sign in to keep it
                    across devices.
                  </p>
                </div>
              )}
            </div>
          </section>
        )}

        {panel === "progress" && (
          <section className="page-view">
            <div className="page-title">
              <div>
                <small>LEARNING EVIDENCE</small>
                <h1>Your understanding, not your streak</h1>
                <p>
                  Mastery grows from explanation, transfer and delayed recall—not from opening a
                  lesson.
                </p>
              </div>
            </div>
            <div className="metric-row">
              <div>
                <small>CONCEPTS ACTIVE</small>
                <strong>{activeConcepts.length}</strong>
                <span>
                  across {new Set(activeConcepts.map((x) => x.m.slug)).size} module
                  {new Set(activeConcepts.map((x) => x.m.slug)).size === 1 ? "" : "s"}
                </span>
              </div>
              <div>
                <small>READY TO REVIEW</small>
                <strong>{reviewConcepts.length}</strong>
                <span>mastery below 60%</span>
              </div>
              <div>
                <small>TRANSFER SCORE</small>
                <strong>{transferAvg === null ? "—" : `${transferAvg}%`}</strong>
                <span>
                  {transferScores.length
                    ? `${transferScores.length} transfer attempt${transferScores.length === 1 ? "" : "s"}`
                    : "answer a transfer task to see this"}
                </span>
              </div>
            </div>
            <div className="progress-board">
              {activeConcepts.map(({ m, c, v }) => (
                <article key={`${m.slug}:${c.slug}`}>
                  <div>
                    <strong>{c.title}</strong>
                    <span>{c.bloom}</span>
                  </div>
                  <Progress value={v} />
                  <b>{v}%</b>
                </article>
              ))}
            </div>
          </section>
        )}

        {authOpen && (
          <div className="modal-backdrop">
            <div className="auth-dialog">
              <Button
                size="icon"
                variant="ghost"
                className="modal-close"
                onClick={() => setAuthOpen(false)}
              >
                <X />
              </Button>
              <span className="brand-mark">AK</span>
              <h2>Keep your learning with you</h2>
              <p>
                Sign in to save materials, sessions, mastery and review schedules across devices.
              </p>
              <Button className="google" onClick={google}>
                Continue with Google
              </Button>
              <small>Your uploads remain private to your account.</small>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
