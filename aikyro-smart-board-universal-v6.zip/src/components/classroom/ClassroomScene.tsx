import { Canvas, useFrame, useThree } from "@react-three/fiber";
import {
  Billboard,
  Environment,
  Lightformer,
  RoundedBox,
  Text,
  useAnimations,
  useGLTF,
} from "@react-three/drei";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { clone as cloneSkinned } from "three/examples/jsm/utils/SkeletonUtils.js";
import * as THREE from "three";
import { addAccessories, applyLookMaterials } from "./avatar-look";
import { BoardVisual, type BoardTheme } from "./board-visuals";
import { planBoard, type BoardPlan } from "./board-topic";
import {
  ARJUN,
  MAYA,
  roomById,
  type Look,
  type RoomId,
  type RoomSpec,
  type Speaker,
} from "./personas";

export type { Speaker, RoomId } from "./personas";

const A = "CharacterArmature|";

/** Honour the OS "reduce motion" setting: the scene then renders on demand instead of animating. */
function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const on = () => setReduced(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return reduced;
}
type V3 = [number, number, number];

// ---------------------------------------------------------------- avatars
function Avatar({
  look,
  position,
  speaking,
  faceTo,
  name,
  active,
  seed = 0,
  scale,
}: {
  look: Look;
  position: V3;
  speaking: boolean;
  faceTo: [number, number];
  /** optional floating name tag */
  name?: string;
  active?: boolean;
  seed?: number;
  /** overrides look.scale (kept out of `look` so the look object stays referentially stable) */
  scale?: number;
}) {
  const { scene, animations } = useGLTF(`/models/${look.model}.glb`);
  const model = useMemo(() => {
    const c = cloneSkinned(scene);
    applyLookMaterials(c, look);
    addAccessories(c, look.accessories);
    return c;
  }, [scene, look]);
  const group = useRef<THREE.Group>(null);
  const { actions } = useAnimations(animations, group);
  useEffect(() => {
    const idle = actions[A + "Idle_Neutral"] ?? actions[A + "Idle"];
    if (!speaking) {
      idle?.reset().fadeIn(0.4).play();
      // de-synchronise background people so the room does not move in lockstep
      if (idle) idle.time = ((seed * 0.37) % 1) * idle.getClip().duration;
      return () => {
        idle?.fadeOut(0.4);
      };
    }
    const seq = [A + "Interact", A + "Idle", A + "Wave"];
    let i = 0;
    let cur = actions[seq[0]!];
    cur?.reset().fadeIn(0.35).play();
    const t = window.setInterval(() => {
      const next = actions[seq[++i % seq.length]!];
      if (next && next !== cur) {
        cur?.fadeOut(0.4);
        next.reset().fadeIn(0.4).play();
        cur = next;
      }
    }, 2600);
    return () => {
      window.clearInterval(t);
      cur?.fadeOut(0.4);
    };
  }, [speaking, actions, seed]);
  const rotY = Math.atan2(faceTo[0] - position[0], faceTo[1] - position[2]);
  const s = scale ?? look.scale ?? 1;
  return (
    <group ref={group} position={position} rotation-y={rotY} scale={s}>
      <primitive object={model} />
      {name && (
        <Billboard position={[0, 2.05, 0]}>
          <RoundedBox args={[Math.max(0.9, name.length * 0.115), 0.26, 0.02]} radius={0.06}>
            <meshBasicMaterial
              color={active ? "#f3b13e" : "#1d2733"}
              transparent
              opacity={active ? 0.95 : 0.7}
            />
          </RoundedBox>
          <Text
            position={[0, 0, 0.02]}
            fontSize={0.14}
            anchorX="center"
            anchorY="middle"
            color={active ? "#1d2733" : "#ffffff"}
          >
            {name}
          </Text>
        </Billboard>
      )}
    </group>
  );
}
(["teacher", "maya", "arjun"] as const).forEach((n) => useGLTF.preload(`/models/${n}.glb`));

// ---------------------------------------------------------------- furniture
function Desk({
  position,
  rotation = 0,
  wood = "#a8784f",
  metal = "#536874",
}: {
  position: V3;
  rotation?: number;
  wood?: string;
  metal?: string;
}) {
  return (
    <group position={position} rotation-y={rotation}>
      <RoundedBox args={[1.8, 0.16, 0.75]} radius={0.05} position={[0, 0.85, 0]} castShadow>
        <meshStandardMaterial color={wood} roughness={0.75} />
      </RoundedBox>
      {[-0.72, 0.72].flatMap((x) =>
        [-0.25, 0.25].map((z, i) => (
          <mesh key={`${x}-${i}`} position={[x, 0.4, z]} castShadow>
            <boxGeometry args={[0.1, 0.8, 0.1]} />
            <meshStandardMaterial color={metal} />
          </mesh>
        )),
      )}
    </group>
  );
}

function RoundTable({
  position,
  radius = 0.95,
  top = "#c9b08a",
}: {
  position: V3;
  radius?: number;
  top?: string;
}) {
  return (
    <group position={position}>
      <mesh position={[0, 0.86, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[radius, radius, 0.08, 40]} />
        <meshStandardMaterial color={top} roughness={0.6} />
      </mesh>
      <mesh position={[0, 0.42, 0]} castShadow>
        <cylinderGeometry args={[0.09, 0.09, 0.84, 12]} />
        <meshStandardMaterial color="#2d3640" metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.03, 0]}>
        <cylinderGeometry args={[0.45, 0.45, 0.05, 24]} />
        <meshStandardMaterial color="#2d3640" metalness={0.5} roughness={0.4} />
      </mesh>
    </group>
  );
}

function Plant({
  position,
  pot = "#253039",
  leaf = "#487963",
}: {
  position: V3;
  pot?: string;
  leaf?: string;
}) {
  return (
    <group position={position}>
      <mesh position={[0, 0.55, 0]}>
        <cylinderGeometry args={[0.46, 0.34, 1, 16]} />
        <meshStandardMaterial color={pot} />
      </mesh>
      <mesh position={[0, 1.45, 0]}>
        <sphereGeometry args={[0.65, 16, 12]} />
        <meshStandardMaterial color={leaf} roughness={0.9} />
      </mesh>
    </group>
  );
}

function CeilingLights({
  xs,
  y = 7.7,
  z = -1,
  color = "#fff6dd",
  len = 3,
}: {
  xs: number[];
  y?: number;
  z?: number;
  color?: string;
  len?: number;
}) {
  return (
    <>
      {xs.map((x) => (
        <mesh key={x} position={[x, y, z]}>
          <boxGeometry args={[0.5, 0.05, len]} />
          <meshBasicMaterial color={color} />
        </mesh>
      ))}
    </>
  );
}

function GridLines({
  w,
  h,
  step,
  color,
  opacity,
}: {
  w: number;
  h: number;
  step: number;
  color: string;
  opacity: number;
}) {
  const geo = useMemo(() => {
    const pts: number[] = [];
    for (let x = -w / 2; x <= w / 2 + 1e-6; x += step) pts.push(x, -h / 2, 0, x, h / 2, 0);
    for (let y = -h / 2; y <= h / 2 + 1e-6; y += step) pts.push(-w / 2, y, 0, w / 2, y, 0);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
    return g;
  }, [w, h, step]);
  return (
    <lineSegments geometry={geo}>
      <lineBasicMaterial color={color} transparent opacity={opacity} />
    </lineSegments>
  );
}

// ---------------------------------------------------------------- boards
const THEMES: Record<RoomSpec["board"], BoardTheme> = {
  "smart-green": {
    ink: "#f5f2e8",
    dim: "#b8cfc4",
    accents: ["#5b8fd6", "#2fa597", "#e0a447"],
    warn: "#ff7b6b",
  },
  "interactive-white": {
    ink: "#1d2733",
    dim: "#5c6a7a",
    accents: ["#3b6fc4", "#1f8a7e", "#c98a2b"],
    warn: "#d2483c",
  },
  holo: {
    ink: "#d8f6ff",
    dim: "#7fb4c7",
    accents: ["#2bd0e8", "#8b7cff", "#ffb64a"],
    warn: "#ff6b81",
  },
};

function BoardContent({
  plan,
  theme,
  title,
  status,
  headingColor,
}: {
  plan: BoardPlan;
  theme: BoardTheme;
  title: string;
  status: string;
  headingColor: string;
}) {
  const showCaption = plan.kind === "flow" || plan.kind === "energy";
  return (
    <group position={[0, 0, 0.12]}>
      <Text
        position={[0, 1.0, 0]}
        fontSize={0.26}
        maxWidth={7.2}
        textAlign="center"
        anchorX="center"
        anchorY="middle"
        color={headingColor}
      >
        {plan.heading}
      </Text>
      <BoardVisual plan={plan} theme={theme} />
      {showCaption && (
        <Text
          position={[0, -1.0, 0]}
          fontSize={0.2}
          maxWidth={7}
          textAlign="center"
          anchorX="center"
          anchorY="middle"
          color={theme.ink}
        >
          {plan.caption}
        </Text>
      )}
      <Text
        position={[-3.85, 1.43, -0.02]}
        fontSize={0.11}
        anchorX="left"
        anchorY="middle"
        color={theme.dim}
      >
        {`●  ${title}`}
      </Text>
      <Text
        position={[3.85, 1.43, -0.02]}
        fontSize={0.11}
        anchorX="right"
        anchorY="middle"
        color={theme.dim}
      >
        {status}
      </Text>
    </group>
  );
}

/** Dark-green smart board: aluminium bezel, glowing panel, pen tray and a floating toolbar. */
function GreenSmartBoard({ plan, concept }: { plan: BoardPlan; concept: string }) {
  const theme = THEMES["smart-green"];
  return (
    <group position={[0, 3.6, -4.7]}>
      <RoundedBox args={[8.5, 3.55, 0.2]} radius={0.06} position={[0, 0, -0.06]} castShadow>
        <meshStandardMaterial color="#b9c2c8" metalness={0.6} roughness={0.35} />
      </RoundedBox>
      <mesh position={[0, 0, 0.06]}>
        <boxGeometry args={[8.1, 3.15, 0.05]} />
        <meshStandardMaterial
          color="#134236"
          emissive="#0f4a39"
          emissiveIntensity={0.55}
          roughness={0.55}
        />
      </mesh>
      <mesh position={[0, 1.5, 0.092]}>
        <boxGeometry args={[8.1, 0.3, 0.02]} />
        <meshStandardMaterial color="#0b2e25" emissive="#0b2e25" emissiveIntensity={0.4} />
      </mesh>
      <group position={[0, 0, 0.09]}>
        <GridLines w={8} h={3} step={0.5} color="#9fd8c4" opacity={0.07} />
      </group>
      <BoardContent
        plan={plan}
        theme={theme}
        title={`SMART BOARD · ${concept.toUpperCase().slice(0, 40)}`}
        status="LIVE"
        headingColor="#fff3b0"
      />
      <RoundedBox args={[1.9, 0.24, 0.04]} radius={0.1} position={[0, -1.36, 0.12]}>
        <meshStandardMaterial color="#0b2e25" emissive="#0b2e25" emissiveIntensity={0.4} />
      </RoundedBox>
      {["#ff7b6b", "#ffd166", "#6fd3a5", "#6aa6ff"].map((c, i) => (
        <mesh key={c} position={[-0.65 + i * 0.43, -1.36, 0.15]}>
          <circleGeometry args={[0.07, 16]} />
          <meshBasicMaterial color={c} />
        </mesh>
      ))}
      {/* pen tray */}
      <mesh position={[0, -1.82, 0.16]}>
        <boxGeometry args={[4.6, 0.1, 0.28]} />
        <meshStandardMaterial color="#9aa3a9" metalness={0.5} roughness={0.4} />
      </mesh>
      {["#ff7b6b", "#ffd166", "#6aa6ff"].map((c, i) => (
        <mesh key={c} position={[-0.8 + i * 0.5, -1.74, 0.18]} rotation-z={Math.PI / 2}>
          <cylinderGeometry args={[0.035, 0.035, 0.4, 10]} />
          <meshStandardMaterial color={c} />
        </mesh>
      ))}
      <mesh position={[1.4, -1.73, 0.18]}>
        <boxGeometry args={[0.38, 0.1, 0.14]} />
        <meshStandardMaterial color="#e8e4d8" />
      </mesh>
      <pointLight position={[0, 0, 1.5]} color="#7ee0b9" intensity={1.2} distance={8} />
    </group>
  );
}

/** White interactive display with slim black bezel and a light UI bar. */
function WhiteDisplay({ plan, concept }: { plan: BoardPlan; concept: string }) {
  const theme = THEMES["interactive-white"];
  return (
    <group position={[0, 3.55, -4.7]}>
      <RoundedBox args={[8.7, 3.5, 0.16]} radius={0.05} position={[0, 0, -0.05]} castShadow>
        <meshStandardMaterial color="#1b1f26" roughness={0.4} metalness={0.3} />
      </RoundedBox>
      <mesh position={[0, 0, 0.05]}>
        <boxGeometry args={[8.4, 3.2, 0.04]} />
        <meshStandardMaterial
          color="#f6f7f9"
          emissive="#ffffff"
          emissiveIntensity={0.5}
          roughness={0.4}
        />
      </mesh>
      <mesh position={[0, 1.5, 0.075]}>
        <boxGeometry args={[8.4, 0.3, 0.015]} />
        <meshStandardMaterial color="#e1e6ec" emissive="#e1e6ec" emissiveIntensity={0.3} />
      </mesh>
      <BoardContent
        plan={plan}
        theme={theme}
        title={`INTERACTIVE DISPLAY · ${concept.toUpperCase().slice(0, 36)}`}
        status="LIVE"
        headingColor="#1d2733"
      />
      {/* dock */}
      <RoundedBox args={[2.4, 0.22, 0.03]} radius={0.1} position={[0, -1.42, 0.11]}>
        <meshStandardMaterial color="#d9dee5" />
      </RoundedBox>
      {["#3b6fc4", "#1f8a7e", "#c98a2b", "#d2483c", "#6b5bd6"].map((c, i) => (
        <mesh key={c} position={[-0.8 + i * 0.4, -1.42, 0.135]}>
          <circleGeometry args={[0.07, 16]} />
          <meshBasicMaterial color={c} />
        </mesh>
      ))}
      <mesh position={[0, 1.95, 0.0]}>
        <boxGeometry args={[1.2, 0.12, 0.22]} />
        <meshStandardMaterial color="#cfd5dc" metalness={0.4} roughness={0.4} />
      </mesh>
    </group>
  );
}

/** Dark glass holographic panel with glowing cyan border. */
function HoloPanel({ plan, concept }: { plan: BoardPlan; concept: string }) {
  const theme = THEMES.holo;
  const edge = "#2bd0e8";
  const W = 8.2;
  const H = 3.3;
  return (
    <group position={[0, 3.6, -4.55]}>
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[W, H, 0.06]} />
        <meshStandardMaterial
          color="#071322"
          emissive="#0a2b40"
          emissiveIntensity={0.55}
          roughness={0.2}
          metalness={0.4}
        />
      </mesh>
      <group position={[0, 0, 0.04]}>
        <GridLines w={W - 0.3} h={H - 0.3} step={0.4} color="#2bd0e8" opacity={0.1} />
      </group>
      {[
        [0, H / 2, W, 0.045],
        [0, -H / 2, W, 0.045],
        [-W / 2, 0, 0.045, H],
        [W / 2, 0, 0.045, H],
      ].map(([x, y, w, h], i) => (
        <mesh key={i} position={[x ?? 0, y ?? 0, 0.04]}>
          <boxGeometry args={[w ?? 0, h ?? 0, 0.03]} />
          <meshBasicMaterial color={edge} />
        </mesh>
      ))}
      <BoardContent
        plan={plan}
        theme={theme}
        title={`HOLO PANEL · ${concept.toUpperCase().slice(0, 40)}`}
        status="LIVE"
        headingColor="#9ff0ff"
      />
      {/* wall standoffs */}
      {[-3.6, 3.6].map((x) => (
        <mesh key={x} position={[x, 0, -0.25]}>
          <cylinderGeometry args={[0.06, 0.06, 0.4, 10]} />
          <meshStandardMaterial color="#53606a" metalness={0.7} roughness={0.3} />
        </mesh>
      ))}
      <pointLight position={[0, 0, 1.8]} color="#47d8ee" intensity={1.8} distance={9} />
    </group>
  );
}

// ---------------------------------------------------------------- rooms
const roomFloor = (color: string, rough = 0.95) => (
  <mesh rotation-x={-Math.PI / 2} receiveShadow>
    <planeGeometry args={[18, 20]} />
    <meshStandardMaterial color={color} roughness={rough} />
  </mesh>
);
const backWall = (color: string) => (
  <mesh position={[0, 4, -5]} receiveShadow>
    <boxGeometry args={[18, 8, 0.2]} />
    <meshStandardMaterial color={color} />
  </mesh>
);

function GreenHallRoom({ plan, concept }: { plan: BoardPlan; concept: string }) {
  return (
    <>
      {roomFloor("#805d3d")}
      {backWall("#d8d1bf")}
      {/* skirting */}
      <mesh position={[0, 0.12, -4.88]}>
        <boxGeometry args={[18, 0.24, 0.06]} />
        <meshStandardMaterial color="#8a6d4d" />
      </mesh>
      {/* window + mullions */}
      <mesh position={[-6.1, 3.9, -4.75]}>
        <boxGeometry args={[2.35, 3.7, 0.12]} />
        <meshStandardMaterial color="#a9d9df" emissive="#a9d9df" emissiveIntensity={0.25} />
      </mesh>
      <mesh position={[-6.1, 3.9, -4.58]}>
        <boxGeometry args={[0.08, 3.7, 0.05]} />
        <meshStandardMaterial color="#253039" />
      </mesh>
      <mesh position={[-6.1, 3.9, -4.58]}>
        <boxGeometry args={[2.35, 0.08, 0.05]} />
        <meshStandardMaterial color="#253039" />
      </mesh>
      {/* door */}
      <mesh position={[6.2, 2.1, -4.68]}>
        <boxGeometry args={[1.25, 2.6, 0.16]} />
        <meshStandardMaterial color="#a8784f" />
      </mesh>
      <mesh position={[6.2, 2.1, -4.52]}>
        <boxGeometry args={[1.03, 2.25, 0.04]} />
        <meshStandardMaterial color="#253039" />
      </mesh>
      {/* wall clock */}
      <mesh position={[5.1, 5.6, -4.86]}>
        <cylinderGeometry args={[0.38, 0.38, 0.06, 28]} />
        <meshStandardMaterial color="#f5f2e8" />
      </mesh>
      <mesh position={[5.1, 5.6, -4.82]} rotation-x={Math.PI / 2}>
        <torusGeometry args={[0.38, 0.03, 8, 28]} />
        <meshStandardMaterial color="#253039" />
      </mesh>
      {/* teacher's side table */}
      <Desk position={[4.0, 0, -3.9]} rotation={0} />
      <CeilingLights xs={[-3, 0, 3]} />
      <GreenSmartBoard plan={plan} concept={concept} />
      <Plant position={[-6.4, 0, -2.7]} />
    </>
  );
}

function LectureRoom({ plan, concept }: { plan: BoardPlan; concept: string }) {
  const slats = Array.from({ length: 16 }, (_, i) => i);
  return (
    <>
      {roomFloor("#46556a", 1)}
      {backWall("#e6e9ee")}
      {/* acoustic wood slat panels either side of the display */}
      {[-1, 1].flatMap((side) =>
        slats.map((i) => (
          <mesh key={`${side}-${i}`} position={[side * (5.15 + i * 0.22), 3.4, -4.86]}>
            <boxGeometry args={[0.12, 5.4, 0.1]} />
            <meshStandardMaterial color={i % 3 === 0 ? "#a77949" : "#b88b5a"} />
          </mesh>
        )),
      )}
      {/* tiered seating platforms */}
      <mesh position={[0, 0.21, 3.1]} receiveShadow castShadow>
        <boxGeometry args={[9.5, 0.42, 2.6]} />
        <meshStandardMaterial color="#5c6b82" roughness={0.95} />
      </mesh>
      <mesh position={[0, 0.42, 5.5]} receiveShadow castShadow>
        <boxGeometry args={[9.5, 0.84, 2.2]} />
        <meshStandardMaterial color="#667690" roughness={0.95} />
      </mesh>
      {/* lectern + laptop */}
      <group position={[3.6, 0, -3.05]}>
        <RoundedBox args={[1.0, 1.15, 0.6]} radius={0.04} position={[0, 0.58, 0]} castShadow>
          <meshStandardMaterial color="#8a6234" roughness={0.6} />
        </RoundedBox>
        <mesh position={[0, 1.2, 0.02]} rotation-x={-0.25}>
          <boxGeometry args={[0.55, 0.03, 0.4]} />
          <meshStandardMaterial color="#c3c8cf" metalness={0.5} roughness={0.4} />
        </mesh>
      </group>
      <CeilingLights xs={[-4, -1.3, 1.3, 4]} color="#eef6ff" />
      <WhiteDisplay plan={plan} concept={concept} />
      <Plant position={[-6.6, 0, -3.2]} pot="#3a4658" leaf="#3f8a64" />
      <Plant position={[6.6, 0, -3.2]} pot="#3a4658" leaf="#3f8a64" />
    </>
  );
}

function StudioRoom({ plan, concept }: { plan: BoardPlan; concept: string }) {
  const books = useMemo(() => {
    const r = [0x6ea8d8, 0xe0a447, 0xd8695f, 0x7bb894, 0xb59bd6, 0xe8e1d0];
    return Array.from({ length: 30 }, (_, i) => ({
      c: r[i % r.length] ?? 0xffffff,
      h: 0.32 + ((i * 37) % 9) * 0.02,
      row: Math.floor(i / 10),
      col: i % 10,
    }));
  }, []);
  return (
    <>
      {roomFloor("#6a6f74", 0.85)}
      {backWall("#202a33")}
      {/* warm wood slat feature wall behind the panel */}
      <mesh position={[0, 4, -4.88]}>
        <boxGeometry args={[9.6, 6.6, 0.06]} />
        <meshStandardMaterial color="#6b4a2f" roughness={0.8} />
      </mesh>
      {/* tall window, right of the panel */}
      <mesh position={[6.4, 3.7, -4.82]}>
        <boxGeometry args={[2.6, 5.4, 0.1]} />
        <meshStandardMaterial color="#26435f" emissive="#3a6a93" emissiveIntensity={0.55} />
      </mesh>
      <mesh position={[6.4, 3.7, -4.75]}>
        <boxGeometry args={[0.07, 5.4, 0.05]} />
        <meshStandardMaterial color="#10161c" />
      </mesh>
      {/* bookshelf, left of the panel */}
      <group position={[-6.4, 0, -4.55]}>
        <mesh position={[0, 2.2, 0]}>
          <boxGeometry args={[3.0, 4.4, 0.5]} />
          <meshStandardMaterial color="#3a2c22" />
        </mesh>
        {books.map((b, i) => (
          <mesh key={i} position={[-1.25 + b.col * 0.28, 0.8 + b.row * 1.25 + b.h / 2, 0.15]}>
            <boxGeometry args={[0.24, b.h + 0.1, 0.3]} />
            <meshStandardMaterial color={b.c} />
          </mesh>
        ))}
      </group>
      {/* rug */}
      <mesh position={[0, 0.02, 0.2]} rotation-x={-Math.PI / 2}>
        <circleGeometry args={[5.2, 48]} />
        <meshStandardMaterial color="#3b4b5c" roughness={1} />
      </mesh>
      {/* tables */}
      <RoundTable position={[-2.8, 0, -0.2]} />
      <RoundTable position={[2.8, 0, -0.2]} />
      <RoundTable position={[-3.55, 0, 1.75]} radius={0.7} top="#b89d78" />
      <RoundTable position={[3.55, 0, 1.75]} radius={0.7} top="#b89d78" />
      {/* teacher's stool + pendant lamps */}
      {[-3, 0, 3].map((x) => (
        <group key={x} position={[x, 7, -1]}>
          <mesh position={[0, 0.4, 0]}>
            <cylinderGeometry args={[0.012, 0.012, 1.6, 6]} />
            <meshBasicMaterial color="#111" />
          </mesh>
          <mesh>
            <sphereGeometry args={[0.28, 16, 12]} />
            <meshBasicMaterial color="#ffd9a0" />
          </mesh>
          <pointLight color="#ffcf8f" intensity={1.4} distance={9} position={[0, -0.3, 0]} />
        </group>
      ))}
      <HoloPanel plan={plan} concept={concept} />
      <Plant position={[-4.9, 0, -3.6]} pot="#2a3138" leaf="#3d7a5b" />
    </>
  );
}

function CameraRig({
  speaker,
  teacherX,
  reduced,
}: {
  speaker: Speaker;
  teacherX: number;
  reduced: boolean;
}) {
  const { camera, invalidate } = useThree();
  useEffect(() => {
    if (!reduced) return;
    // No gliding: jump straight to the new shot and draw one frame.
    const p =
      speaker === "teacher"
        ? [0, 3.1, 8.8]
        : speaker === "maya"
          ? [-1.2, 2.3, -1.9]
          : [1.2, 2.3, -1.9];
    const l =
      speaker === "teacher"
        ? [teacherX * 0.3, 2.2, -2]
        : speaker === "maya"
          ? [-2.8, 1.45, 0.55]
          : [2.8, 1.45, 0.55];
    camera.position.set(p[0] ?? 0, p[1] ?? 0, p[2] ?? 0);
    camera.lookAt(l[0] ?? 0, l[1] ?? 0, l[2] ?? 0);
    invalidate();
  }, [reduced, speaker, teacherX, camera, invalidate]);
  useFrame((_, delta) => {
    if (reduced) return;
    const target =
      speaker === "teacher"
        ? new THREE.Vector3(0, 3.1, 8.8)
        : speaker === "maya"
          ? new THREE.Vector3(-1.2, 2.3, -1.9)
          : new THREE.Vector3(1.2, 2.3, -1.9);
    camera.position.lerp(target, 1 - Math.exp(-1.5 * Math.min(delta, 0.05)));
    const lookAt =
      speaker === "teacher"
        ? new THREE.Vector3(teacherX * 0.3, 2.2, -2)
        : speaker === "maya"
          ? new THREE.Vector3(-2.8, 1.45, 0.55)
          : new THREE.Vector3(2.8, 1.45, 0.55);
    camera.lookAt(lookAt);
  });
  return null;
}

const ROOM_STYLE: Record<
  RoomId,
  { wall: string; fog: [number, number]; ambient: number; sun: number; sunColor: string }
> = {
  "green-hall": { wall: "#d8d1bf", fog: [14, 30], ambient: 0.65, sun: 1.6, sunColor: "#ffffff" },
  "lecture-theatre": {
    wall: "#e6e9ee",
    fog: [16, 34],
    ambient: 0.75,
    sun: 1.2,
    sunColor: "#f2f6ff",
  },
  studio: { wall: "#202a33", fog: [12, 26], ambient: 0.4, sun: 0.7, sunColor: "#ffe2b8" },
};

function Room({
  room,
  speaker,
  plan,
  concept,
  reduced,
}: {
  room: RoomSpec;
  speaker: Speaker;
  plan: BoardPlan;
  concept: string;
  reduced: boolean;
}) {
  const st = ROOM_STYLE[room.id];
  return (
    <>
      <CameraRig speaker={speaker} teacherX={room.teacherPosition[0]} reduced={reduced} />
      <color attach="background" args={[st.wall]} />
      <fog attach="fog" args={[st.wall, st.fog[0], st.fog[1]]} />
      <ambientLight intensity={st.ambient} />
      <directionalLight
        position={[5, 10, 7]}
        intensity={st.sun}
        color={st.sunColor}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />
      <Environment>
        <Lightformer
          intensity={room.id === "studio" ? 0.8 : 2}
          position={[0, 7, 0]}
          scale={[12, 12, 1]}
        />
        <Lightformer
          intensity={1}
          color="#a9d9df"
          position={[-7, 4, 0]}
          rotation-y={Math.PI / 2}
          scale={[7, 4, 1]}
        />
      </Environment>

      {room.id === "green-hall" && <GreenHallRoom plan={plan} concept={concept} />}
      {room.id === "lecture-theatre" && <LectureRoom plan={plan} concept={concept} />}
      {room.id === "studio" && <StudioRoom plan={plan} concept={concept} />}

      {/* Desks for the two main learners (the studio uses round tables instead) */}
      {room.id !== "studio" && (
        <>
          <Desk position={[-2.8, 0, -0.2]} rotation={-0.06} />
          <Desk position={[2.8, 0, -0.2]} rotation={0.06} />
        </>
      )}

      {/* The teacher — a different person in every classroom */}
      <Avatar
        look={room.teacher.look}
        position={room.teacherPosition}
        speaking={speaker === "teacher"}
        faceTo={[0, 6]}
        name={room.teacher.name}
        active={speaker === "teacher"}
        seed={1}
      />
      <Avatar
        look={MAYA.look}
        position={[-2.8, 0, 0.55]}
        speaking={speaker === "maya"}
        faceTo={[0, -3.2]}
        name={MAYA.name}
        active={speaker === "maya"}
        seed={2}
      />
      <Avatar
        look={ARJUN.look}
        position={[2.8, 0, 0.55]}
        speaking={speaker === "arjun"}
        faceTo={[0, -3.2]}
        name={ARJUN.name}
        active={speaker === "arjun"}
        seed={3}
      />

      {/* Background classmates + their desks */}
      {room.classmates.map((c, i) => (
        <group key={i}>
          {room.id !== "studio" && (
            <Desk position={[c.position[0], c.position[1], c.position[2] - 0.75]} />
          )}
          <Avatar
            look={c.look}
            {...(c.scale !== undefined ? { scale: c.scale } : {})}
            position={c.position}
            speaking={false}
            faceTo={[0, -3.2]}
            seed={i + 4}
          />
        </group>
      ))}
    </>
  );
}

export function ClassroomScene({
  speaker,
  roomId,
  board,
  moduleTitle,
  conceptTitle,
  lessonText = "",
}: {
  speaker: Speaker;
  roomId: RoomId;
  board: string;
  moduleTitle: string;
  conceptTitle: string;
  lessonText?: string;
}) {
  const reduced = usePrefersReducedMotion();
  return (
    <Canvas
      shadows
      frameloop={reduced ? "demand" : "always"}
      dpr={[1, 1.5]}
      camera={{ position: [0, 3.1, 8.8], fov: 48 }}
      gl={{ antialias: true }}
    >
      <Suspense fallback={null}>
        <ClassroomWorld
          speaker={speaker}
          roomId={roomId}
          board={board}
          moduleTitle={moduleTitle}
          conceptTitle={conceptTitle}
          lessonText={lessonText}
          reduced={reduced}
        />
      </Suspense>
    </Canvas>
  );
}

/** Everything that lives inside the Canvas (exported so it can be rendered headlessly in tests). */
export function ClassroomWorld({
  speaker,
  roomId,
  board,
  moduleTitle,
  conceptTitle,
  lessonText = "",
  reduced = false,
}: {
  speaker: Speaker;
  roomId: RoomId;
  board: string;
  moduleTitle: string;
  conceptTitle: string;
  lessonText?: string;
  reduced?: boolean;
}) {
  const room = roomById(roomId);
  const plan = useMemo(
    () => planBoard({ moduleTitle, conceptTitle, board, lessonText }),
    [moduleTitle, conceptTitle, board, lessonText],
  );
  return (
    <Room room={room} speaker={speaker} plan={plan} concept={conceptTitle} reduced={reduced} />
  );
}
