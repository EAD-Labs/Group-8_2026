/**
 * Regression tests for the grading trust boundary. They run against the hosted database
 * as a real signed-in learner (session file from `lovable auth-session`). Every write
 * attempted here must be refused, so the tests never change learner records.
 */
import { describe, it, expect, beforeAll } from "vitest";
import { readFileSync, existsSync } from "node:fs";
import { homedir } from "node:os";

const SESSION = `${homedir()}/.cache/lovable-auth/session.json`;
const env = Object.fromEntries(readFileSync(".env", "utf8").split("\n").filter(l => l.includes("=")).map(l => { const i = l.indexOf("="); return [l.slice(0, i).trim(), l.slice(i + 1).trim().replace(/^"|"$/g, "")]; }));
const URL_ = env.VITE_SUPABASE_URL; const KEY = env.VITE_SUPABASE_PUBLISHABLE_KEY;
const has = existsSync(SESSION);
const S = has ? JSON.parse(readFileSync(SESSION, "utf8")) : null;
const H = () => ({ apikey: KEY, Authorization: `Bearer ${S.session.access_token}`, "content-type": "application/json", Prefer: "return=representation" });
const rest = (path: string, init: RequestInit = {}) => fetch(`${URL_}/rest/v1/${path}`, { ...init, headers: { ...H(), ...(init.headers ?? {}) } });

describe.skipIf(!has)("grading trust boundary", () => {
  let attempt: { id: string; score: number | null; session_id: string; concept_slug: string; module_slug: string; stage_index: number };
  let points: number;
  beforeAll(async () => {
    const a = await (await rest("assessment_attempts?select=id,score,session_id,concept_slug,module_slug,stage_index&grading_status=eq.graded&order=created_at.desc&limit=1")).json();
    attempt = a[0];
    points = (await (await rest(`profiles?select=points&id=eq.${S.user_id}`)).json())[0].points;
  });

  it("learner cannot change a stored score", async () => {
    expect((await rest(`assessment_attempts?id=eq.${attempt.id}`, { method: "PATCH", body: JSON.stringify({ score: 100 }) })).status).toBe(403);
  });
  it("learner cannot insert a pre-graded answer", async () => {
    const r = await rest("assessment_attempts", { method: "POST", body: JSON.stringify({ user_id: S.user_id, concept_slug: "x", assessment_type: "checkpoint", response_text: "x", score: 100, grading_status: "graded" }) });
    expect(r.status).toBe(403);
  });
  it("learner cannot mark an answer as measured", async () => {
    expect((await rest(`assessment_attempts?id=eq.${attempt.id}`, { method: "PATCH", body: JSON.stringify({ measured_at: new Date().toISOString() }) })).status).toBe(403);
  });
  it("learner cannot delete evidence", async () => {
    expect((await rest(`assessment_attempts?id=eq.${attempt.id}`, { method: "DELETE" })).status).toBe(403);
  });
  it("answers must belong to the learner's own session", async () => {
    const r = await rest("assessment_attempts", { method: "POST", body: JSON.stringify({ user_id: S.user_id, session_id: "00000000-0000-0000-0000-000000000000", concept_slug: "x", assessment_type: "checkpoint", response_text: "x" }) });
    expect(r.status).toBe(400);
    expect(await r.text()).toContain("session does not belong to learner");
  });
  it("cannot answer as another learner", async () => {
    const r = await rest("assessment_attempts", { method: "POST", body: JSON.stringify({ user_id: "00000000-0000-0000-0000-000000000001", concept_slug: "x", assessment_type: "checkpoint", response_text: "x" }) });
    expect(r.status).toBe(403);
  });
  it("a revision must link to the same question", async () => {
    const r = await rest("assessment_attempts", { method: "POST", body: JSON.stringify({ user_id: S.user_id, session_id: attempt.session_id, module_slug: attempt.module_slug, concept_slug: attempt.concept_slug, stage_index: attempt.stage_index + 1, assessment_type: "checkpoint", response_text: "x", revises_attempt_id: attempt.id }) });
    expect(r.status).toBe(400);
    expect(await r.text()).toContain("revision must link");
  });
  it("learner cannot set points", async () => {
    expect((await rest(`profiles?id=eq.${S.user_id}`, { method: "PATCH", body: JSON.stringify({ points: 9999 }) })).status).toBe(403);
  });
  it("learner cannot award points", async () => {
    expect((await rest("point_awards", { method: "POST", body: JSON.stringify({ user_id: S.user_id, award_key: "forged", points: 500, reason: "x" }) })).status).toBe(403);
  });
  it("learner cannot change mastery", async () => {
    expect((await rest(`concept_mastery?user_id=eq.${S.user_id}`, { method: "PATCH", body: JSON.stringify({ mastery_score: 100, mastery_state: "mastered" }) })).status).toBe(403);
  });
  it("learner cannot close a learning gap", async () => {
    expect((await rest(`learning_gaps?user_id=eq.${S.user_id}`, { method: "PATCH", body: JSON.stringify({ status: "resolved" }) })).status).toBe(403);
  });
  it("learner cannot run measurement directly", async () => {
    expect((await rest("rpc/apply_attempt_measurement", { method: "POST", body: JSON.stringify({ _attempt_id: attempt.id }) })).status).toBe(403);
  });
  it("learner cannot write an AI module's grading reference", async () => {
    expect((await rest("custom_modules", { method: "POST", body: JSON.stringify({ user_id: S.user_id, slug: "custom-forged", title: "x", concepts: [] }) })).status).toBe(403);
  });
  it("cannot read or change another learner's records", async () => {
    const other = "00000000-0000-0000-0000-000000000001";
    const read = await (await rest(`assessment_attempts?select=id&user_id=neq.${S.user_id}`)).json();
    expect(read).toEqual([]);
    const r = await rest(`learning_sessions?user_id=eq.${other}`, { method: "PATCH", body: JSON.stringify({ completed: true }) });
    expect(await r.json()).toEqual([]);
  });
  it("points equal the ledger and each question pays at most once", async () => {
    const awards: { award_key: string; points: number }[] = await (await rest(`point_awards?select=award_key,points&user_id=eq.${S.user_id}`)).json();
    expect(new Set(awards.map(a => a.award_key)).size).toBe(awards.length);
    expect(awards.reduce((t, a) => t + a.points, 0)).toBe(points);
  });
  it("stored score is unchanged after all attempts", async () => {
    const a = await (await rest(`assessment_attempts?select=score&id=eq.${attempt.id}`)).json();
    expect(a[0].score).toBe(attempt.score);
  });
});
