CREATE TABLE public.custom_modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  concepts jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.custom_modules TO authenticated;
GRANT ALL ON public.custom_modules TO service_role;
ALTER TABLE public.custom_modules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Learners read own modules" ON public.custom_modules FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE INDEX custom_modules_user ON public.custom_modules (user_id);

-- Measurement ignores AI-module answers unless the module is server-held for that learner.
CREATE OR REPLACE FUNCTION public.measurement_trusted(_user_id uuid, _module_slug text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT _module_slug NOT LIKE 'custom-%'
      OR EXISTS (SELECT 1 FROM public.custom_modules m WHERE m.slug = _module_slug AND m.user_id = _user_id)
$$;
REVOKE ALL ON FUNCTION public.measurement_trusted(uuid, text) FROM public, anon, authenticated;