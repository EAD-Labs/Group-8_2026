ALTER TABLE public.assessment_attempts ADD COLUMN IF NOT EXISTS revises_attempt_id uuid REFERENCES public.assessment_attempts(id) ON DELETE SET NULL;
ALTER TABLE public.assessment_attempts ADD COLUMN IF NOT EXISTS measured_at timestamptz;
ALTER TABLE public.concept_mastery ADD COLUMN IF NOT EXISTS mastery_state text NOT NULL DEFAULT 'in_progress';
ALTER TABLE public.concept_mastery ADD COLUMN IF NOT EXISTS evidence_count integer NOT NULL DEFAULT 0;
ALTER TABLE public.concept_mastery ADD COLUMN IF NOT EXISTS last_evidence_at timestamptz;

CREATE TABLE public.learning_gaps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  module_slug text NOT NULL,
  concept_slug text NOT NULL,
  gap_key text NOT NULL,
  kind text NOT NULL,
  description text NOT NULL,
  next_step text,
  source_attempt_id uuid REFERENCES public.assessment_attempts(id) ON DELETE SET NULL,
  latest_attempt_id uuid REFERENCES public.assessment_attempts(id) ON DELETE SET NULL,
  evidence_count integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'open',
  resolved_at timestamptz,
  resolved_by_attempt_id uuid REFERENCES public.assessment_attempts(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.learning_gaps TO authenticated;
GRANT ALL ON public.learning_gaps TO service_role;
ALTER TABLE public.learning_gaps ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Learners read own gaps" ON public.learning_gaps FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE UNIQUE INDEX learning_gaps_one_open ON public.learning_gaps (user_id, module_slug, concept_slug, gap_key) WHERE status = 'open';
CREATE TRIGGER learning_gaps_updated_at BEFORE UPDATE ON public.learning_gaps FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.point_awards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  award_key text NOT NULL,
  attempt_id uuid REFERENCES public.assessment_attempts(id) ON DELETE SET NULL,
  points integer NOT NULL,
  reason text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, award_key)
);
GRANT SELECT ON public.point_awards TO authenticated;
GRANT ALL ON public.point_awards TO service_role;
ALTER TABLE public.point_awards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Learners read own awards" ON public.point_awards FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Points can only change through the measurement function.
CREATE OR REPLACE FUNCTION public.guard_profile_points() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.points IS DISTINCT FROM OLD.points AND coalesce(current_setting('app.points_writer', true), '') <> 'on' THEN
    NEW.points := OLD.points;
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER profiles_guard_points BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.guard_profile_points();

CREATE OR REPLACE FUNCTION public.apply_attempt_measurement(_attempt_id uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  a public.assessment_attempts%ROWTYPE;
  first_time boolean;
  misc text; nstep text; missed text;
  avg_score numeric; n_q integer; last_at timestamptz; open_gaps integer; state text;
  pts integer; total integer; cnt integer;
BEGIN
  SELECT * INTO a FROM public.assessment_attempts WHERE id = _attempt_id;
  IF a.id IS NULL OR a.user_id IS DISTINCT FROM auth.uid() THEN RAISE EXCEPTION 'attempt not found'; END IF;
  IF a.status <> 'answered' OR a.grading_status <> 'graded' OR a.score IS NULL
     OR a.assessment_type NOT IN ('prediction','checkpoint','teach_back') OR a.module_slug IS NULL OR a.stage_index IS NULL THEN
    RETURN jsonb_build_object('applied', false);
  END IF;
  first_time := a.measured_at IS NULL;
  misc := nullif(trim(a.feedback->>'misconception'), '');
  nstep := nullif(trim(a.feedback->>'next_step'), '');
  missed := a.feedback->'rubric_missed'->>0;

  IF first_time THEN
    -- Gaps
    IF a.score < 85 AND misc IS NOT NULL THEN
      UPDATE public.learning_gaps SET description = misc, next_step = nstep, latest_attempt_id = a.id, evidence_count = evidence_count + 1
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'misconception:' || a.stage_index AND status = 'open';
      IF NOT FOUND THEN
        INSERT INTO public.learning_gaps (user_id, module_slug, concept_slug, gap_key, kind, description, next_step, source_attempt_id, latest_attempt_id)
        VALUES (a.user_id, a.module_slug, a.concept_slug, 'misconception:' || a.stage_index, 'misconception', misc, nstep, a.id, a.id);
      END IF;
    END IF;
    IF a.score < 85 AND missed IS NOT NULL THEN
      SELECT count(*) INTO cnt FROM public.assessment_attempts
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND stage_index = a.stage_index
          AND grading_status = 'graded' AND status = 'answered' AND score < 85 AND jsonb_array_length(coalesce(feedback->'rubric_missed','[]'::jsonb)) > 0;
      IF cnt >= 2 THEN
        UPDATE public.learning_gaps SET description = 'Repeatedly missed: ' || missed, next_step = nstep, latest_attempt_id = a.id, evidence_count = evidence_count + 1
          WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'rubric:' || a.stage_index AND status = 'open';
        IF NOT FOUND THEN
          INSERT INTO public.learning_gaps (user_id, module_slug, concept_slug, gap_key, kind, description, next_step, source_attempt_id, latest_attempt_id, evidence_count)
          VALUES (a.user_id, a.module_slug, a.concept_slug, 'rubric:' || a.stage_index, 'missed_point', 'Repeatedly missed: ' || missed, nstep, a.id, a.id, cnt);
        END IF;
      END IF;
    END IF;
    IF a.score < 40 THEN
      SELECT count(*) INTO cnt FROM public.assessment_attempts
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug
          AND grading_status = 'graded' AND status = 'answered' AND score < 40 AND assessment_type IN ('prediction','checkpoint','teach_back');
      IF cnt >= 2 AND NOT EXISTS (SELECT 1 FROM public.learning_gaps WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND status = 'open' AND gap_key <> 'low_scores') THEN
        UPDATE public.learning_gaps SET latest_attempt_id = a.id, evidence_count = cnt
          WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'low_scores' AND status = 'open';
        IF NOT FOUND THEN
          INSERT INTO public.learning_gaps (user_id, module_slug, concept_slug, gap_key, kind, description, next_step, source_attempt_id, latest_attempt_id, evidence_count)
          VALUES (a.user_id, a.module_slug, a.concept_slug, 'low_scores', 'low_scores', 'Several answers on this concept scored below 40.', nstep, a.id, a.id, cnt);
        END IF;
      END IF;
    END IF;
    IF a.score >= 85 THEN
      UPDATE public.learning_gaps SET status = 'resolved', resolved_at = now(), resolved_by_attempt_id = a.id
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug
          AND gap_key IN ('misconception:' || a.stage_index, 'rubric:' || a.stage_index) AND status = 'open';
    END IF;

    -- Points: one award per question, the first time it is answered correctly.
    IF a.score >= 85 THEN
      pts := CASE WHEN a.assessment_type = 'teach_back' THEN 15 ELSE 10 END;
      INSERT INTO public.point_awards (user_id, award_key, attempt_id, points, reason)
      VALUES (a.user_id, 'question:' || a.module_slug || ':' || a.concept_slug || ':' || a.stage_index, a.id, pts, 'correct_' || a.assessment_type)
      ON CONFLICT (user_id, award_key) DO NOTHING;
    END IF;
    UPDATE public.assessment_attempts SET measured_at = now() WHERE id = a.id;
  END IF;

  -- Mastery: average of the latest graded score per question on this concept (recomputed, idempotent).
  SELECT avg(score), count(*), max(created_at) INTO avg_score, n_q, last_at FROM (
    SELECT DISTINCT ON (stage_index) stage_index, score, created_at FROM public.assessment_attempts
    WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug
      AND status = 'answered' AND grading_status = 'graded' AND score IS NOT NULL AND stage_index IS NOT NULL
      AND assessment_type IN ('prediction','checkpoint','teach_back')
    ORDER BY stage_index, created_at DESC) latest;
  IF avg_score < 70 OR avg_score IS NULL THEN NULL; END IF;
  UPDATE public.learning_gaps SET status = 'resolved', resolved_at = now(), resolved_by_attempt_id = a.id
    WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'low_scores' AND status = 'open' AND avg_score >= 70;
  SELECT count(*) INTO open_gaps FROM public.learning_gaps WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND status = 'open';
  state := CASE WHEN avg_score < 40 OR open_gaps > 0 THEN 'needs_review'
                WHEN avg_score >= 70 AND n_q >= 2 THEN 'mastered'
                ELSE 'in_progress' END;
  INSERT INTO public.concept_mastery (user_id, module_slug, concept_slug, mastery_score, mastery_state, evidence_count, last_evidence_at)
  VALUES (a.user_id, a.module_slug, a.concept_slug, round(avg_score)::int, state, n_q, last_at)
  ON CONFLICT (user_id, module_slug, concept_slug) DO UPDATE SET mastery_score = EXCLUDED.mastery_score, mastery_state = EXCLUDED.mastery_state, evidence_count = EXCLUDED.evidence_count, last_evidence_at = EXCLUDED.last_evidence_at;

  SELECT coalesce(sum(points), 0) INTO total FROM public.point_awards WHERE user_id = a.user_id;
  PERFORM set_config('app.points_writer', 'on', true);
  UPDATE public.profiles SET points = total WHERE id = a.user_id;
  PERFORM set_config('app.points_writer', 'off', true);

  RETURN jsonb_build_object('applied', true, 'points', total, 'mastery_score', round(avg_score)::int, 'mastery_state', state, 'evidence_count', n_q, 'open_gaps', open_gaps);
END; $$;
REVOKE ALL ON FUNCTION public.apply_attempt_measurement(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.apply_attempt_measurement(uuid) TO authenticated;