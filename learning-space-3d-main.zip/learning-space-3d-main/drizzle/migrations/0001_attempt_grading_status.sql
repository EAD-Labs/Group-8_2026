ALTER TABLE public.assessment_attempts
  ADD COLUMN IF NOT EXISTS grading_status text NOT NULL DEFAULT 'not_graded',
  ADD COLUMN IF NOT EXISTS graded_at timestamptz,
  ADD COLUMN IF NOT EXISTS grading_error text;
COMMENT ON COLUMN public.assessment_attempts.grading_status IS 'not_graded | graded | failed';