CREATE OR REPLACE FUNCTION public.handle_new_learner()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_learner();

INSERT INTO public.profiles (id, display_name)
SELECT u.id, COALESCE(u.raw_user_meta_data->>'full_name', split_part(u.email, '@', 1)) FROM auth.users u
ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.assessment_attempts
  ADD COLUMN IF NOT EXISTS module_slug text,
  ADD COLUMN IF NOT EXISTS stage_index integer,
  ADD COLUMN IF NOT EXISTS prompt_text text,
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'answered',
  ADD COLUMN IF NOT EXISTS hint_used boolean NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS assessment_attempts_session_idx ON public.assessment_attempts(session_id);
CREATE INDEX IF NOT EXISTS learning_sessions_user_concept_idx ON public.learning_sessions(user_id, module_slug, concept_slug);