-- Learners may insert their own answers/skips but never grade fields; no updates/deletes of evidence.
REVOKE INSERT, UPDATE, DELETE ON public.assessment_attempts FROM authenticated, anon;
GRANT INSERT (user_id, session_id, module_slug, concept_slug, stage_index, assessment_type, prompt_text, response_text, status, hint_used, revises_attempt_id) ON public.assessment_attempts TO authenticated;
GRANT SELECT ON public.assessment_attempts TO authenticated;
GRANT ALL ON public.assessment_attempts TO service_role;

-- Mastery is read-only for learners.
REVOKE INSERT, UPDATE, DELETE ON public.concept_mastery FROM authenticated, anon;
GRANT SELECT ON public.concept_mastery TO authenticated;
GRANT ALL ON public.concept_mastery TO service_role;

-- Profiles: learners may only create their row and edit display_name.
REVOKE INSERT, UPDATE, DELETE ON public.profiles FROM authenticated, anon;
GRANT SELECT ON public.profiles TO authenticated;
GRANT INSERT (id, display_name) ON public.profiles TO authenticated;
GRANT UPDATE (display_name) ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

REVOKE INSERT, UPDATE, DELETE ON public.learning_gaps FROM authenticated, anon;
REVOKE INSERT, UPDATE, DELETE ON public.point_awards FROM authenticated, anon;

-- Answers must link to the learner's own session and (for revisions) their own earlier answer to the same question.
CREATE OR REPLACE FUNCTION public.validate_attempt_links() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.session_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.learning_sessions s WHERE s.id = NEW.session_id AND s.user_id = NEW.user_id) THEN
    RAISE EXCEPTION 'session does not belong to learner';
  END IF;
  IF NEW.revises_attempt_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.assessment_attempts o WHERE o.id = NEW.revises_attempt_id AND o.user_id = NEW.user_id
      AND o.module_slug IS NOT DISTINCT FROM NEW.module_slug AND o.concept_slug = NEW.concept_slug AND o.stage_index IS NOT DISTINCT FROM NEW.stage_index) THEN
    RAISE EXCEPTION 'revision must link to the learner''s own answer to the same question';
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS assessment_attempts_validate_links ON public.assessment_attempts;
CREATE TRIGGER assessment_attempts_validate_links BEFORE INSERT ON public.assessment_attempts FOR EACH ROW EXECUTE FUNCTION public.validate_attempt_links();

-- Measurement: callable only by the trusted server (service role). Gap closing now also requires the specific error to be gone.
CREATE OR REPLACE FUNCTION public.apply_attempt_measurement(_attempt_id uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  a public.assessment_attempts%ROWTYPE;
  first_time boolean;
  misc text; nstep text; missed text; n_missed integer;
  avg_score numeric; n_q integer; last_at timestamptz; open_gaps integer; state text;
  pts integer; total integer; cnt integer;
BEGIN
  IF coalesce(auth.role(), '') <> 'service_role' AND current_user NOT IN ('postgres', 'service_role') THEN
    RAISE EXCEPTION 'measurement is server-only';
  END IF;
  SELECT * INTO a FROM public.assessment_attempts WHERE id = _attempt_id;
  IF a.id IS NULL THEN RAISE EXCEPTION 'attempt not found'; END IF;
  IF a.status <> 'answered' OR a.grading_status <> 'graded' OR a.score IS NULL
     OR a.assessment_type NOT IN ('prediction','checkpoint','teach_back') OR a.module_slug IS NULL OR a.stage_index IS NULL THEN
    RETURN jsonb_build_object('applied', false);
  END IF;
  first_time := a.measured_at IS NULL;
  misc := nullif(trim(a.feedback->>'misconception'), '');
  nstep := nullif(trim(a.feedback->>'next_step'), '');
  missed := a.feedback->'rubric_missed'->>0;
  n_missed := jsonb_array_length(coalesce(a.feedback->'rubric_missed','[]'::jsonb));

  IF first_time THEN
    -- A misconception the grader explicitly detects opens/updates a gap at any score.
    IF misc IS NOT NULL AND a.score < 85 THEN
      UPDATE public.learning_gaps SET description = misc, next_step = nstep, latest_attempt_id = a.id, evidence_count = evidence_count + 1
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'misconception:' || a.stage_index AND status = 'open';
      IF NOT FOUND THEN
        INSERT INTO public.learning_gaps (user_id, module_slug, concept_slug, gap_key, kind, description, next_step, source_attempt_id, latest_attempt_id)
        VALUES (a.user_id, a.module_slug, a.concept_slug, 'misconception:' || a.stage_index, 'misconception', misc, nstep, a.id, a.id);
      END IF;
    ELSIF misc IS NOT NULL THEN
      -- High score but misconception still present: keep any open gap open and record the evidence.
      UPDATE public.learning_gaps SET latest_attempt_id = a.id, evidence_count = evidence_count + 1
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'misconception:' || a.stage_index AND status = 'open';
    END IF;
    IF a.score < 85 AND missed IS NOT NULL THEN
      SELECT count(*) INTO cnt FROM public.assessment_attempts
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND stage_index = a.stage_index
          AND grading_status = 'graded' AND status = 'answered' AND score < 85 AND jsonb_array_length(coalesce(feedback->'rubric_missed','[]'::jsonb)) > 0;
      IF cnt >= 2 THEN
        UPDATE public.learning_gaps SET description = 'Repeatedly missed: ' || missed, next_step = nstep, latest_attempt_id = a.id, evidence_count = evidence_count + 1
          WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'rubric:' || a.stage_index AND status = 'open';
        IF NOT FOUND THEN
          INSERT INTO public.learning_gaps (user_id, module_slug, concept_slug, gap_key, kind, description, next_step, source_attempt_id, latest_attempt_id, evidence_count)
          VALUES (a.user_id, a.module_slug, a.concept_slug, 'rubric:' || a.stage_index, 'missed_point', 'Repeatedly missed: ' || missed, nstep, a.id, a.id, cnt);
        END IF;
      END IF;
    END IF;
    IF a.score < 40 THEN
      SELECT count(*) INTO cnt FROM public.assessment_attempts
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug
          AND grading_status = 'graded' AND status = 'answered' AND score < 40 AND assessment_type IN ('prediction','checkpoint','teach_back');
      IF cnt >= 2 AND NOT EXISTS (SELECT 1 FROM public.learning_gaps WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND status = 'open' AND gap_key <> 'low_scores') THEN
        UPDATE public.learning_gaps SET latest_attempt_id = a.id, evidence_count = cnt
          WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'low_scores' AND status = 'open';
        IF NOT FOUND THEN
          INSERT INTO public.learning_gaps (user_id, module_slug, concept_slug, gap_key, kind, description, next_step, source_attempt_id, latest_attempt_id, evidence_count)
          VALUES (a.user_id, a.module_slug, a.concept_slug, 'low_scores', 'low_scores', 'Several answers on this concept scored below 40.', nstep, a.id, a.id, cnt);
        END IF;
      END IF;
    END IF;
    -- Close a gap only when the later answer scores 85+ AND the specific error is no longer present.
    IF a.score >= 85 AND misc IS NULL THEN
      UPDATE public.learning_gaps SET status = 'resolved', resolved_at = now(), resolved_by_attempt_id = a.id
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug
          AND gap_key = 'misconception:' || a.stage_index AND status = 'open';
    END IF;
    IF a.score >= 85 AND n_missed = 0 THEN
      UPDATE public.learning_gaps SET status = 'resolved', resolved_at = now(), resolved_by_attempt_id = a.id
        WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug
          AND gap_key = 'rubric:' || a.stage_index AND status = 'open';
    END IF;

    -- Points: one award per question, first correct answer; only for built-in curriculum (server-held reference).
    IF a.score >= 85 AND a.module_slug NOT LIKE 'custom-%' THEN
      pts := CASE WHEN a.assessment_type = 'teach_back' THEN 15 ELSE 10 END;
      INSERT INTO public.point_awards (user_id, award_key, attempt_id, points, reason)
      VALUES (a.user_id, 'question:' || a.module_slug || ':' || a.concept_slug || ':' || a.stage_index, a.id, pts, 'correct_' || a.assessment_type)
      ON CONFLICT (user_id, award_key) DO NOTHING;
    END IF;
    UPDATE public.assessment_attempts SET measured_at = now() WHERE id = a.id;
  END IF;

  SELECT avg(score), count(*), max(created_at) INTO avg_score, n_q, last_at FROM (
    SELECT DISTINCT ON (stage_index) stage_index, score, created_at FROM public.assessment_attempts
    WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug
      AND status = 'answered' AND grading_status = 'graded' AND score IS NOT NULL AND stage_index IS NOT NULL
      AND assessment_type IN ('prediction','checkpoint','teach_back')
    ORDER BY stage_index, created_at DESC) latest;
  UPDATE public.learning_gaps SET status = 'resolved', resolved_at = now(), resolved_by_attempt_id = a.id
    WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND gap_key = 'low_scores' AND status = 'open' AND avg_score >= 70;
  SELECT count(*) INTO open_gaps FROM public.learning_gaps WHERE user_id = a.user_id AND module_slug = a.module_slug AND concept_slug = a.concept_slug AND status = 'open';
  state := CASE WHEN avg_score < 40 OR open_gaps > 0 THEN 'needs_review'
                WHEN avg_score >= 70 AND n_q >= 2 THEN 'mastered'
                ELSE 'in_progress' END;
  INSERT INTO public.concept_mastery (user_id, module_slug, concept_slug, mastery_score, mastery_state, evidence_count, last_evidence_at)
  VALUES (a.user_id, a.module_slug, a.concept_slug, round(avg_score)::int, state, n_q, last_at)
  ON CONFLICT (user_id, module_slug, concept_slug) DO UPDATE SET mastery_score = EXCLUDED.mastery_score, mastery_state = EXCLUDED.mastery_state, evidence_count = EXCLUDED.evidence_count, last_evidence_at = EXCLUDED.last_evidence_at;

  SELECT coalesce(sum(points), 0) INTO total FROM public.point_awards WHERE user_id = a.user_id;
  PERFORM set_config('app.points_writer', 'on', true);
  UPDATE public.profiles SET points = total WHERE id = a.user_id;
  PERFORM set_config('app.points_writer', 'off', true);

  RETURN jsonb_build_object('applied', true, 'points', total, 'mastery_score', round(avg_score)::int, 'mastery_state', state, 'evidence_count', n_q, 'open_gaps', open_gaps);
END; $$;
REVOKE ALL ON FUNCTION public.apply_attempt_measurement(uuid) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.apply_attempt_measurement(uuid) TO service_role;
REVOKE ALL ON FUNCTION public.validate_attempt_links() FROM public, anon, authenticated;