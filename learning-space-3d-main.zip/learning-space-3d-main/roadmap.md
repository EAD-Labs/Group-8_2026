# Product roadmap

- [x] Review the uploaded implementation, current live app, and HLD
- [x] Define the upgraded classroom experience and architecture
- [x] Build the realistic interactive classroom and complete learning modules
- [x] Add learner material upload and AI-grounded study flow
- [x] Validate desktop/mobile behavior and core learning flow
- [x] Connect classroom chat to GPT through Lovable AI; document Claude option
- [x] Restore the fuller original My Desk interface after comparison
- [x] Let learners load their own Unity WebGL scenes into the classroom
- [x] Meeting feedback: per-persona transcript threads, highlighted evaluated questions, unanswered-question follow-up
- [x] Phase 3 security: server-side grading, locked learner writes, gap-closure tightening, validation (Oct 13 brief)
- [ ] Gap-matching grader change (misconception still present?) — proposal awaiting review
