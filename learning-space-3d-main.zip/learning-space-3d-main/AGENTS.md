<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Learner evidence (sessions, attempts, skips) is written from the browser client straight to the hosted database tables under per-user access rules; no parallel backend. Why: one source of truth for Part 3.
- Learner-facing progress numbers come only from saved records; show empty states, never sample values. Why: measurement integrity.
- Answer grading runs only in the authenticated gradeAttempt server function: it loads the attempt under the learner's own access rules, grades it, and writes grade fields with the trusted server client; learners have no write access to grade fields, mastery, gaps, points or the measurement function. Why: grades and measurement cannot be forged from the browser. Why: one grading path, results stay with the answer.
- Mastery, learning gaps and points are computed only by the apply_attempt_measurement database function (called by gradeAttempt and the syncMeasurement backfill); points come from the point_awards ledger, one award per question, and profiles.points is guarded so other writes can't change it. Why: idempotent, non-farmable measurement from graded evidence only.
- AI-generated modules are created and stored only by the authenticated generateModule server function (custom_modules table, learner read-only); grading loads their reference from that stored copy, and measurement ignores custom-module answers without a server-held module. Why: learners cannot supply their own grading reference.
- Security regression tests live in tests/security.test.ts and run against the hosted database as a real learner (`bun run test`). Why: verify permissions on the deployed configuration, not local assumptions.
