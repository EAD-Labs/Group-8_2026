import type { Concept } from "@/lib/curriculum";

/** Question types that receive real grading in Phase 2. Prior-knowledge ("blank") and transfer are saved but not graded yet. */
export const GRADED_TYPES = ["prediction", "checkpoint", "teach_back"];
export const ASSESSMENT_TYPE: Record<string, string> = { question: "blank", predict: "prediction", teachback: "teach_back" };
export const assessmentTypeFor = (kind: string) => ASSESSMENT_TYPE[kind] ?? kind;

export type GradingReference = { conceptTitle: string; prompt: string; stageText: string; coreIdea: string; example: string; misconception: string; equation: string };

export function buildReference(concept: Concept, stageIndex: number): GradingReference | null {
  const st = concept.stages[stageIndex];
  if (!st?.prompt) return null;
  const by = (k: string) => concept.stages.find(s => s.kind === k);
  return {
    conceptTitle: concept.title,
    prompt: st.prompt,
    stageText: st.text,
    coreIdea: by("explain")?.text ?? "",
    example: (by("example")?.text ?? "").replace(/^Can we make that concrete\?\s*/, ""),
    misconception: (by("challenge")?.text ?? "").replace(/^I want to challenge a common shortcut:\s*/, ""),
    equation: by("explain")?.board ?? "",
  };
}
