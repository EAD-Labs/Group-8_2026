import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({ topic: z.string().max(500), material: z.string().max(12000).optional() });
const Concept = z.object({ title: z.string().max(300), bloom: z.string().max(40), definition: z.string().max(4000), misconception: z.string().max(2000), example: z.string().max(4000), equation: z.string().max(500), transfer: z.string().max(2000) });
const Out = z.object({ title: z.string().max(300), description: z.string().max(1000), concepts: z.array(Concept).min(2).max(8) });
export type StoredModule = { slug: string; title: string; description: string; concepts: z.infer<typeof Concept>[] };

const SYSTEM = `You design complete university learning modules for AI KYRO. Cover the WHOLE topic as an ordered concept sequence (4-7 concepts), from foundations to analysis — not just definitions. If learner material is supplied, base the sequence on it and don't invent facts it contradicts. Reply with ONLY raw JSON: {"title":string,"description":string (1 sentence),"concepts":[{"title":string,"bloom":"Remember"|"Understand"|"Apply"|"Analyse","definition":string (2-3 sentence core explanation),"misconception":string (a common wrong belief, phrased as a lowercase clause),"example":string (concrete worked example),"equation":string (key formula or short principle for the board),"transfer":string (a new-situation problem)}]}`;

/** Generates an AI module on the server and stores it (with its grading reference) in server-controlled storage. */
export const generateModule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    if (!data.topic.trim() && !data.material?.trim()) return { ok: false as const, error: "Add a topic or attach material." };
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return { ok: false as const, error: "AI is not configured." };
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${key}`, "Lovable-API-Key": key },
      body: JSON.stringify({ model: "openai/gpt-6-astra", messages: [{ role: "system", content: SYSTEM }, { role: "user", content: `TOPIC: ${data.topic || "(derive from material)"}\n\nLEARNER MATERIAL:\n${data.material || "None"}` }] }),
    });
    if (!res.ok) return { ok: false as const, error: res.status === 402 ? "AI credits are used up for this workspace." : res.status === 429 ? "Too many requests — try again in a moment." : "Could not build the module. Try rephrasing the topic." };
    const body = await res.json() as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content ?? "";
    let parsed;
    try { parsed = Out.parse(JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1))); }
    catch { return { ok: false as const, error: "Could not build the module. Try rephrasing the topic." }; }
    const slug = `custom-${crypto.randomUUID()}`;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("custom_modules").insert({ user_id: context.userId, slug, title: parsed.title, description: parsed.description, concepts: parsed.concepts });
    if (error) { console.error("store module", error); return { ok: false as const, error: "Could not save the module." }; }
    return { ok: true as const, module: { slug, ...parsed } as StoredModule };
  });
