import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { modules, arc, type Concept } from "@/lib/curriculum";
import { GRADED_TYPES, buildReference, type GradingReference } from "@/lib/grading";

type StoredConcept = { title: string; bloom: string; definition: string; misconception: string; example: string; equation: string; transfer: string };

// The client sends only the attempt id; grading references are always loaded on the server.
const Input = z.object({ attemptId: z.string().uuid() });

const Result = z.object({
  score: z.number().int().min(0).max(100),
  verdict: z.enum(["correct", "partial", "incorrect"]),
  feedback: z.string(),
  rubric_met: z.array(z.string()),
  rubric_missed: z.array(z.string()),
  misconception: z.string().nullable(),
  next_step: z.string().nullable(),
});
const MODEL = "openai/gpt-6-astra";
const SYSTEM = "You are a rigorous university grader. Grade the learner's answer against the course reference for meaning and reasoning, not keywords. A keyword without a correct mechanism earns no credit for that point. Give partial credit for genuinely correct parts. Rubric points must come from the reference (3-4 short points). Record a misconception only when the answer shows one, else null. feedback: max 2 sentences addressed to the learner. next_step: a concrete retry instruction when score < 85, else null. Score 0-100; bands: 85-100 correct, 40-84 partial, 0-39 incorrect.";
export type GradeResult = z.infer<typeof Result>;

export const gradeAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: attempt, error } = await supabase.from("assessment_attempts")
      .select("id,module_slug,concept_slug,stage_index,assessment_type,response_text,status,hint_used,prompt_text,grading_status")
      .eq("id", data.attemptId).maybeSingle();
    if (error || !attempt) return { ok: false as const, error: "Answer not found." };
    if ((attempt as { grading_status?: string }).grading_status === "graded") return { ok: false as const, error: "This answer is already graded." };
    if (attempt.status !== "answered" || !GRADED_TYPES.includes(attempt.assessment_type)) return { ok: false as const, error: "This item is not graded." };

    let ref: GradingReference | null = null;
    const mod = modules.find(m => m.slug === attempt.module_slug);
    let concept: Concept | undefined = mod?.concepts.find(c => c.slug === attempt.concept_slug);
    let source = "curriculum";
    if (!concept && attempt.module_slug?.startsWith("custom-")) {
      // AI-generated module: only the server-stored copy owned by this learner is trusted.
      const { data: stored } = await supabase.from("custom_modules").select("slug,concepts").eq("slug", attempt.module_slug).eq("user_id", context.userId).maybeSingle();
      const list = (stored?.concepts ?? []) as unknown as StoredConcept[];
      const idx = Number(attempt.concept_slug.slice(attempt.module_slug.length + 1));
      const c = stored && attempt.concept_slug === `${attempt.module_slug}-${idx}` ? list[idx] : undefined;
      if (c) { concept = { slug: attempt.concept_slug, title: c.title, bloom: c.bloom, duration: 12, mastery: 0, stages: arc(c.title, c.definition, c.misconception, c.example, c.equation, c.transfer) }; source = "custom_module_server"; }
    }
    if (concept && attempt.stage_index != null) ref = buildReference(concept, attempt.stage_index);
    if (!ref) return { ok: false as const, error: "This question has no trusted course reference, so it can't be graded." };

    // Authoritative writes go through the trusted server client; the learner cannot write grade fields.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const fail = async (msg: string) => {
      await supabaseAdmin.from("assessment_attempts").update({ grading_status: "failed", grading_error: msg.slice(0, 500) }).eq("id", attempt.id).eq("user_id", context.userId);
      return { ok: false as const, error: "Grading is unavailable right now. Your answer is saved — try again." };
    };

    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return fail("AI not configured");
    try {
      const schema = { type: "object", additionalProperties: false,
        required: ["score", "verdict", "feedback", "rubric_met", "rubric_missed", "misconception", "next_step"],
        properties: {
          score: { type: "integer" }, verdict: { type: "string", enum: ["correct", "partial", "incorrect"] }, feedback: { type: "string" },
          rubric_met: { type: "array", items: { type: "string" } }, rubric_missed: { type: "array", items: { type: "string" } },
          misconception: { type: ["string", "null"] }, next_step: { type: ["string", "null"] },
        } };
      const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${key}`, "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "fetch" },
        body: JSON.stringify({
          model: MODEL, stream: true, store: false, reasoning: { effort: "low" },
          instructions: SYSTEM,
          input: `CONCEPT: ${ref.conceptTitle}\nQUESTION CONTEXT: ${ref.stageText}\nTASK: ${ref.prompt}\n\nCOURSE REFERENCE\nCore idea: ${ref.coreIdea}\nKey relation: ${ref.equation}\nWorked example: ${ref.example}\nKnown misconception: ${ref.misconception}\n\nLEARNER ANSWER:\n${attempt.response_text}`,
          text: { format: { type: "json_schema", name: "grade", strict: true, schema } },
        }),
      });
      if (!res.ok || !res.body) { console.error("grading gateway", res.status, await res.text()); return fail(`gateway ${res.status}`); }
      const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = "", out = "";
      for (;;) { const { done, value } = await reader.read(); if (done) break; buf += dec.decode(value, { stream: true });
        let i; while ((i = buf.indexOf("\n")) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (!line.startsWith("data:")) continue; const payload = line.slice(5).trim(); if (!payload || payload === "[DONE]") continue;
          try { const ev = JSON.parse(payload); if (ev.type === "response.output_text.delta") out += ev.delta; } catch { /* partial */ } } }
      const args = out;
      const parsed = Result.safeParse(typeof args === "string" ? JSON.parse(args) : args);
      if (!parsed.success) return fail("invalid grader output");
      const g = parsed.data;
      const feedback = { ...g, hint_used: attempt.hint_used, reference_source: source, grader: MODEL };
      const { error: upErr } = await supabaseAdmin.from("assessment_attempts")
        .update({ score: g.score, feedback, grading_status: "graded", graded_at: new Date().toISOString(), grading_error: null }).eq("id", attempt.id).eq("user_id", context.userId);
      if (upErr) return fail(upErr.message);
      const { data: measurement, error: mErr } = await supabaseAdmin.rpc("apply_attempt_measurement", { _attempt_id: attempt.id });
      if (mErr) console.error("measurement error", mErr);
      return { ok: true as const, score: g.score, feedback, measurement: (measurement ?? null) as { applied?: boolean; points?: number; mastery_score?: number; mastery_state?: string; open_gaps?: number } | null };
    } catch (e) {
      console.error("grading error", e);
      return fail(e instanceof Error ? e.message : "unknown");
    }
  });

/** Applies mastery/gap/points measurement to any graded answers not yet measured (oldest first). Idempotent. */
export const syncMeasurement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data } = await supabase.from("assessment_attempts").select("id")
      .eq("user_id", userId).eq("grading_status", "graded").eq("status", "answered").is("measured_at", null)
      .in("assessment_type", GRADED_TYPES).order("created_at");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    for (const row of data ?? []) {
      const { error } = await supabaseAdmin.rpc("apply_attempt_measurement", { _attempt_id: row.id });
      if (error) console.error("measurement sync", error);
    }
    return { synced: data?.length ?? 0 };
  });
