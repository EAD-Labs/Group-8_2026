export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      assessment_attempts: {
        Row: {
          assessment_type: string
          concept_slug: string
          created_at: string
          feedback: Json
          graded_at: string | null
          grading_error: string | null
          grading_status: string
          hint_used: boolean
          id: string
          measured_at: string | null
          module_slug: string | null
          prompt_text: string | null
          response_text: string
          revises_attempt_id: string | null
          score: number | null
          session_id: string | null
          stage_index: number | null
          status: string
          user_id: string
        }
        Insert: {
          assessment_type: string
          concept_slug: string
          created_at?: string
          feedback?: Json
          graded_at?: string | null
          grading_error?: string | null
          grading_status?: string
          hint_used?: boolean
          id?: string
          measured_at?: string | null
          module_slug?: string | null
          prompt_text?: string | null
          response_text: string
          revises_attempt_id?: string | null
          score?: number | null
          session_id?: string | null
          stage_index?: number | null
          status?: string
          user_id: string
        }
        Update: {
          assessment_type?: string
          concept_slug?: string
          created_at?: string
          feedback?: Json
          graded_at?: string | null
          grading_error?: string | null
          grading_status?: string
          hint_used?: boolean
          id?: string
          measured_at?: string | null
          module_slug?: string | null
          prompt_text?: string | null
          response_text?: string
          revises_attempt_id?: string | null
          score?: number | null
          session_id?: string | null
          stage_index?: number | null
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "assessment_attempts_revises_attempt_id_fkey"
            columns: ["revises_attempt_id"]
            isOneToOne: false
            referencedRelation: "assessment_attempts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "assessment_attempts_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "learning_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      concept_mastery: {
        Row: {
          bloom_level: string
          concept_slug: string
          created_at: string
          doubt_log: Json
          evidence_count: number
          id: string
          last_evidence_at: string | null
          mastery_score: number
          mastery_state: string
          module_slug: string
          next_review_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          bloom_level?: string
          concept_slug: string
          created_at?: string
          doubt_log?: Json
          evidence_count?: number
          id?: string
          last_evidence_at?: string | null
          mastery_score?: number
          mastery_state?: string
          module_slug: string
          next_review_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          bloom_level?: string
          concept_slug?: string
          created_at?: string
          doubt_log?: Json
          evidence_count?: number
          id?: string
          last_evidence_at?: string | null
          mastery_score?: number
          mastery_state?: string
          module_slug?: string
          next_review_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      custom_modules: {
        Row: {
          concepts: Json
          created_at: string
          description: string
          id: string
          slug: string
          title: string
          user_id: string
        }
        Insert: {
          concepts: Json
          created_at?: string
          description?: string
          id?: string
          slug: string
          title: string
          user_id: string
        }
        Update: {
          concepts?: Json
          created_at?: string
          description?: string
          id?: string
          slug?: string
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      learning_gaps: {
        Row: {
          concept_slug: string
          created_at: string
          description: string
          evidence_count: number
          gap_key: string
          id: string
          kind: string
          latest_attempt_id: string | null
          module_slug: string
          next_step: string | null
          resolved_at: string | null
          resolved_by_attempt_id: string | null
          source_attempt_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          concept_slug: string
          created_at?: string
          description: string
          evidence_count?: number
          gap_key: string
          id?: string
          kind: string
          latest_attempt_id?: string | null
          module_slug: string
          next_step?: string | null
          resolved_at?: string | null
          resolved_by_attempt_id?: string | null
          source_attempt_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          concept_slug?: string
          created_at?: string
          description?: string
          evidence_count?: number
          gap_key?: string
          id?: string
          kind?: string
          latest_attempt_id?: string | null
          module_slug?: string
          next_step?: string | null
          resolved_at?: string | null
          resolved_by_attempt_id?: string | null
          source_attempt_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "learning_gaps_latest_attempt_id_fkey"
            columns: ["latest_attempt_id"]
            isOneToOne: false
            referencedRelation: "assessment_attempts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "learning_gaps_resolved_by_attempt_id_fkey"
            columns: ["resolved_by_attempt_id"]
            isOneToOne: false
            referencedRelation: "assessment_attempts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "learning_gaps_source_attempt_id_fkey"
            columns: ["source_attempt_id"]
            isOneToOne: false
            referencedRelation: "assessment_attempts"
            referencedColumns: ["id"]
          },
        ]
      }
      learning_materials: {
        Row: {
          created_at: string
          extracted_summary: string | null
          file_name: string
          file_type: string
          id: string
          page_count: number | null
          source_outline: Json
          status: string
          storage_path: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          extracted_summary?: string | null
          file_name: string
          file_type: string
          id?: string
          page_count?: number | null
          source_outline?: Json
          status?: string
          storage_path: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          extracted_summary?: string | null
          file_name?: string
          file_type?: string
          id?: string
          page_count?: number | null
          source_outline?: Json
          status?: string
          storage_path?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      learning_sessions: {
        Row: {
          completed: boolean
          concept_slug: string
          created_at: string
          current_stage: number
          dialogue_mode: string
          id: string
          material_id: string | null
          module_slug: string
          source_refs: Json
          transcript: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          completed?: boolean
          concept_slug: string
          created_at?: string
          current_stage?: number
          dialogue_mode?: string
          id?: string
          material_id?: string | null
          module_slug: string
          source_refs?: Json
          transcript?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          completed?: boolean
          concept_slug?: string
          created_at?: string
          current_stage?: number
          dialogue_mode?: string
          id?: string
          material_id?: string | null
          module_slug?: string
          source_refs?: Json
          transcript?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "learning_sessions_material_id_fkey"
            columns: ["material_id"]
            isOneToOne: false
            referencedRelation: "learning_materials"
            referencedColumns: ["id"]
          },
        ]
      }
      point_awards: {
        Row: {
          attempt_id: string | null
          award_key: string
          created_at: string
          id: string
          points: number
          reason: string
          user_id: string
        }
        Insert: {
          attempt_id?: string | null
          award_key: string
          created_at?: string
          id?: string
          points: number
          reason: string
          user_id: string
        }
        Update: {
          attempt_id?: string | null
          award_key?: string
          created_at?: string
          id?: string
          points?: number
          reason?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "point_awards_attempt_id_fkey"
            columns: ["attempt_id"]
            isOneToOne: false
            referencedRelation: "assessment_attempts"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
          points: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id: string
          points?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
          points?: number
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      apply_attempt_measurement: {
        Args: { _attempt_id: string }
        Returns: Json
      }
      measurement_trusted: {
        Args: { _module_slug: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
