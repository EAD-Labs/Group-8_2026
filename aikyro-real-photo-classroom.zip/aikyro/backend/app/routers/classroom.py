from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from app.auth import get_current_user
from app.content.loader import get_concept, get_misconception
from app.database import get_db
from app.models import User, LearningSession, DialogueTurn, InteractionEvent, ConditionType, VerifiedKnowledgeRecord
from app.schemas import (
    StartSessionRequest, StartFreeformSessionRequest, StartSessionResponse,
    LearnerQuestionRequest, InteractionEventIn, InteractionEventOut, QuestionHistoryItem, TurnOut,
)
from app.services.verification_engine import produce_verified_record, produce_verified_record_freeform
from app.services.dialogue_orchestrator import build_dialogue, insert_learner_question
from app.services.measurement_service import log_doubt
from app.services.grading_service import grade_answer

router = APIRouter(prefix="/classroom", tags=["classroom"])


@router.get("/questions", response_model=list[QuestionHistoryItem])
def question_history(db: DBSession = Depends(get_db), user: User = Depends(get_current_user)):
    """
    Every question the learner has asked as the third student, across every
    session, most recent first — with the teacher's answer alongside it, so
    it's actually reviewable rather than a name in a list (this is the
    'history of questions asked to the teacher' from Screen 1, HLD 9.3/5.1
    step 5, surfaced somewhere the learner can revisit it and open the
    session it came from).
    """
    questions = (
        db.query(DialogueTurn, LearningSession)
        .join(LearningSession, DialogueTurn.session_id == LearningSession.id)
        .filter(LearningSession.user_id == user.id, DialogueTurn.turn_type == "learner_question")
        .order_by(DialogueTurn.created_at.desc())
        .all()
    )
    if not questions:
        return []

    session_ids = {session.id for _, session in questions}
    all_turns = (
        db.query(DialogueTurn)
        .filter(DialogueTurn.session_id.in_(session_ids))
        .order_by(DialogueTurn.turn_index)
        .all()
    )
    turns_by_session: dict[str, list[DialogueTurn]] = {}
    for t in all_turns:
        turns_by_session.setdefault(t.session_id, []).append(t)

    records = {
        r.id: r
        for r in db.query(VerifiedKnowledgeRecord)
        .filter(VerifiedKnowledgeRecord.id.in_({s.verified_record_id for _, s in questions}))
        .all()
    }

    items = []
    for turn, session in questions:
        concept = get_concept(session.concept_id)
        if concept:
            concept_name = concept["name"]
        else:
            record = records.get(session.verified_record_id)
            concept_name = record.topic_name if record and record.topic_name else session.concept_id

        # the teacher's answer is inserted immediately after the question
        # turn by /classroom/{session_id}/question — find it by turn_index
        answer = None
        for t in turns_by_session.get(session.id, []):
            if t.turn_index == turn.turn_index + 1 and t.speaker == "teacher":
                answer = t.content
                break

        items.append(
            QuestionHistoryItem(
                session_id=session.id,
                turn_id=turn.id,
                concept_id=session.concept_id,
                concept_name=concept_name,
                question=turn.content,
                answer=answer,
                asked_at=turn.created_at,
            )
        )
    return items


@router.post("/start", response_model=StartSessionResponse)
async def start_session(
    payload: StartSessionRequest, db: DBSession = Depends(get_db), user: User = Depends(get_current_user)
):
    concept = get_concept(payload.concept_id)
    if not concept:
        raise HTTPException(404, "Unknown concept")

    record = await produce_verified_record(db, payload.concept_id)

    condition = ConditionType.GENERAL_USE
    if user.pilot_condition_map and payload.concept_id in user.pilot_condition_map:
        condition = ConditionType(user.pilot_condition_map[payload.concept_id])

    session = LearningSession(
        user_id=user.id,
        concept_id=payload.concept_id,
        module_id=concept["module_id"],
        verified_record_id=record.id,
        condition=condition,
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    turns = await build_dialogue(record)
    for i, t in enumerate(turns):
        db.add(DialogueTurn(session_id=session.id, turn_index=i, **t))
    db.commit()

    return StartSessionResponse(session_id=session.id, concept_id=payload.concept_id, condition=condition.value)


@router.post("/start-freeform", response_model=StartSessionResponse)
async def start_freeform_session(
    payload: StartFreeformSessionRequest, db: DBSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """
    Open-topic entry point: not looked up in modules.json, not part of the
    graded platform-vs-plain-chat comparison (HLD's graded pairs are fixed to
    two pilot modules — see D-03). Always runs as GENERAL_USE.
    """
    topic = payload.topic.strip()
    if not topic:
        raise HTTPException(400, "Topic cannot be empty")
    if len(topic) > 200:
        raise HTTPException(400, "Keep the topic under 200 characters")

    record, concept_id = await produce_verified_record_freeform(db, topic)

    session = LearningSession(
        user_id=user.id,
        concept_id=concept_id,
        module_id="general",
        verified_record_id=record.id,
        condition=ConditionType.GENERAL_USE,
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    turns = await build_dialogue(record)
    for i, t in enumerate(turns):
        db.add(DialogueTurn(session_id=session.id, turn_index=i, **t))
    db.commit()

    return StartSessionResponse(
        session_id=session.id, concept_id=concept_id, condition=ConditionType.GENERAL_USE.value, topic_name=topic
    )


@router.get("/{session_id}/turns", response_model=list[TurnOut])
def get_turns(session_id: str, db: DBSession = Depends(get_db), user: User = Depends(get_current_user)):
    """
    Full ordered turn list for a session, once — not a stream. Turns are
    already generated and persisted at /start, so there's nothing to push
    incrementally; the frontend reveals them one at a time locally as the
    learner clicks through (see Classroom.tsx). This replaces the old SSE
    /stream endpoint, which fixes two defects at once: D3 (an EventSource
    can't set an Authorization header, which is exactly why that endpoint
    had none — this one is a plain authenticated GET) and D7 (nothing to
    resume: a dropped connection just means calling this again).
    """
    session = db.query(LearningSession).filter_by(id=session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    if session.user_id != user.id:
        raise HTTPException(403, "Not your session")

    turns = (
        db.query(DialogueTurn)
        .filter(DialogueTurn.session_id == session_id)
        .order_by(DialogueTurn.turn_index)
        .all()
    )
    return [
        TurnOut(
            id=t.id,
            speaker=t.speaker,
            turn_type=t.turn_type,
            content=t.content,
            target_bloom_level=t.target_bloom_level.value if t.target_bloom_level else None,
        )
        for t in turns
    ]


@router.post("/{session_id}/question")
async def ask_question(
    session_id: str, payload: LearnerQuestionRequest, db: DBSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """
    Learner enters as third student (HLD 6.1). Both halves of this exchange
    are persisted — the learner's own question as a `learner_question` turn,
    then the teacher's answer right after it — so the exchange survives a
    reload and can be looked back up later (GET /classroom/questions).

    D3: this endpoint used to take no auth at all — any caller with a
    session id could post into another learner's dialogue. Now checked.
    D2: the teacher's answer is grounded in the turns so far, not just the
    verified text and concept name — see insert_learner_question.
    """
    session = db.query(LearningSession).filter_by(id=session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    if session.user_id != user.id:
        raise HTTPException(403, "Not your session")

    question_text = payload.question.strip()
    if not question_text:
        raise HTTPException(400, "Question cannot be empty")

    record = db.query(VerifiedKnowledgeRecord).filter_by(id=session.verified_record_id).first()
    concept = get_concept(session.concept_id)
    concept_name = concept["name"] if concept else (record.topic_name if record else session.concept_id)

    prior_turns = (
        db.query(DialogueTurn)
        .filter_by(session_id=session_id)
        .order_by(DialogueTurn.turn_index)
        .all()
    )
    prior_turns_data = [{"speaker": t.speaker, "content": t.content} for t in prior_turns]

    answer_turn = await insert_learner_question(
        question_text, record.verified_text if record else "", concept_name, prior_turns_data
    )

    next_index = len(prior_turns)
    question_turn = DialogueTurn(
        session_id=session_id,
        turn_index=next_index,
        speaker="learner",
        turn_type="learner_question",
        content=question_text,
        target_bloom_level=None,
    )
    db.add(question_turn)
    db.commit()
    db.refresh(question_turn)

    turn = DialogueTurn(session_id=session_id, turn_index=next_index + 1, **answer_turn)
    db.add(turn)
    db.commit()
    db.refresh(turn)
    return {"id": turn.id, "content": turn.content}


@router.post("/interaction-event", response_model=InteractionEventOut)
async def record_interaction_event(
    payload: InteractionEventIn, db: DBSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """
    Reveals, guesses, questions, dwell time — feeds the Measurement Service
    (Part 3) and the doubt log (HLD 6.6).

    D1 fix: correctness used to depend on the frontend sending `is_correct`
    and a `misconception` string in the payload, which it never did — so
    the doubt log could never be written to. Now this endpoint grades the
    guess itself (real LLM grading in live mode, same honest placeholder as
    checkpoints in mock mode) against the turn's own content and the
    session's verified record, and — if the turn targeted a known
    misconception (dialogue_orchestrator, content/modules.json §5) — writes
    the doubt log entry with that misconception's real statement, not a
    placeholder the client would have had to invent.
    """
    turn = db.query(DialogueTurn).filter_by(id=payload.turn_id).first()
    if not turn:
        raise HTTPException(404, "Turn not found")
    session = db.query(LearningSession).filter_by(id=turn.session_id).first()
    if not session or session.user_id != user.id:
        raise HTTPException(403, "Not your session")

    is_correct = payload.is_correct
    feedback = ""

    if turn.turn_type in ("blank", "hint") and payload.event_type == "guess":
        guess_text = str(payload.payload.get("guess", "")).strip()
        record = db.query(VerifiedKnowledgeRecord).filter_by(id=session.verified_record_id).first()
        concept = get_concept(session.concept_id)
        concept_name = concept["name"] if concept else (record.topic_name if record else session.concept_id)

        is_correct, _score, feedback = await grade_answer(
            prompt=turn.content,
            verified_text=record.verified_text if record else "",
            learner_answer=guess_text,
            concept_name=concept_name,
        )

    event = InteractionEvent(
        turn_id=payload.turn_id,
        event_type=payload.event_type,
        payload=payload.payload,
        is_correct=is_correct,
    )
    db.add(event)
    db.commit()

    if is_correct is False:
        misconception_statement = None
        if turn.target_misconception_id:
            misconception = get_misconception(session.concept_id, turn.target_misconception_id)
            if misconception:
                misconception_statement = misconception["statement"]

        log_doubt(
            db,
            user_id=user.id,
            concept_id=session.concept_id,
            misconception=misconception_statement or "General difficulty with this concept (no specific misconception on record)",
            source="wrong_blank" if turn.turn_type == "blank" else "revealed_hint",
        )

    db.refresh(event)
    return InteractionEventOut(id=event.id, is_correct=is_correct, feedback=feedback)
