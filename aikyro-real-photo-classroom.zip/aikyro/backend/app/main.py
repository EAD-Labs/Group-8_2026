from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine
from app import models  # noqa: F401 — ensure models are registered before create_all
from app.routers import auth, topics, classroom, checkpoint, progress, voice


@asynccontextmanager
async def lifespan(app: FastAPI):
    # dev convenience: auto-create tables against sqlite. Swap for Alembic
    # migrations before this touches a real Postgres instance (HLD 8.4).
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title="AI KYRO — Metacognitive AI Scaffold API", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,  # D8: was hardcoded, now a setting
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(topics.router)
app.include_router(classroom.router)
app.include_router(checkpoint.router)
app.include_router(progress.router)
app.include_router(voice.router)


@app.get("/health")
def health():
    return {"status": "ok"}
