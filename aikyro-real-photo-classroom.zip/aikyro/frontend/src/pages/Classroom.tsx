import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  Mic, Square, Send, Volume2, VolumeX, ArrowRight, Loader2,
  GraduationCap, BookOpen, Brain, User, Hand,
} from 'lucide-react'
import NavShell from '../components/NavShell'
import { api } from '../api/client'
import classroomImage from '../assets/realistic-classroom.jpg'

type Turn = {
  id: string
  speaker: 'teacher' | 'basic_student' | 'advanced_student' | 'learner'
  turn_type: 'dialogue' | 'hint' | 'blank' | 'learner_question'
  content: string
  target_bloom_level: string | null
}

const PERSONA: Record<
  string,
  { label: string; icon: typeof GraduationCap; bg: string; text: string; border: string }
> = {
  teacher: { label: 'Teacher', icon: GraduationCap, bg: 'bg-teacher', text: 'text-teacher', border: 'border-teacher/30' },
  basic_student: { label: 'Basic Student', icon: BookOpen, bg: 'bg-basic', text: 'text-basic', border: 'border-basic/30' },
  advanced_student: { label: 'Advanced Student', icon: Brain, bg: 'bg-advanced', text: 'text-advanced', border: 'border-advanced/30' },
  learner: { label: 'You', icon: User, bg: 'bg-learner', text: 'text-learner', border: 'border-learner/30' },
}

// Web Speech API isn't in default TS lib types — minimal ambient declarations.
interface SpeechRecognitionResultLike {
  isFinal: boolean
  0: { transcript: string }
}
interface SpeechRecognitionEventLike extends Event {
  results: ArrayLike<SpeechRecognitionResultLike>
  resultIndex: number
}
interface SpeechRecognitionLike extends EventTarget {
  lang: string
  interimResults: boolean
  continuous: boolean
  start: () => void
  stop: () => void
  onresult: ((e: SpeechRecognitionEventLike) => void) | null
  onend: (() => void) | null
  onerror: (() => void) | null
}
declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike
    webkitSpeechRecognition?: new () => SpeechRecognitionLike
  }
}

export default function Classroom() {
  const { sessionId } = useParams<{ sessionId: string }>()
  const [turns, setTurns] = useState<Turn[]>([])
  const [streamDone, setStreamDone] = useState(false)
  const [pacedTurns, setPacedTurns] = useState<Turn[]>([])
  const pacingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const latestTurnsRef = useRef<Turn[]>([])
  const [revealedHints, setRevealedHints] = useState<Record<string, boolean>>({})
  const [guesses, setGuesses] = useState<Record<string, string>>({})
  const [question, setQuestion] = useState('')
  const [asking, setAsking] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(false)
  const [recording, setRecording] = useState(false)
  const [voiceSubmitting, setVoiceSubmitting] = useState(false)
  const [voiceResult, setVoiceResult] = useState<{
    ok: boolean
    reason?: string
    transcript_coverage_score?: number
    speech_rate_wpm?: number | null
    hesitation_flags?: { term: string; pause_ms: number }[]
    signal_degraded?: boolean
  } | null>(null)
  const [voiceError, setVoiceError] = useState<string | null>(null)

  const [speakMode, setSpeakMode] = useState(false)
  const [listening, setListening] = useState(false)
  const speechSupported = typeof window !== 'undefined' && !!(window.SpeechRecognition || window.webkitSpeechRecognition)
  const ttsSupported = typeof window !== 'undefined' && 'speechSynthesis' in window

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null)
  const spokenTurnIds = useRef<Set<string>>(new Set())
  const navigate = useNavigate()

  useEffect(() => {
    if (!sessionId) return
    let cancelled = false
    api
      .getTurns(sessionId)
      .then((fetchedTurns: Turn[]) => {
        if (cancelled) return
        setTurns(fetchedTurns)
        setStreamDone(true)
      })
      .catch(() => {
        if (!cancelled) setStreamDone(true)
      })
    return () => {
      cancelled = true
    }
  }, [sessionId])

  useEffect(() => {
    api.getVoiceStatus().then((s) => setVoiceEnabled(!!s.enabled)).catch(() => setVoiceEnabled(false))
  }, [])

  latestTurnsRef.current = turns

  // Pace the simulated classroom conversation so every turn gets a full
  // 15 seconds on screen before the next person speaks. The stream can arrive
  // faster in the background, but the learner only sees one paced turn at a time.
  const hasPendingInteractive = pacedTurns.some(
    (t) => (t.turn_type === 'blank' || t.turn_type === 'hint') && !revealedHints[t.id]
  )

  useEffect(() => {
    if (pacedTurns.length >= latestTurnsRef.current.length || pacingTimerRef.current || hasPendingInteractive) return

    if (pacedTurns.length === 0) {
      setPacedTurns([latestTurnsRef.current[0]])
      return
    }

    pacingTimerRef.current = setTimeout(() => {
      pacingTimerRef.current = null
      setPacedTurns((prev) => latestTurnsRef.current.slice(0, prev.length + 1))
    }, 15000)

    return () => {
      if (pacingTimerRef.current) {
        clearTimeout(pacingTimerRef.current)
        pacingTimerRef.current = null
      }
    }
  }, [turns.length, pacedTurns.length, hasPendingInteractive])

  useEffect(() => () => {
    if (pacingTimerRef.current) clearTimeout(pacingTimerRef.current)
  }, [])

  // The room freezes on the first unanswered hint/blank — like actually
  // being called on — instead of racing ahead while turns keep streaming in
  // behind the scenes.
  const pendingInteractive = pacedTurns.find(
    (t) => (t.turn_type === 'blank' || t.turn_type === 'hint') && !revealedHints[t.id]
  )
  const currentTurn = pendingInteractive || (pacedTurns.length ? pacedTurns[pacedTurns.length - 1] : null)
  const currentIndex = currentTurn ? pacedTurns.findIndex((t) => t.id === currentTurn.id) : -1
  const visibleTurns = currentIndex >= 0 ? pacedTurns.slice(0, currentIndex + 1) : []
  const calledOn = currentTurn?.turn_type === 'blank' || currentTurn?.turn_type === 'hint'
  const waitingForNextTurn = pacedTurns.length < turns.length && !pendingInteractive
  const lastTeacherTurn = [...visibleTurns].reverse().find((t) => t.speaker === 'teacher')
  const boardText = lastTeacherTurn?.content ?? 'Welcome — class is about to begin.'
  // camera focus for the stage: spotlight the learner specifically when
  // it's a called-on moment, otherwise follow whoever's actually speaking
  const activeSpeaker: 'teacher' | 'basic_student' | 'advanced_student' | 'learner' = calledOn
    ? 'learner'
    : (currentTurn?.speaker as 'teacher' | 'basic_student' | 'advanced_student' | 'learner') || 'teacher'

  // speak newly-spotlighted AI turns aloud when speak-mode is on
  useEffect(() => {
    if (!speakMode || !ttsSupported || !currentTurn) return
    if (currentTurn.speaker === 'learner') return
    if (spokenTurnIds.current.has(currentTurn.id)) return
    spokenTurnIds.current.add(currentTurn.id)
    const utterance = new SpeechSynthesisUtterance(currentTurn.content)
    utterance.rate = 1.0
    window.speechSynthesis.speak(utterance)
  }, [currentTurn, speakMode, ttsSupported])

  useEffect(() => {
    return () => {
      if (ttsSupported) window.speechSynthesis.cancel()
    }
  }, [ttsSupported])

  function speakText(text: string) {
    if (!ttsSupported) return
    window.speechSynthesis.cancel()
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(text))
  }

  const [guessFeedback, setGuessFeedback] = useState<Record<string, { isCorrect: boolean | null; feedback: string }>>({})
  const [gradingGuess, setGradingGuess] = useState<string | null>(null)

  async function submitGuess(turn: Turn) {
    const guessText = guesses[turn.id] || ''
    if (!guessText.trim() || guessFeedback[turn.id]) return
    setGradingGuess(turn.id)
    try {
      const res = await api.recordInteractionEvent({
        turn_id: turn.id,
        event_type: 'guess',
        payload: { guess: guessText },
      })
      // Deliberately NOT calling setRevealedHints here — that would make
      // `calledOn` go false on the next render and yank this feedback off
      // screen before the learner reads it. Revealing (and so advancing
      // pacing) happens when they click "Continue" below, not the instant
      // grading finishes.
      setGuessFeedback((prev) => ({ ...prev, [turn.id]: { isCorrect: res.is_correct, feedback: res.feedback || '' } }))
    } finally {
      setGradingGuess(null)
    }
  }

  function continueAfterFeedback(turnId: string) {
    setRevealedHints((prev) => ({ ...prev, [turnId]: true }))
  }

  async function handleAsk(text?: string) {
    const q = (text ?? question).trim()
    if (!q || !sessionId) return
    setAsking(true)
    try {
      const res = await api.askQuestion(sessionId, q)
      setTurns((prev) => [
        ...prev,
        { id: `learner-${Date.now()}`, speaker: 'learner', turn_type: 'learner_question', content: q, target_bloom_level: null },
        { id: res.id, speaker: 'teacher', turn_type: 'dialogue', content: res.content, target_bloom_level: null },
      ])
      setQuestion('')
    } finally {
      setAsking(false)
    }
  }

  function toggleListening() {
    if (!speechSupported) return
    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!Ctor) return

    if (listening) {
      recognitionRef.current?.stop()
      setListening(false)
      return
    }

    const recognition = new Ctor()
    recognition.lang = 'en-US'
    recognition.interimResults = true
    recognition.continuous = false
    recognition.onresult = (e) => {
      let finalTranscript = ''
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const result = e.results[i]
        if (result.isFinal) finalTranscript += result[0].transcript
        else setQuestion(result[0].transcript)
      }
      if (finalTranscript) setQuestion(finalTranscript)
    }
    recognition.onend = () => setListening(false)
    recognition.onerror = () => {
      setListening(false)
      setVoiceError('Could not hear you clearly — try typing instead.')
    }
    recognitionRef.current = recognition
    recognition.start()
    setListening(true)
  }

  async function startRecording() {
    setVoiceError(null)
    setVoiceResult(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : ''
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined)
      chunksRef.current = []
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data)
      }
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop())
      }
      recorder.start()
      mediaRecorderRef.current = recorder
      setRecording(true)
    } catch {
      setVoiceError('Could not access the microphone. You can type your explanation instead.')
    }
  }

  async function stopAndSubmitRecording() {
    const recorder = mediaRecorderRef.current
    if (!recorder || !sessionId) return
    recorder.stop()
    setRecording(false)
    setVoiceSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 200))
    try {
      const blob = new Blob(chunksRef.current, { type: chunksRef.current[0]?.type || 'audio/webm' })
      const res = await api.submitVoiceClip(sessionId, blob)
      setVoiceResult(res)
      if (!res.ok) setVoiceError('Voice scoring failed — you can type your explanation instead.')
    } catch {
      setVoiceError('Voice submission failed — you can type your explanation instead.')
    } finally {
      setVoiceSubmitting(false)
    }
  }



  return (
    <NavShell title="Classroom">
      <div className="space-y-4">
        {ttsSupported && (
          <div className="flex justify-end">
            <button
              onClick={() => {
                setSpeakMode((v) => !v)
                if (speakMode) window.speechSynthesis.cancel()
              }}
              className={`inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full border transition-colors ${
                speakMode ? 'bg-cobalt text-white border-cobalt' : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'
              }`}
            >
              {speakMode ? <Volume2 size={13} /> : <VolumeX size={13} />}
              {speakMode ? 'Reading aloud' : 'Read aloud'}
            </button>
          </div>
        )}

        {/* classroom + live conversation */}
        <div className="classroom-layout">
          <div className="relative rounded-3xl border border-slate-200 overflow-hidden classroom-stage">
            <img src={classroomImage} alt="A sunlit classroom" className="stage-photo" width={1920} height={1088} />
            <div className="stage-shade" />
            <div className="stage-sun" />

            <div className="blackboard">
              <small>On the board</small>
              <p>{boardText}</p>
            </div>

            <div className="figures">
              {(['teacher', 'basic_student', 'advanced_student', 'learner'] as const).map((who) => (
                <div key={who} className={`figure figure-${who} ${activeSpeaker === who ? 'speaking' : ''}`}>
                  <span className="figure-head" />
                  <span className="figure-body" />
                  <span className="figure-label">{PERSONA[who].label}</span>
                  {activeSpeaker === who && (
                    <span className="figure-bars" aria-hidden="true">
                      <i /><i /><i />
                    </span>
                  )}
                </div>
              ))}
            </div>

            {currentTurn && (
              <div className={`stage-bubble bubble-${activeSpeaker}`} aria-live="polite">
                <strong>{PERSONA[activeSpeaker].label}</strong>
                <p>{calledOn ? 'Your turn — answer below.' : currentTurn.content}</p>
              </div>
            )}

            {calledOn && (
              <div className="absolute top-3 right-3 bg-black/40 backdrop-blur-sm text-amber text-[11px] font-semibold px-3 py-1.5 rounded-full flex items-center gap-1.5 animate-pulse z-10">
                <Hand size={12} /> points at you
              </div>
            )}

            {ttsSupported && (
              <button
                onClick={() => speakText(currentTurn?.content || boardText)}
                className="absolute top-3 left-3 bg-black/30 hover:bg-black/50 text-white/80 hover:text-white rounded-full p-2 transition-colors z-10"
                aria-label="Read board aloud"
              >
                <Volume2 size={14} />
              </button>
            )}

            {waitingForNextTurn && (
              <div className="stage-controls">
                <Loader2 size={13} className="animate-spin text-white/70" />
                <span className="stage-progress">Next speaker in 15 seconds…</span>
              </div>
            )}
          </div>

          <aside className="class-transcript">
            <div className="class-transcript-header">
              <div>
                <p className="class-transcript-kicker">Class transcript</p>
                <h2>Follow the discussion</h2>
              </div>
              <span className="class-live-pill"><span /> LIVE</span>
            </div>

            <div className="class-transcript-list">
              {visibleTurns.length === 0 && (
                <div className="class-empty-transcript">
                  <GraduationCap size={20} />
                  <p>The class is getting ready…</p>
                </div>
              )}
              {visibleTurns.map((turn, index) => {
                const meta = PERSONA[turn.speaker] || PERSONA.teacher
                const Icon = meta.icon
                const isCurrent = index === visibleTurns.length - 1
                return (
                  <div key={turn.id} className={`transcript-turn ${isCurrent ? 'is-current' : ''} ${turn.speaker === 'learner' ? 'is-learner' : ''}`}>
                    <div className={`transcript-avatar ${meta.bg}`}><Icon size={13} /></div>
                    <div className="transcript-body">
                      <div className="transcript-name-row">
                        <strong>{meta.label}</strong>
                        {isCurrent && <span className="speaking-label">speaking</span>}
                      </div>
                      <p>{turn.content}</p>
                    </div>
                  </div>
                )
              })}
              {waitingForNextTurn && (
                <div className="transcript-waiting">
                  <span className="typing-dots"><i /><i /><i /></span>
                  Next response is coming…
                </div>
              )}
            </div>

            {calledOn && currentTurn && (
              <div className="transcript-response">
                {!guessFeedback[currentTurn.id] ? (
                  <>
                    <p>{currentTurn.turn_type === 'blank' ? 'Your answer' : 'Your guess, before the answer'}</p>
                    <div className="transcript-response-row">
                      <input
                        autoFocus
                        placeholder={currentTurn.turn_type === 'blank' ? 'Type your answer…' : 'Type your guess…'}
                        value={guesses[currentTurn.id] || ''}
                        onChange={(e) => setGuesses((prev) => ({ ...prev, [currentTurn.id]: e.target.value }))}
                        onKeyDown={(e) => e.key === 'Enter' && submitGuess(currentTurn)}
                        disabled={gradingGuess === currentTurn.id}
                      />
                      <button onClick={() => submitGuess(currentTurn)} disabled={gradingGuess === currentTurn.id}>
                        {gradingGuess === currentTurn.id
                          ? 'Checking…'
                          : currentTurn.turn_type === 'blank'
                            ? 'Answer'
                            : 'Reveal'}
                      </button>
                    </div>
                  </>
                ) : (
                  <div className={`guess-feedback ${guessFeedback[currentTurn.id].isCorrect ? 'guess-feedback-correct' : 'guess-feedback-incorrect'}`}>
                    <p className="guess-feedback-verdict">
                      {guessFeedback[currentTurn.id].isCorrect ? '✓ Correct' : '✗ Not quite'}
                    </p>
                    {guessFeedback[currentTurn.id].feedback && (
                      <p className="guess-feedback-text">{guessFeedback[currentTurn.id].feedback}</p>
                    )}
                    <button onClick={() => continueAfterFeedback(currentTurn.id)}>Continue</button>
                  </div>
                )}
              </div>
            )}
          </aside>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-3 flex gap-2 items-center">
          <Hand size={15} className="text-slate-300 ml-1 shrink-0" />
          <input
            className="border-0 focus:outline-none focus:ring-0 px-2 py-2 text-sm flex-1"
            placeholder={listening ? 'Listening…' : 'Raise your hand to ask a question…'}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
          />
          {speechSupported && (
            <button
              onClick={toggleListening}
              className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                listening ? 'bg-learner text-white animate-pulse' : 'text-slate-400 hover:bg-slate-50'
              }`}
              aria-label={listening ? 'Stop listening' : 'Ask by voice'}
            >
              <Mic size={16} />
            </button>
          )}
          <button
            className="bg-ink text-white rounded-lg w-9 h-9 flex items-center justify-center disabled:opacity-50 hover:bg-cobalt-dark transition-colors shrink-0"
            disabled={asking || !question.trim()}
            onClick={() => handleAsk()}
            aria-label="Send question"
          >
            <Send size={15} />
          </button>
        </div>

        {streamDone && voiceEnabled && (
          <div className="bg-white rounded-2xl border border-slate-200 p-5">
            <p className="text-sm text-slate-600 mb-3">
              Teach it back out loud — record a short clip explaining the concept in your own words.
            </p>
            <div className="flex items-center gap-3">
              {!recording ? (
                <button
                  className="flex items-center gap-2 border border-slate-200 rounded-lg px-4 py-2 text-sm font-medium hover:bg-slate-50 disabled:opacity-50"
                  disabled={voiceSubmitting}
                  onClick={startRecording}
                >
                  <Mic size={15} /> Start recording
                </button>
              ) : (
                <button
                  className="flex items-center gap-2 bg-learner text-white rounded-lg px-4 py-2 text-sm font-medium animate-pulse"
                  onClick={stopAndSubmitRecording}
                >
                  <Square size={13} /> Stop & submit
                </button>
              )}
              {voiceSubmitting && <span className="text-xs text-slate-400">Scoring…</span>}
            </div>

            {voiceError && <p className="text-xs text-amber mt-2">{voiceError}</p>}

            {voiceResult?.ok && (
              <div className="mt-3 text-sm text-slate-700 space-y-1">
                <p>
                  Coverage score: <span className="font-medium">{voiceResult.transcript_coverage_score}</span>
                  {voiceResult.signal_degraded && (
                    <span className="ml-2 text-xs text-amber">(timing signal degraded — coverage still counted)</span>
                  )}
                </p>
                {voiceResult.speech_rate_wpm != null && (
                  <p className="text-xs text-slate-400">Speech rate: {voiceResult.speech_rate_wpm} wpm</p>
                )}
                {voiceResult.hesitation_flags && voiceResult.hesitation_flags.length > 0 && (
                  <p className="text-xs text-slate-400">
                    Hesitation noticed near: {voiceResult.hesitation_flags.map((h) => h.term).join(', ')}
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {streamDone && !pendingInteractive && pacedTurns.length === turns.length && currentIndex === pacedTurns.length - 1 && (
          <div className="flex justify-end">
            <button
              className="flex items-center gap-1.5 bg-ink text-white rounded-lg px-5 py-2.5 text-sm font-medium hover:bg-cobalt-dark transition-colors"
              onClick={() => navigate(`/checkpoint/${sessionId}`)}
            >
              Proceed to checkpoint <ArrowRight size={14} />
            </button>
          </div>
        )}
      </div>
    </NavShell>
  )
}
