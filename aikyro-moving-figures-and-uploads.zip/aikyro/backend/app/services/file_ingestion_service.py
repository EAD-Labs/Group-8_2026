"""
Turns an uploaded PDF or image into text the rest of the pipeline can treat
as "course material" — the thing the learner explicitly said should be
prioritized over the model's general knowledge when generating a custom
module (curriculum, concept explanations).

PDF extraction is real and works in mock mode too (it's just text
extraction, no LLM call needed). Image extraction genuinely needs a vision
model, so it only works in live mode with a configured provider — in mock
mode it degrades to a placeholder string, same fallback pattern as
everywhere else, rather than silently producing nothing.
"""
from app.config import settings
from app.services.llm_providers import describe_image, preferred_available_provider

MAX_CHARS_PER_FILE = 6000  # keep prompts from ballooning with a large PDF
MAX_TOTAL_CHARS = 16000


async def extract_text(filename: str, content_type: str, data: bytes) -> str:
    """Returns extracted text (possibly a placeholder), never raises — a
    file that fails to parse degrades to an empty/placeholder string rather
    than blocking module creation."""
    try:
        if content_type == "application/pdf" or filename.lower().endswith(".pdf"):
            return _extract_pdf(data)[:MAX_CHARS_PER_FILE]
        if content_type.startswith("image/"):
            return (await _extract_image(data, content_type))[:MAX_CHARS_PER_FILE]
    except Exception as e:
        return f"[Could not read {filename}: {e}]"
    return f"[Unsupported file type for {filename} — only PDF and images are read as course material]"


def _extract_pdf(data: bytes) -> str:
    from pypdf import PdfReader
    import io

    reader = PdfReader(io.BytesIO(data))
    pages = []
    for page in reader.pages:
        text = page.extract_text() or ""
        if text.strip():
            pages.append(text.strip())
    return "\n\n".join(pages) or "[No extractable text found in this PDF — it may be scanned images without OCR]"


async def _extract_image(data: bytes, content_type: str) -> str:
    if settings.llm_mode != "live":
        return "[Image provided — set llm_mode=live to have the AI actually read it as course material]"
    provider = preferred_available_provider()
    if not provider:
        return "[Image provided — no live provider configured to read it]"

    import base64

    image_b64 = base64.b64encode(data).decode()
    prompt = (
        "This image is course material a student uploaded (a textbook page, slide, "
        "diagram, or handwritten notes). Transcribe/describe everything academically "
        "relevant in it as plain text — definitions, formulas, diagrams (describe what "
        "they show), examples. Be thorough and literal; don't summarize or skip detail."
    )
    return await describe_image(provider, image_b64, content_type, prompt)


def combine(extracted: list[str]) -> str:
    combined = "\n\n---\n\n".join(t for t in extracted if t.strip())
    return combined[:MAX_TOTAL_CHARS]
