import { Canvas, useFrame } from '@react-three/fiber'
import { OrthographicCamera } from '@react-three/drei'
import { useRef } from 'react'
import * as THREE from 'three'

export type ClassroomSpeaker = 'teacher' | 'basic_student' | 'advanced_student' | 'learner'

// Matches tailwind.config.js persona colors, so this layer and the rest of
// the UI never disagree on whose color is whose.
const COLOR = {
  teacher: '#2F3F8F',
  basic_student: '#1E8A72',
  advanced_student: '#6B3FA0',
  learner: '#B54A34',
  skin: '#c99a72',
}

// World positions under the fixed orthographic camera below (world units,
// not pixels — see <OrthographicCamera> bounds). Roughly: teacher upper-
// middle near the board, students in a lower row like desks in the
// foreground of the photo. Tuned by eye against a typical front-of-room
// classroom photo composition — nudge these if it doesn't line up with
// your actual image once you can see it rendered.
const LAYOUT: Record<ClassroomSpeaker, { x: number; y: number; scale: number }> = {
  teacher: { x: 0, y: 0.55, scale: 1.15 },
  basic_student: { x: -2.6, y: -1.1, scale: 0.95 },
  advanced_student: { x: 2.6, y: -1.1, scale: 0.95 },
  learner: { x: 0, y: -1.55, scale: 1 },
}

function Person({ who, speaking, seated }: { who: ClassroomSpeaker; speaking: boolean; seated: boolean }) {
  const { x, y, scale } = LAYOUT[who]
  const color = COLOR[who]
  const group = useRef<THREE.Group>(null)
  const arm = useRef<THREE.Mesh>(null)
  const seed = useRef(Math.random() * Math.PI * 2)

  useFrame(({ clock }, rawDelta) => {
    const dt = Math.min(rawDelta, 0.05)
    const t = clock.elapsedTime + seed.current
    if (group.current) {
      // idle breathing sway for everyone, a bigger bounce for whoever's talking
      const idle = Math.sin(t * 1.4) * 0.025
      const talk = speaking ? 0.09 + Math.sin(t * 5) * 0.045 : 0
      group.current.position.y = y + idle + talk
      group.current.rotation.z = Math.sin(t * 0.9) * 0.015
    }
    if (arm.current) {
      const target = speaking ? -1.7 + Math.sin(t * 6) * 0.15 : -0.2 + Math.sin(t * 1.1) * 0.05
      arm.current.rotation.z = THREE.MathUtils.damp(arm.current.rotation.z, target, 6, dt)
    }
  })

  const headY = seated ? 0.62 : 0.86
  const bodyY = seated ? 0.18 : 0.32

  return (
    <group ref={group} position={[x, y, 0]} scale={scale}>
      {/* soft contact shadow */}
      <mesh position={[0, -0.62, -0.01]}>
        <circleGeometry args={[0.34, 20]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.22} />
      </mesh>

      <mesh position={[0, headY, 0]}>
        <sphereGeometry args={[0.22, 20, 16]} />
        <meshStandardMaterial color={COLOR.skin} roughness={0.85} />
      </mesh>
      <mesh position={[0, bodyY, 0]}>
        <capsuleGeometry args={[0.26, seated ? 0.42 : 0.58, 6, 12]} />
        <meshStandardMaterial color={color} roughness={0.75} />
      </mesh>
      <mesh ref={arm} position={[0.3, bodyY + 0.1, 0]} rotation-z={-0.2}>
        <capsuleGeometry args={[0.07, 0.46, 4, 8]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[-0.3, bodyY, 0]} rotation-z={0.18}>
        <capsuleGeometry args={[0.07, 0.46, 4, 8]} />
        <meshStandardMaterial color={color} />
      </mesh>
    </group>
  )
}

export function ClassroomFigures({ speaker }: { speaker: ClassroomSpeaker }) {
  return (
    <Canvas
      gl={{ alpha: true, antialias: true }}
      style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}
    >
      <OrthographicCamera makeDefault position={[0, 0, 10]} zoom={90} />
      <ambientLight intensity={0.9} />
      <directionalLight position={[3, 5, 6]} intensity={0.9} />
      <Person who="teacher" speaking={speaker === 'teacher'} seated={false} />
      <Person who="basic_student" speaking={speaker === 'basic_student'} seated />
      <Person who="advanced_student" speaking={speaker === 'advanced_student'} seated />
      <Person who="learner" speaking={speaker === 'learner'} seated />
    </Canvas>
  )
}
