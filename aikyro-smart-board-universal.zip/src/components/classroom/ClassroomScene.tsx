import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer, RoundedBox, Text, useAnimations, useGLTF } from "@react-three/drei";
import { Suspense, useEffect, useMemo, useRef } from "react";
import { clone as cloneSkinned } from "three/examples/jsm/utils/SkeletonUtils.js";
import * as THREE from "three";

type Speaker = "teacher" | "maya" | "arjun";
const C = { wall: "#d8d1bf", floor: "#805d3d", wood: "#a8784f", dark: "#253039", board: "#183e35", chalk: "#f5f2e8", teacher: "#2f6f71", maya: "#d06a52", arjun: "#d7a83e", skin: "#b97a55", metal: "#536874", window: "#a9d9df" };


const A = "CharacterArmature|";
function Avatar({ url, position, rotation = 0, scale = 1, speaking, faceTo }: { url: string; position: [number, number, number]; rotation?: number; scale?: number; speaking: boolean; faceTo?: [number, number] }) {
  const { scene, animations } = useGLTF(url);
  const model = useMemo(() => { const c = cloneSkinned(scene); c.traverse(o => { if ((o as THREE.Mesh).isMesh) { o.castShadow = true; o.receiveShadow = true; } }); return c; }, [scene]);
  const group = useRef<THREE.Group>(null);
  const { actions } = useAnimations(animations, group);
  useEffect(() => {
    const idle = actions[A + "Idle_Neutral"] ?? actions[A + "Idle"];
    if (!speaking) { idle?.reset().fadeIn(.4).play(); return () => { idle?.fadeOut(.4); }; }
    const seq = [A + "Interact", A + "Idle", A + "Wave"]; let i = 0; let cur = actions[seq[0]!];
    cur?.reset().fadeIn(.35).play();
    const t = window.setInterval(() => { const next = actions[seq[++i % seq.length]!]; if (next && next !== cur) { cur?.fadeOut(.4); next.reset().fadeIn(.4).play(); cur = next; } }, 2600);
    return () => { window.clearInterval(t); cur?.fadeOut(.4); };
  }, [speaking, actions]);
  const rotY = faceTo ? Math.atan2(faceTo[0] - position[0], faceTo[1] - position[2]) : rotation;
  return <group ref={group} position={position} rotation-y={rotY} scale={scale}><primitive object={model} /></group>;
}
["/models/teacher.glb", "/models/maya.glb", "/models/arjun.glb"].forEach(u => useGLTF.preload(u));

function Desk({ position, rotation = 0 }: { position: [number, number, number]; rotation?: number }) {
 return <group position={position} rotation-y={rotation}><RoundedBox args={[1.8,.16,.75]} radius={.05} position={[0,.85,0]} castShadow><meshStandardMaterial color={C.wood} roughness={.75}/></RoundedBox>{[-.72,.72].flatMap(x=>[-.25,.25].map((z,i)=><mesh key={`${x}-${i}`} position={[x,.4,z]} castShadow><boxGeometry args={[.1,.8,.1]}/><meshStandardMaterial color={C.metal}/></mesh>))}</group>
}

function CameraRig({ speaker }: { speaker: Speaker }) {
 const { camera } = useThree();
 useFrame((_, delta) => {
  const target = speaker === "teacher" ? new THREE.Vector3(0,3.1,8.8) : speaker === "maya" ? new THREE.Vector3(-1.2,2.3,-1.9) : new THREE.Vector3(1.2,2.3,-1.9);
  camera.position.lerp(target, 1-Math.exp(-1.5*Math.min(delta,.05)));
  const lookAt = speaker === "teacher"
   ? new THREE.Vector3(0, 2.2, -2)
   : speaker === "maya"
     ? new THREE.Vector3(-2.8, 1.45, .55)
     : new THREE.Vector3(2.8, 1.45, .55);
  camera.lookAt(lookAt);
 });
 return null;
}

function BoardVisual({ board, lessonContext }: { board: string; lessonContext: string }) {
 const source = `${board}. ${lessonContext}`;
 const lower = source.toLowerCase();
 const energy = /energy|δu|heat|work|first law|thermodynamic|enthalpy|exergy/.test(lower);
 const entropy = /entropy|δs|reversible|irreversible|universe/.test(lower);
 const probability = /probability|bayes|p\(|independence|expectation|sampling|confidence|correlation|statistics/.test(lower);
 const chemistry = /reaction|chemical|mole|stoichiometr|equilibrium|catalyst|acid|base|oxidation|reduction|ph|concentration|kinetic/.test(lower);
 const biology = /cell|biology|organism|gene|dna|protein|enzyme|ecosystem|photosynthesis|respiration|evolution/.test(lower);
 const computing = /algorithm|code|program|computer|machine learning|neural network|data structure|complexity|database|artificial intelligence| ai /.test(` ${lower} `);
 const economics = /market|econom|supply|demand|inflation|interest rate|finance|investment|profit|revenue|cost|portfolio|capital/.test(lower);
 const history = /history|historical|revolution|empire|war|civilization|colonial|independence|century|treaty/.test(lower);
 const maths = /derivative|integral|function|equation|matrix|vector|calculus|linear algebra|geometry|theorem|proof|limit|optimization/.test(lower);
 const steps = /predict|claim|mechanism|evidence|new situation|teach-back|test the boundary/.test(lower);
 const headingRaw = board.trim() || lessonContext.trim() || "Today's concept";
 const heading = headingRaw.length > 48 ? headingRaw.slice(0, 45).trim() + "…" : headingRaw;
 const node = (x: number, label: string, color: string, width = 1.55) => <group position={[x,-.15,.08]}><RoundedBox args={[width,.62,.06]} radius={.08}><meshStandardMaterial color={color} emissive={color} emissiveIntensity={.12}/></RoundedBox><Text position={[0,0,.05]} fontSize={.17} maxWidth={width-.12} textAlign="center" anchorX="center" anchorY="middle" color="#ffffff">{label}</Text></group>;
 // Universal fallback: turn the actual lesson text into a three-part visual, so new AI-generated
 // topics and uploaded material still produce a meaningful board even without a domain-specific renderer.
 const clean = (s: string) => s.replace(/\b(the|and|with|from|that|this|into|when|what|which|where|your|their|about|after|before|because|through|using|between|concept|explain|understand|lesson)\b/gi, " ").replace(/[^\p{L}\p{N} ΔΣ=+−*/().%-]/gu, " ").replace(/\s+/g, " ").trim();
 const phrases = (s: string) => {
   const chunks = s.split(/[.!?;:\n→]+/).map(clean).filter(x => x.length > 3);
   const unique: string[] = [];
   for (const chunk of chunks) { const short = chunk.split(/\s+/).slice(0, 4).join(" "); if (short && !unique.some(x => x.toLowerCase() === short.toLowerCase())) unique.push(short); if (unique.length === 3) break; }
   return unique;
 };
 const fallback = phrases(lessonContext || board);
 const generic = [fallback[0] || "CORE IDEA", fallback[1] || "HOW IT WORKS", fallback[2] || "APPLY & CHECK"];
 return <group position={[0,3.6,-4.62]}>
  <Text position={[0,1.13,.08]} fontSize={.25} maxWidth={7.2} textAlign="center" anchorX="center" anchorY="middle" color="#fff3b0">{heading}</Text>
  {energy ? <>
    {node(-2.35,"HEAT / Q","#b94f48")}{node(0,"SYSTEM / ΔU","#237e75")}{node(2.35,"WORK / W","#4776b8")}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.25} color="#f5f2e8">{(/enthalpy/.test(lower) ? "ΔH = Qₚ" : /exergy/.test(lower) ? "Useful work depends on surroundings" : "ΔU = Q − W")}</Text>
  </> : entropy ? <>
    {node(-2.3,"INITIAL STATE","#c65d43")}{node(0,"ENERGY SPREADS","#6c65b6")}{node(2.3,"FINAL STATE","#3f8fbd")}
    <Text position={[-1.15,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.15,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.25} color="#f5f2e8">ΔS universe ≥ 0</Text>
  </> : probability ? <>
    <mesh position={[-.62,-.15,.08]}><circleGeometry args={[.72,48]}/><meshBasicMaterial color="#3d91d0" transparent opacity={.65}/></mesh>
    <mesh position={[.22,-.15,.1]}><circleGeometry args={[.72,48]}/><meshBasicMaterial color="#d5a63a" transparent opacity={.65}/></mesh>
    <Text position={[-.78,-.12,.2]} fontSize={.25} color="#ffffff">A</Text><Text position={[.4,-.12,.22]} fontSize={.25} color="#ffffff">B</Text>
    <Text position={[2,-.05,.12]} fontSize={.22} maxWidth={2.4} color="#f5f2e8">{(/bayes/.test(lower) ? "Prior × likelihood → posterior" : /correlation/.test(lower) ? "Association ≠ causation" : "P(A | B) = P(A ∩ B) / P(B)")}</Text>
    <Text position={[0,-1.03,.08]} fontSize={.2} color="#d7f3e8">Update the reference group first</Text>
  </> : chemistry ? <>
    {node(-2.35,"REACTANTS","#4776b8")}{node(0,"REACTION","#237e75")}{node(2.35,"PRODUCTS","#b47737")}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.22} color="#f5f2e8">Track species, conditions and conservation</Text>
  </> : biology ? <>
    {node(-2.35,"STRUCTURE","#4776b8")}{node(0,"PROCESS","#237e75")}{node(2.35,"FUNCTION","#b47737")}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.22} color="#f5f2e8">Connect biological structure to its role</Text>
  </> : computing ? <>
    {node(-2.35,"INPUT / DATA","#4776b8")}{node(0,"ALGORITHM","#237e75")}{node(2.35,"OUTPUT","#b47737")}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.22} color="#f5f2e8">Inspect assumptions, steps and result</Text>
  </> : economics ? <>
    {node(-2.35,"DRIVER","#4776b8")}{node(0,"MARKET RESPONSE","#237e75",1.8)}{node(2.35,"OUTCOME","#b47737")}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.22} color="#f5f2e8">Separate assumptions from observed evidence</Text>
  </> : history ? <>
    {node(-2.35,"CONTEXT","#4776b8")}{node(0,"TURNING POINT","#237e75",1.8)}{node(2.35,"CONSEQUENCE","#b47737",1.7)}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.22} color="#f5f2e8">Trace cause, decision and consequence</Text>
  </> : maths ? <>
    {node(-2.35,"GIVEN","#4776b8")}{node(0,"METHOD","#237e75")}{node(2.35,"RESULT","#b47737")}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.22} color="#f5f2e8">State conditions, solve, then verify</Text>
  </> : <>
    {node(-2.35,generic[0].toUpperCase(),"#4776b8",1.8)}{node(0,generic[1].toUpperCase(),"#237e75",1.8)}{node(2.35,generic[2].toUpperCase(),"#b47737",1.8)}
    <Text position={[-1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text><Text position={[1.18,-.15,.18]} fontSize={.3} color="#f5f2e8">→</Text>
    <Text position={[0,-.93,.08]} fontSize={.22} color="#f5f2e8">{steps ? "Predict → explain → test your idea" : "Explore the idea → connect it → apply it"}</Text>
  </>}
 </group>;
}

function Room({ speaker, board, lessonContext }: { speaker: Speaker; board: string; lessonContext: string }) {
 return <>
  <CameraRig speaker={speaker}/><color attach="background" args={[C.wall]}/><fog attach="fog" args={[C.wall,14,30]}/>
  <ambientLight intensity={.65}/><directionalLight position={[5,10,7]} intensity={1.6} castShadow shadow-mapSize-width={1024} shadow-mapSize-height={1024}/>
  <Environment><Lightformer intensity={2} position={[0,7,0]} scale={[12,12,1]}/><Lightformer intensity={1} color={C.window} position={[-7,4,0]} rotation-y={Math.PI/2} scale={[7,4,1]}/></Environment>
  <mesh rotation-x={-Math.PI/2} receiveShadow><planeGeometry args={[18,20]}/><meshStandardMaterial color={C.floor} roughness={.95}/></mesh>
  <mesh position={[0,4,-5]} receiveShadow><boxGeometry args={[18,8,.2]}/><meshStandardMaterial color={C.wall}/></mesh>
  <mesh position={[-6.1,3.9,-4.75]}><boxGeometry args={[2.35,3.7,.12]}/><meshStandardMaterial color={C.window} emissive={C.window} emissiveIntensity={.18}/></mesh>
  <mesh position={[-6.1,3.9,-4.58]}><boxGeometry args={[.08,3.7,.05]}/><meshStandardMaterial color={C.dark}/></mesh>
  <mesh position={[-6.1,3.9,-4.58]}><boxGeometry args={[2.35,.08,.05]}/><meshStandardMaterial color={C.dark}/></mesh>
  <mesh position={[6.2,2.1,-4.68]}><boxGeometry args={[1.25,2.6,.16]}/><meshStandardMaterial color={C.wood}/></mesh>
  <mesh position={[6.2,2.1,-4.52]}><boxGeometry args={[1.03,2.25,.04]}/><meshStandardMaterial color={C.dark}/></mesh>
  <RoundedBox args={[8,3.2,.18]} radius={.06} position={[0,3.6,-4.78]} castShadow><meshStandardMaterial color={C.board} roughness={.85}/></RoundedBox>
  <BoardVisual board={board} lessonContext={lessonContext}/>
  <Avatar url="/models/teacher.glb" position={[0,0,-3.2]} speaking={speaker==="teacher"} faceTo={[0,6]}/>
  <Desk position={[-2.8,0,-.2]} rotation={-.06}/><Avatar url="/models/maya.glb" position={[-2.8,0,.55]} scale={.92} speaking={speaker==="maya"} faceTo={[0,-3.2]}/>
  <Desk position={[2.8,0,-.2]} rotation={.06}/><Avatar url="/models/arjun.glb" position={[2.8,0,.55]} scale={.95} speaking={speaker==="arjun"} faceTo={[0,-3.2]}/>
  <Desk position={[-2.7,0,3.1]}/><Avatar url="/models/arjun.glb" position={[-2.7,0,3.85]} scale={.9} speaking={false} faceTo={[0,-3.2]}/>
  <Desk position={[2.7,0,3.1]}/><Avatar url="/models/maya.glb" position={[2.7,0,3.85]} scale={.9} speaking={false} faceTo={[0,-3.2]}/>
  <Desk position={[0,0,5.2]}/>
  <group position={[-6.4,0,-2.7]}><mesh position={[0,.55,0]}><cylinderGeometry args={[.46,.34,1,16]}/><meshStandardMaterial color={C.dark}/></mesh><mesh position={[0,1.45,0]}><sphereGeometry args={[.65,16,12]}/><meshStandardMaterial color="#487963" roughness={.9}/></mesh></group>
 </>;
}

export function ClassroomScene({ speaker, board, lessonContext = "" }: { speaker: Speaker; board: string; lessonContext?: string }) {
 return <Canvas shadows dpr={[1,1.5]} camera={{ position:[0,3.1,8.8], fov:48 }} gl={{ antialias:true }}><Suspense fallback={null}><Room speaker={speaker} board={board} lessonContext={lessonContext}/></Suspense></Canvas>;
}
